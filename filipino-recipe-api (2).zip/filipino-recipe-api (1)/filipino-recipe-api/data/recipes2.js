// Each recipe references ingredient names that must match (or closely match)
// an entry in ingredients.js so nutrition can be computed automatically.
// "grams" is an approximate portion used per recipe serving for nutrition totals.

module.exports = [
  // ULAM RECIPES
  {
    name: "Sinigang na Baboy",
    description: "Pork simmered in a sour tamarind broth with vegetables.",
    servings: 4,
    tags: ["ulam", "soup", "sour"],
    instructions: [
      "1. Boil pork in water until tender, skimming scum.",
      "2. Add sitaw, kalabasa, and labanos, simmer until half-cooked.",
      "3. Add tamarind souring mix or fresh sampalok, then talong and sili na mura.",
      "4. Season with patis to taste and simmer until vegetables are tender.",
    ],
    ingredients: [
      { name: "Baboy (pork, kasim/shoulder)", grams: 600 },
      { name: "Sitaw (yardlong beans)", grams: 100 },
      { name: "Kalabasa (squash)", grams: 150 },
      { name: "Labanos (radish)", grams: 100 },
      { name: "Talong (eggplant)", grams: 100 },
      { name: "Sili na mura (green finger chili)", grams: 20 },
      { name: "Patis (fish sauce)", grams: 15 },
    ],
  },
  {
    name: "Adobong Manok",
    description: "Chicken braised in soy sauce, vinegar, garlic, and bay leaf.",
    servings: 4,
    tags: ["ulam", "braised"],
    instructions: [
      "Marinate chicken in toyo, suka, crushed bawang, and pepper.",
      "Sear chicken, then simmer in the marinade plus water until tender.",
      "Reduce sauce until slightly thick.",
    ],
    ingredients: [
      { name: "Manok (chicken)", grams: 700 },
      { name: "Toyo (soy sauce)", grams: 60 },
      { name: "Suka (vinegar)", grams: 60 },
      { name: "Bawang (garlic)", grams: 20 },
    ],
  },
  {
    name: "Pinakbet",
    description: "Mixed native vegetables sautéed with bagoong.",
    servings: 4,
    tags: ["ulam", "vegetable"],
    instructions: [
      "Sauté bawang, sibuyas, and luya.",
      "Add pork if using, cook briefly.",
      "Add kalabasa first, then sitaw, talong, and ampalaya.",
      "Season with bagoong alamang, cover and simmer until vegetables are just tender.",
    ],
    ingredients: [
      { name: "Kalabasa (squash)", grams: 150 },
      { name: "Sitaw (yardlong beans)", grams: 100 },
      { name: "Talong (eggplant)", grams: 100 },
      { name: "Ampalaya (bitter melon)", grams: 80 },
      { name: "Bagoong alamang (shrimp paste)", grams: 20 },
      { name: "Bawang (garlic)", grams: 10 },
      { name: "Sibuyas (onion)", grams: 40 },
    ],
  },
  {
    name: "Tinolang Manok",
    description: "Ginger chicken soup with green papaya or chayote and malunggay leaves.",
    servings: 4,
    tags: ["ulam", "soup"],
    instructions: [
      "Sauté luya, bawang, and sibuyas, then add chicken pieces.",
      "Add patis and water, simmer until chicken is tender.",
      "Add gabi or green papaya, cook until soft.",
      "Finish with malunggay leaves.",
    ],
    ingredients: [
      { name: "Manok (chicken)", grams: 700 },
      { name: "Luya (ginger)", grams: 30 },
      { name: "Malunggay (moringa leaves)", grams: 40 },
      { name: "Patis (fish sauce)", grams: 15 },
      { name: "Sibuyas (onion)", grams: 40 },
      { name: "Bawang (garlic)", grams: 10 },
    ],
  },
  {
    name: "Laing",
    description: "Dried taro leaves simmered in coconut milk with chili.",
    servings: 4,
    tags: ["ulam", "vegetable", "spicy"],
    instructions: [
      "Simmer gata with bawang, sibuyas, and luya.",
      "Add dried gabi leaves without stirring until softened, then add bagoong alamang.",
      "Add siling labuyo and simmer until oil separates.",
    ],
    ingredients: [
      { name: "Gata (coconut milk)", grams: 400 },
      { name: "Bagoong alamang (shrimp paste)", grams: 30 },
      { name: "Siling labuyo (bird's eye chili)", grams: 15 },
      { name: "Bawang (garlic)", grams: 10 },
      { name: "Sibuyas (onion)", grams: 30 },
    ],
  },
  {
    name: "Bicol Express",
    description: "Pork simmered in coconut milk with shrimp paste and chilies.",
    servings: 4,
    tags: ["ulam", "spicy"],
    instructions: [
      "Sauté bawang, sibuyas, and luya, then add pork and brown.",
      "Add bagoong alamang and gata, simmer until pork is tender.",
      "Add sili na mura and siling labuyo, simmer until sauce thickens.",
    ],
    ingredients: [
      { name: "Baboy (pork, kasim/shoulder)", grams: 500 },
      { name: "Gata (coconut milk)", grams: 300 },
      { name: "Bagoong alamang (shrimp paste)", grams: 40 },
      { name: "Siling labuyo (bird's eye chili)", grams: 30 },
      { name: "Sili na mura (green finger chili)", grams: 30 },
    ],
  },
  {
    name: "Ginisang Sitaw at Kalabasa",
    description: "Sautéed yardlong beans and squash with shrimp or pork.",
    servings: 4,
    tags: ["ulam", "vegetable"],
    instructions: [
      "Sauté bawang, sibuyas, and luya.",
      "Add hipon or pork, cook until color changes.",
      "Add kalabasa, cook briefly, then sitaw.",
      "Season with patis, simmer until vegetables are tender.",
    ],
    ingredients: [
      { name: "Sitaw (yardlong beans)", grams: 150 },
      { name: "Kalabasa (squash)", grams: 150 },
      { name: "Hipon (shrimp)", grams: 150 },
      { name: "Bawang (garlic)", grams: 10 },
      { name: "Sibuyas (onion)", grams: 30 },
      { name: "Patis (fish sauce)", grams: 10 },
    ],
  },
  {
    name: "Paksiw na Bangus",
    description: "Milkfish simmered in vinegar, garlic, and ginger.",
    servings: 4,
    tags: ["ulam", "sour"],
    instructions: [
      "Arrange bangus in a pan with luya, bawang, and sili na mura.",
      "Add suka and water, bring to a boil without stirring.",
      "Simmer until fish is cooked through and sauce reduces slightly.",
    ],
    ingredients: [
      { name: "Bangus (milkfish)", grams: 600 },
      { name: "Suka (vinegar)", grams: 100 },
      { name: "Luya (ginger)", grams: 20 },
      { name: "Bawang (garlic)", grams: 10 },
      { name: "Sili na mura (green finger chili)", grams: 15 },
    ],
  },
  {
    name: "Ginataang Kalabasa at Sitaw",
    description: "Squash and yardlong beans simmered in coconut milk.",
    servings: 4,
    tags: ["ulam", "vegetable"],
    instructions: [
      "Sauté bawang, sibuyas, and luya.",
      "Add kalabasa and gata, simmer until squash softens.",
      "Add sitaw and bagoong alamang, simmer until tender.",
    ],
    ingredients: [
      { name: "Kalabasa (squash)", grams: 200 },
      { name: "Sitaw (yardlong beans)", grams: 100 },
      { name: "Gata (coconut milk)", grams: 300 },
      { name: "Bagoong alamang (shrimp paste)", grams: 20 },
      { name: "Bawang (garlic)", grams: 10 },
      { name: "Sibuyas (onion)", grams: 30 },
    ],
  },
  {
    name: "Nilagang Baka",
    description: "Boiled beef soup with saba, kalabasa, and vegetables.",
    servings: 4,
    tags: ["ulam", "soup"],
    instructions: [
      "Boil baka until tender, skimming scum.",
      "Add saging na saba and kalabasa, simmer until soft.",
      "Season with patis or salt to taste.",
    ],
    ingredients: [
      { name: "Baka (beef, brisket/shank)", grams: 700 },
      { name: "Saging na saba (plantain)", grams: 150 },
      { name: "Kalabasa (squash)", grams: 150 },
      { name: "Sibuyas (onion)", grams: 40 },
      { name: "Patis (fish sauce)", grams: 10 },
    ],
  },
  {
    name: "Ginisang Ampalaya with Egg",
    description: "Sautéed bitter melon with egg, garlic, and onion.",
    servings: 3,
    tags: ["ulam", "vegetable"],
    instructions: [
      "Sauté bawang and sibuyas.",
      "Add sliced ampalaya, cook until slightly wilted.",
      "Push to the side, scramble itlog, then mix together.",
      "Season with patis to taste.",
    ],
    ingredients: [
      { name: "Ampalaya (bitter melon)", grams: 200 },
      { name: "Itlog (egg)", grams: 100 },
      { name: "Bawang (garlic)", grams: 10 },
      { name: "Sibuyas (onion)", grams: 30 },
      { name: "Patis (fish sauce)", grams: 8 },
    ],
  },
  {
    name: "Tokwa't Bagoong",
    description: "Fried tofu drizzled with sautéed shrimp paste, served with calamansi.",
    servings: 3,
    tags: ["ulam", "vegetarian-ish", "condiment-forward"],
    ingredients: [
      { name: "Tokwa (tofu)", grams: 300 },
      { name: "Bagoong alamang (shrimp paste)", grams: 40 },
      { name: "Bawang (garlic)", grams: 10 },
      { name: "Calamansi", grams: 20 },
    ],
    instructions: [
      "1. Fry tokwa cubes until golden and crisp.",
      "2. Sauté bawang and bagoong alamang with a bit of sugar until fragrant.",
      "3. Top tofu with the bagoong mixture and a squeeze of calamansi.",
    ],
  },
  {
    name: "Adobong talong",
    description: "Eggplant braised in soy sauce, vinegar, and garlic.",
    servings: 3,
    tags: ["lunch", "dinner", "breakfast"],
    ingredients: [
      { name: "Talong (eggplant)", grams: 300 },
      { name: "Bawang (garlic)", grams: 10 },
      { name: "Toyo (soy sauce)", grams: 30 },
      { name: "Suka (vinegar)", grams: 30 },
      { name: "Asukal (sugar)", grams: 10 },
      { name: "Mantika (cooking oil)", grams: 20 },
    ],
    instructions: [
      "1. Slice the eggplant into 3-inch pieces, halved lengthwise, then fry in batches until lightly browned and tender, then set aside.",
      "2. In the same pan, sauté the garlic briefly in the remaining oil.",
      "3. Add the soy sauce, vinegar, and a little water, then bring to a boil.",
      "4. Pour in the vinegar and let it boil undisturbed for a minute before stirring, then stir in the brown sugar and simmer briefly.",
      "5. Return the fried eggplant to the pan, toss gently to coat, and simmer a couple more minutes until it soaks up the sauce.",
    ]
  },
  {
    name: "Gising-gising",
    description: "Ground pork and green beans simmered in spicy coconut milk with shrimp paste.",
    servings: 4,
    tags: ["ulam", "spicy", "vegetable"],
    ingredients: [
      { name: "Baboy (pork, kasim/shoulder)", grams: 225 },
      { name: "Baguio beans", grams: 150 },
      { name: "Gata (coconut milk)", grams: 200 },
      { name: "Bagoong alamang (shrimp paste)", grams: 30 },
      { name: "Siling labuyo (bird's eye chili)", grams: 15 },
      { name: "Bawang (garlic)", grams: 10 },
      { name: "Sibuyas (onion)", grams: 30 },
    ],
    instructions: [
      "1. Sauté bawang, sibuyas, and siling labuyo until fragrant.",
      "2. Add ground pork and cook until browned.",
      "3. Stir in shrimp paste and chopped chili.",
      "4. Pour in coconut milk, bring to a boil, and simmer for about 20 minutes.",
      "5. Add the baguio beans and cook a few more minutes until just tender, stirring occasionally.",
      "6. Serve hot with steamed rice.",
    ]
  },
  {
    name: "Ginataang Tilapia",
    description: "Tilapia simmered in coconut milk with vegetables and shrimp paste.",
    servings: 3,
    tags: ["all", "breakfast", "lunch", "dinner"],
    ingredients: [
      { name: "Tilapia", grams: 450 },
      { name: "Gata (coconut milk)", grams: 200 },
      { name: "Bagoong alamang (shrimp paste)", grams: 30 },
      { name: "Sili na mura (green finger chili)", grams: 15 },
      { name: "Bawang (garlic)", grams: 10 },
      { name: "Sibuyas (onion)", grams: 30 },
      { name: "Luya (ginger)", grams: 10 },
      { name: "Patis (fish sauce)", grams: 10 },
    ],
    instructions: [
      "1. Season and fry the tilapia until golden, then set aside.",
      "2. Sauté onion, garlic, and ginger until fragrant.",
      "3. Pour in coconut milk, bring to a boil, cover, and simmer briefly.",
      "4. Add the siling green and fried fish, cover, and simmer about 12 minutes.",
      "5. Season with fish sauce and pepper, then add pechay and cook just until wilted."
    ]
  },

  // DESSERTS & SNACKS
  {
    name: "Buko Pie",
    description: "A creamy coconut pie with tender young coconut meat in a flaky crust.",
    servings: 8,
    tags: ["snack", "dessert"],
    ingredients: [
      { name: "Harina (all-purpose flour)", grams: 250 },
      { name: "Mantikilya (butter)", grams: 75 },
      { name: "Shortening", grams: 75 },
      { name: "Buko (young coconut meat)", grams: 400 },
      { name: "Asukal (sugar)", grams: 150 },
      { name: "Gawgaw (cornstarch)", grams: 60 },
      { name: "Evaporated milk (evaporada)", grams: 120 },
      { name: "Asin (salt)", grams: 3 },
    ],
    instructions: [
      "1. Combine flour and salt, then cut in butter and shortening until crumbly.",
      "2. Add cold water gradually to form a dough, then chill and roll out to line a pie pan.",
      "3. In a saucepan, mix coconut meat, sugar, cornstarch, and evaporated milk. Cook until thickened.",
      "4. Pour filling into the crust and bake at 190°C until golden and set.",
      "5. Cool completely before slicing."
    ]
  },
  {
    name: "Egg Pie",
    description: "A rich and creamy custard pie with a smooth egg filling.",
    servings: 8,
    tags: ["snack", "dessert"],
    ingredients: [
      { name: "Pie crust", grams: 250 },
      { name: "Itlog (egg)", grams: 250 },
      { name: "Evaporated milk (evaporada)", grams: 370 },
      { name: "Condensed milk (condensada)", grams: 390 },
      { name: "Asukal (sugar)", grams: 100 },
      { name: "Vanilla extract", grams: 5 },
    ],
    instructions: [
      "1. Blind-bake the pie crust until lightly golden and set aside.",
      "2. Beat eggs gently, then add evaporated milk, condensed milk, sugar, and vanilla.",
      "3. Pour the custard into the pre-baked crust.",
      "4. Bake at 175°C until the custard is set and the top is golden.",
      "5. Cool and refrigerate before serving."
    ]
  },
  {
    name: "Taho",
    description: "Silken tofu with sago pearls and warm brown sugar syrup.",
    servings: 4,
    tags: ["snack", "dessert"],
    ingredients: [
      { name: "Silken tofu", grams: 500 },
      { name: "Sago pearls", grams: 100 },
      { name: "Asukal (sugar)", grams: 150 },
      { name: "Pandan leaf", grams: 5 },
    ],
    instructions: [
      "1. Cook sago pearls according to package directions, then drain and set aside.",
      "2. Simmer brown sugar, water, and pandan leaf until a syrup forms.",
      "3. Gently warm the silken tofu without boiling.",
      "4. Scoop warm tofu into a bowl, add sago, and drizzle with syrup."
    ]
  },
  {
    name: "Puto Bumbong",
    description: "Purple glutinous rice steamed in bamboo tubes, topped with coconut and sugar.",
    servings: 6,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Sticky purple rice", grams: 200 },
      { name: "Malagkit (glutinous rice)", grams: 200 },
      { name: "Purple rice", grams: 100 },
      { name: "Muscovado sugar", grams: 150 },
      { name: "Niyog (grated coconut)", grams: 150 },
      { name: "Mantikilya (butter)", grams: 30 },
    ],
    instructions: [
      "1. Soak all rice varieties in water for at least 2 days, then drain.",
      "2. Grind the soaked rice until fine.",
      "3. Pack into bamboo tubes lined with banana leaves and steam until cooked.",
      "4. Remove onto banana leaves, then top with butter, grated coconut, and muscovado sugar."
    ]
  },
  {
    name: "Leche Puto",
    description: "Steamed puto topped with a layer of creamy leche flan.",
    servings: 8,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Harina (all-purpose flour)", grams: 100 },
      { name: "Baking powder", grams: 10 },
      { name: "Asukal (sugar)", grams: 80 },
      { name: "Evaporated milk (evaporada)", grams: 180 },
      { name: "Itlog (egg)", grams: 150 },
      { name: "Condensed milk (condensada)", grams: 390 },
      { name: "Vanilla extract", grams: 5 },
    ],
    instructions: [
      "1. Bring water in a steamer to a boil.",
      "2. Beat egg yolks, gradually add condensed milk, and add vanilla to make the leche flan.",
      "3. Fill molds halfway with leche flan and steam for 25 minutes, then cool.",
      "4. Combine flour, sugar, and baking powder, then add milk to make the puto batter.",
      "5. Pour puto batter over the steamed leche flan and steam again for 30–35 minutes.",
      "6. Cool completely before removing from molds."
    ]
  },
  {
    name: "Ube Pichi-Pichi",
    description: "Steamed cassava cakes flavored with ube and coated in grated coconut.",
    servings: 10,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Kamoteng kahoy (cassava)", grams: 800 },
      { name: "Asukal (sugar)", grams: 200 },
      { name: "Lihiya (lye water)", grams: 5 },
      { name: "Ube flavoring", grams: 5 },
      { name: "Niyog (grated coconut)", grams: 150 },
    ],
    instructions: [
      "1. Combine grated cassava, water, sugar, lye water, and ube flavoring.",
      "2. Pour into small molds and steam for 60 minutes.",
      "3. Cool completely until sticky.",
      "4. Roll each piece in grated coconut and serve."
    ]
  },
  {
    name: "Nilupak",
    description: "Mashed cassava mixed with coconut, butter, and condensed milk.",
    servings: 6,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Kamoteng kahoy (cassava)", grams: 1000 },
      { name: "Condensed milk (condensada)", grams: 390 },
      { name: "Mantikilya (butter)", grams: 100 },
      { name: "Niyog (grated coconut)", grams: 100 },
    ],
    instructions: [
      "1. Boil cassava until tender, then drain and mash while hot.",
      "2. Add condensed milk, butter, and grated coconut. Mix well.",
      "3. Adjust sweetness with sugar if desired.",
      "4. Shape into desired forms and top with more grated coconut."
    ]
  },
  {
    name: "Ginataang Munggo",
    description: "Toasted mung beans and sticky rice simmered in sweet coconut milk.",
    servings: 4,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Mung beans (munggo)", grams: 100 },
      { name: "Kakang gata (coconut cream)", grams: 500 },
      { name: "Malagkit (glutinous rice)", grams: 100 },
      { name: "Asukal (sugar)", grams: 100 },
    ],
    instructions: [
      "1. Toast mung beans until brown, then crack using a mortar and pestle.",
      "2. Bring coconut milk to a boil in a pot.",
      "3. Add sticky rice and toasted mung beans, then simmer for 15–20 minutes.",
      "4. Add sugar, stir, and remove from heat.",
      "5. Serve warm or cold."
    ]
  },
  {
    name: "Puto Cake",
    description: "A soft steamed cake topped with salted egg slices.",
    servings: 6,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Cake flour", grams: 220 },
      { name: "Asukal (sugar)", grams: 150 },
      { name: "Baking powder", grams: 12 },
      { name: "Asin (salt)", grams: 2 },
      { name: "Evaporated milk (evaporada)", grams: 360 },
      { name: "Itlog (egg)", grams: 100 },
      { name: "Maalat na itlog (salted egg)", grams: 60 },
      { name: "Vanilla extract", grams: 5 },
    ],
    instructions: [
      "1. Sift dry ingredients together and mix well.",
      "2. Gradually add milk while whisking, then add eggs and vanilla.",
      "3. Pour into a mold and steam for 12 minutes.",
      "4. Top with salted egg slices and steam for another 18 minutes.",
      "5. Cool before removing from mold."
    ]
  },
  {
    name: "Binignit",
    description: "A warm Visayan dessert soup of root crops, bananas, and sago in coconut milk.",
    servings: 6,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Kamote (sweet potato)", grams: 200 },
      { name: "Ube (purple yam)", grams: 200 },
      { name: "Saging na saba (plantain)", grams: 200 },
      { name: "Muscovado sugar", grams: 200 },
      { name: "Gata (coconut milk)", grams: 800 },
      { name: "Langka (jackfruit)", grams: 150 },
      { name: "Gabi (taro)", grams: 150 },
      { name: "Sago pearls", grams: 150 },
      { name: "Glutinous rice flour", grams: 20 },
    ],
    instructions: [
      "1. Combine coconut milk and water in a pot and bring to a boil.",
      "2. Add sweet potato, purple yam, saba banana, jackfruit, and taro. Cook for 8–10 minutes.",
      "3. Add muscovado sugar and sago pearls, then cook for another 8 minutes.",
      "4. Dilute glutinous rice flour in water and pour into the pot, stirring.",
      "5. Continue cooking until all tubers are soft. Serve warm."
    ]
  },
  {
    name: "Chocolate Biko",
    description: "Sweet glutinous rice cooked with coconut milk and cacao tablea.",
    servings: 6,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Malagkit (glutinous rice)", grams: 300 },
      { name: "Gata (coconut milk)", grams: 400 },
      { name: "Asukal (sugar)", grams: 150 },
      { name: "Cacao tablea", grams: 60 },
      { name: "Asin (salt)", grams: 2 },
    ],
    instructions: [
      "1. Combine coconut milk and cacao tablea in a pot and stir until dissolved.",
      "2. Add glutinous rice, sugar, and salt. Stir and cover.",
      "3. Cook over low heat until the rice absorbs half the liquid.",
      "4. Stir occasionally until the liquid is fully absorbed and rice is cooked.",
      "5. Transfer to a greased dish and cool before serving."
    ]
  },
  {
    name: "Ube Biko",
    description: "Glutinous rice cooked with ube and coconut milk, topped with latik.",
    servings: 6,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Malagkit (glutinous rice)", grams: 300 },
      { name: "Asukal (sugar)", grams: 200 },
      { name: "Ube halaya", grams: 200 },
      { name: "Gata (coconut milk)", grams: 400 },
      { name: "Asin (salt)", grams: 2 },
      { name: "Latik", grams: 50 },
    ],
    instructions: [
      "1. Cook glutinous rice with water and coconut milk until done.",
      "2. In a separate pan, combine coconut milk, sugar, and ube halaya.",
      "3. Add cooked rice to the ube mixture and cook until liquid is absorbed.",
      "4. Transfer to a serving dish and top with latik."
    ]
  },
  {
    name: "Royal Bibingka",
    description: "A rich and creamy baked rice cake topped with cheese and salted egg.",
    servings: 8,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Glutinous rice flour", grams: 180 },
      { name: "Rice flour", grams: 60 },
      { name: "Gata (coconut milk)", grams: 480 },
      { name: "Asukal (sugar)", grams: 200 },
      { name: "Evaporated milk (evaporada)", grams: 80 },
      { name: "Mantikilya (butter)", grams: 100 },
      { name: "Itlog (egg)", grams: 250 },
      { name: "Keso (cheese)", grams: 100 },
      { name: "Maalat na itlog (salted egg)", grams: 60 },
    ],
    instructions: [
      "1. Preheat oven to 175°C.",
      "2. Combine glutinous rice flour, rice flour, and sugar.",
      "3. Add coconut milk, evaporated milk, melted butter, and eggs. Stir until smooth.",
      "4. Pour into a greased pan and bake for 30–40 minutes.",
      "5. Top with cheese and salted egg, then bake for another 5–10 minutes.",
      "6. Cool before slicing."
    ]
  },
  {
    name: "Bibingkang Malagkit",
    description: "Sweet sticky rice baked with a caramelized coconut cream topping.",
    servings: 8,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Malagkit (glutinous rice)", grams: 400 },
      { name: "Asukal (sugar)", grams: 300 },
      { name: "Gata (coconut milk)", grams: 800 },
      { name: "Kakang gata (coconut cream)", grams: 400 },
      { name: "Asin (salt)", grams: 3 },
      { name: "Dahon ng saging (banana leaves)", grams: 50 },
    ],
    instructions: [
      "1. Cook glutinous rice with coconut milk, stirring occasionally.",
      "2. Add salt and half the sugar, then continue cooking until rice is done.",
      "3. Line a baking pan with banana leaves and spread the rice evenly.",
      "4. Combine coconut cream and remaining sugar, then simmer until reduced.",
      "5. Pour over the rice and bake at 190°C until topping is set.",
      "6. Cool for 30 minutes before serving."
    ]
  },
  {
    name: "Pastimallow",
    description: "Marshmallows wrapped in a sweet milk dough and coated with sugar.",
    servings: 8,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Marshmallows", grams: 200 },
      { name: "Powdered milk (gatas na pulbos)", grams: 200 },
      { name: "Condensed milk (condensada)", grams: 390 },
      { name: "Mantikilya (butter)", grams: 30 },
      { name: "Asukal (sugar)", grams: 100 },
    ],
    instructions: [
      "1. Combine powdered milk, condensed milk, and melted butter to form a dough.",
      "2. Flatten a portion of dough and wrap around a marshmallow.",
      "3. Roll into a ball and coat with sugar.",
      "4. Repeat with remaining ingredients and chill before serving."
    ]
  },
  {
    name: "Cathedral Window Gelatin",
    description: "A colorful gelatin dessert with cubes of flavored gelatin in a creamy base.",
    servings: 10,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Colored gelatin", grams: 300 },
      { name: "All-purpose cream", grams: 250 },
      { name: "Condensed milk (condensada)", grams: 390 },
      { name: "Pinya (pineapple)", grams: 200 },
      { name: "Gelatin powder (unflavored)", grams: 30 },
    ],
    instructions: [
      "1. Prepare colored gelatin according to package directions, let set, then cut into cubes.",
      "2. Bloom unflavored gelatin in water for 5 minutes.",
      "3. Heat pineapple juice and dissolve bloomed gelatin in it.",
      "4. Combine whipping cream, condensed milk, and pineapple juice mixture.",
      "5. Fold in colored gelatin cubes, pour into a mold, and refrigerate until set."
    ]
  },
  {
    name: "Fruit Cocktail Float",
    description: "A layered dessert of graham crackers, cream, and fruit cocktail.",
    servings: 8,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Fruit cocktail", grams: 400 },
      { name: "Graham crackers", grams: 200 },
      { name: "All-purpose cream", grams: 250 },
      { name: "Condensed milk (condensada)", grams: 390 },
    ],
    instructions: [
      "1. Drain fruit cocktail well.",
      "2. Combine all-purpose cream and condensed milk.",
      "3. Layer crushed graham crackers, cream mixture, and fruit cocktail in a dish.",
      "4. Repeat layers and top with crushed graham.",
      "5. Chill for at least 4 hours before serving."
    ]
  },
  {
    name: "Filipino Fruit Salad",
    description: "A creamy chilled salad of fruit cocktail, nata de coco, and kaong.",
    servings: 8,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Fruit cocktail", grams: 800 },
      { name: "Nata de coco", grams: 300 },
      { name: "Kaong", grams: 300 },
      { name: "All-purpose cream", grams: 250 },
      { name: "Condensed milk (condensada)", grams: 200 },
      { name: "Keso (cheese)", grams: 100 },
    ],
    instructions: [
      "1. Drain all canned and jarred fruits thoroughly.",
      "2. Combine fruit cocktail, nata de coco, and kaong in a bowl.",
      "3. Add all-purpose cream and condensed milk, then fold gently.",
      "4. Add cheese cubes if desired.",
      "5. Chill for at least 4 hours before serving."
    ]
  },
  {
    name: "Buko Ice Candy",
    description: "Frozen coconut ice candy made with young coconut and milk.",
    servings: 10,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Buko (young coconut meat)", grams: 300 },
      { name: "Coconut water", grams: 300 },
      { name: "Evaporated milk (evaporada)", grams: 200 },
      { name: "Condensed milk (condensada)", grams: 200 },
      { name: "Asukal (sugar)", grams: 100 },
    ],
    instructions: [
      "1. Combine coconut water, evaporated milk, condensed milk, and sugar.",
      "2. Stir until sugar dissolves, then add shredded coconut meat.",
      "3. Pour into ice candy bags or molds.",
      "4. Freeze until solid."
    ]
  },
  {
    name: "Peanut Brittle",
    description: "Crunchy caramelized peanuts with a hint of butter.",
    servings: 8,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Mani (peanuts)", grams: 200 },
      { name: "Asukal (sugar)", grams: 200 },
      { name: "Corn syrup", grams: 150 },
      { name: "Mantikilya (butter)", grams: 30 },
      { name: "Baking soda", grams: 5 },
    ],
    instructions: [
      "1. Combine sugar and corn syrup in a saucepan and cook until dissolved.",
      "2. Continue cooking until hard crack stage (150°C).",
      "3. Stir in peanuts and butter.",
      "4. Remove from heat and quickly stir in baking soda.",
      "5. Pour onto a greased sheet, spread thinly, and cool before breaking into pieces."
    ]
  },
  {
    name: "Tikoy",
    description: "A sweet glutinous rice cake, sliced and pan-fried until golden.",
    servings: 8,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Glutinous rice flour", grams: 300 },
      { name: "Asukal (sugar)", grams: 200 },
      { name: "Powdered milk (gatas na pulbos)", grams: 50 },
      { name: "Asin (salt)", grams: 2 },
      { name: "Linga (sesame seeds)", grams: 20 },
      { name: "Mantika (cooking oil)", grams: 100 },
    ],
    instructions: [
      "1. Mix glutinous rice flour, sugar, powdered milk, and salt.",
      "2. Gradually add water and stir until a smooth batter forms.",
      "3. Pour into a greased pan and steam for about 1 hour.",
      "4. Cool completely, then slice into serving pieces.",
      "5. Pan-fry in oil until golden brown and sprinkle with sesame seeds."
    ]
  },
  {
    name: "Cheese Puffs",
    description: "Flaky puff pastry filled with melted cheddar cheese.",
    servings: 6,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Puff pastry", grams: 400 },
      { name: "Keso (cheese)", grams: 150 },
      { name: "Itlog (egg)", grams: 50 },
    ],
    instructions: [
      "1. Preheat oven to 190°C.",
      "2. Cut puff pastry into squares.",
      "3. Place cheese in the center of each square, fold over, and seal.",
      "4. Brush tops with beaten egg.",
      "5. Bake for 15–20 minutes until golden and puffed."
    ]
  },
  {
    name: "Bibingka Muffins",
    description: "Individual bibingka muffins topped with cheese and salted egg.",
    servings: 12,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Glutinous rice flour", grams: 240 },
      { name: "Baking powder", grams: 8 },
      { name: "Asin (salt)", grams: 2 },
      { name: "Itlog (egg)", grams: 250 },
      { name: "Asukal (sugar)", grams: 200 },
      { name: "Margarine", grams: 80 },
      { name: "Gata (coconut milk)", grams: 480 },
      { name: "Vanilla extract", grams: 5 },
      { name: "Maalat na itlog (salted egg)", grams: 60 },
      { name: "Keso (cheese)", grams: 100 },
    ],
    instructions: [
      "1. Preheat oven to 190°C.",
      "2. Combine glutinous rice flour, salt, and baking powder.",
      "3. Beat eggs, add sugar, then add vanilla.",
      "4. Combine egg mixture with flour mixture and stir until smooth.",
      "5. Scoop into muffin cups and bake for 28 minutes.",
      "6. Spread margarine on top, add cheese and salted egg, then bake for another 3–5 minutes."
    ]
  },
  {
    name: "Banana Chips",
    description: "Thinly sliced saba bananas fried until crispy and coated with sugar.",
    servings: 6,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Saging na saba (plantain)", grams: 500 },
      { name: "Mantika (cooking oil)", grams: 300 },
      { name: "Asukal (sugar)", grams: 100 },
      { name: "Asin (salt)", grams: 3 },
    ],
    instructions: [
      "1. Peel bananas and soak in cold water.",
      "2. Slice thinly using a mandoline.",
      "3. Heat oil and fry banana slices until golden and crispy.",
      "4. Drain on paper towels.",
      "5. Sprinkle with sugar and salt while warm."
    ]
  },
  {
    name: "Banana Muffins",
    description: "Moist and fluffy muffins made with ripe bananas.",
    servings: 12,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Saging na hinog (ripe banana)", grams: 300 },
      { name: "Harina (all-purpose flour)", grams: 220 },
      { name: "Asukal (sugar)", grams: 150 },
      { name: "Itlog (egg)", grams: 50 },
      { name: "Mantikilya (butter)", grams: 75 },
      { name: "Baking soda", grams: 5 },
      { name: "Asin (salt)", grams: 2 },
    ],
    instructions: [
      "1. Preheat oven to 175°C.",
      "2. Mash bananas, then add sugar, egg, and melted butter.",
      "3. Combine flour, baking soda, and salt in a separate bowl.",
      "4. Fold dry ingredients into wet mixture.",
      "5. Pour into greased muffin cups and bake for 20–25 minutes."
    ]
  },
  {
    name: "Banana Nut Muffins",
    description: "Banana muffins with crunchy walnuts or peanuts.",
    servings: 12,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Saging na hinog (ripe banana)", grams: 300 },
      { name: "Harina (all-purpose flour)", grams: 220 },
      { name: "Asukal (sugar)", grams: 150 },
      { name: "Itlog (egg)", grams: 50 },
      { name: "Mantikilya (butter)", grams: 75 },
      { name: "Walnuts", grams: 80 },
      { name: "Baking soda", grams: 5 },
      { name: "Asin (salt)", grams: 2 },
    ],
    instructions: [
      "1. Preheat oven to 175°C.",
      "2. Combine mashed bananas, sugar, egg, and melted butter.",
      "3. Mix flour, baking soda, and salt in another bowl.",
      "4. Fold dry ingredients into wet mixture, then add nuts.",
      "5. Pour into greased muffin cups and bake for 20–25 minutes."
    ]
  },
  {
    name: "Banana Cream Pie",
    description: "A creamy banana custard pie topped with whipped cream.",
    servings: 8,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Pie crust", grams: 250 },
      { name: "Saging na hinog (ripe banana)", grams: 300 },
      { name: "Fresh milk (gatas)", grams: 480 },
      { name: "Asukal (sugar)", grams: 150 },
      { name: "Itlog (egg)", grams: 200 },
      { name: "Gawgaw (cornstarch)", grams: 30 },
      { name: "Vanilla extract", grams: 5 },
      { name: "Whipped cream", grams: 200 },
    ],
    instructions: [
      "1. Bake pie crust and let cool.",
      "2. Combine sugar, cornstarch, and milk in a saucepan and cook until thickened.",
      "3. Temper egg yolks, return to pan, and cook for 2 more minutes. Add vanilla.",
      "4. Arrange sliced bananas on the crust and pour custard over them.",
      "5. Chill for 4 hours, then top with whipped cream."
    ]
  },
  {
    name: "Mamon",
    description: "Light and fluffy sponge cakes topped with butter and sugar.",
    servings: 8,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Cake flour", grams: 120 },
      { name: "Baking powder", grams: 6 },
      { name: "Asin (salt)", grams: 2 },
      { name: "Itlog (egg)", grams: 200 },
      { name: "Asukal (sugar)", grams: 150 },
      { name: "Fresh milk (gatas)", grams: 60 },
      { name: "Mantikilya (butter)", grams: 60 },
      { name: "Vanilla extract", grams: 5 },
    ],
    instructions: [
      "1. Preheat oven to 175°C.",
      "2. Sift cake flour, baking powder, and salt.",
      "3. Beat egg whites until soft peaks, gradually add sugar, then add egg yolks.",
      "4. Fold in flour mixture alternately with milk and melted butter. Add vanilla.",
      "5. Pour into greased molds and bake for 15–20 minutes."
    ]
  },
  {
    name: "Brazo de Mercedes",
    description: "A rolled meringue cake filled with rich custard.",
    servings: 8,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Itlog (egg)", grams: 400 },
      { name: "Asukal (sugar)", grams: 200 },
      { name: "Condensed milk (condensada)", grams: 390 },
      { name: "Vanilla extract", grams: 5 },
      { name: "Lemon", grams: 20 },
      { name: "Cream of tartar", grams: 3 },
    ],
    instructions: [
      "1. Preheat oven to 175°C and line a baking sheet with parchment.",
      "2. Beat egg whites and cream of tartar until soft peaks, then gradually add sugar until stiff.",
      "3. Spread meringue onto the sheet and bake for 15–20 minutes.",
      "4. Combine egg yolks, condensed milk, vanilla, and lemon juice in a double boiler and cook until thick.",
      "5. Spread filling over cooled meringue, roll, and chill before slicing."
    ]
  },
  {
    name: "Custard Cake",
    description: "A layered cake with custard and caramel, topped with meringue.",
    servings: 10,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Asukal (sugar)", grams: 300 },
      { name: "Itlog (egg)", grams: 500 },
      { name: "Condensed milk (condensada)", grams: 390 },
      { name: "Evaporated milk (evaporada)", grams: 240 },
      { name: "Cake flour", grams: 180 },
      { name: "Baking powder", grams: 5 },
      { name: "Fresh milk (gatas)", grams: 60 },
      { name: "Lemon", grams: 10 },
      { name: "Cream of tartar", grams: 3 },
      { name: "Vanilla extract", grams: 5 },
    ],
    instructions: [
      "1. Melt sugar in a baking pan until golden to make caramel. Set aside.",
      "2. Combine eggs, condensed milk, evaporated milk, and sugar for the custard. Pour over caramel.",
      "3. Beat egg yolks with sugar, add flour alternately with milk, and add lemon rind.",
      "4. Beat egg whites with cream of tartar and sugar until stiff, then fold into batter.",
      "5. Pour batter over custard and bake in a water bath at 175°C for about 1 hour.",
      "6. Cool and refrigerate before serving."
    ]
  },
  {
    name: "Crema de Fruta",
    description: "A layered dessert of graham crackers, custard, fruit, and gelatin.",
    servings: 10,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Graham crackers", grams: 200 },
      { name: "Fruit cocktail", grams: 400 },
      { name: "Condensed milk (condensada)", grams: 390 },
      { name: "Gelatin powder (unflavored)", grams: 30 },
      { name: "All-purpose cream", grams: 250 },
    ],
    instructions: [
      "1. Arrange a layer of graham crackers in a dish.",
      "2. Top with custard and fruit cocktail. Repeat layers.",
      "3. Prepare gelatin according to package directions and pour over the top.",
      "4. Chill until set.",
      "5. Top with all-purpose cream before serving."
    ]
  },
  {
    name: "Jelly Roll",
    description: "A light sponge cake rolled with jam or jelly.",
    servings: 8,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Cake flour", grams: 90 },
      { name: "Itlog (egg)", grams: 200 },
      { name: "Asukal (sugar)", grams: 150 },
      { name: "Fresh milk (gatas)", grams: 60 },
      { name: "Baking powder", grams: 5 },
      { name: "Jam/jelly", grams: 150 },
    ],
    instructions: [
      "1. Preheat oven to 190°C and line a jelly roll pan with parchment.",
      "2. Beat eggs and sugar until light and fluffy.",
      "3. Fold in cake flour and baking powder, then add milk.",
      "4. Pour into pan and bake for 10–12 minutes.",
      "5. Turn onto a sugared towel, roll while warm, then cool, unroll, spread with jam, and re-roll."
    ]
  },
  {
    name: "Peach Mango Pie",
    description: "A sweet pie filled with peaches and mangoes.",
    servings: 8,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Pie crust", grams: 400 },
      { name: "Peaches", grams: 200 },
      { name: "Mangga (mango)", grams: 200 },
      { name: "Asukal (sugar)", grams: 100 },
      { name: "Gawgaw (cornstarch)", grams: 15 },
      { name: "Mantikilya (butter)", grams: 15 },
      { name: "Asin (salt)", grams: 2 },
    ],
    instructions: [
      "1. Preheat oven to 190°C.",
      "2. Combine peaches, mangoes, sugar, cornstarch, and salt.",
      "3. Line a pie pan with one crust, pour in filling, and dot with butter.",
      "4. Cover with second crust, seal, and cut slits on top.",
      "5. Bake for 35–40 minutes until golden and bubbly.",
      "6. Cool before slicing."
    ]
  },
  {
    name: "Peach Mango Nuggets",
    description: "Crispy lumpia-wrapped nuggets filled with peach, mango, and cream cheese.",
    servings: 8,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Mangga (mango)", grams: 200 },
      { name: "Peaches", grams: 200 },
      { name: "Cream cheese", grams: 150 },
      { name: "Graham crackers", grams: 100 },
      { name: "Lumpia wrappers", grams: 200 },
      { name: "Asukal (sugar)", grams: 100 },
    ],
    instructions: [
      "1. Mix diced mangoes, peaches, and cream cheese.",
      "2. Place a spoonful onto a lumpia wrapper and sprinkle with crushed graham.",
      "3. Fold and roll to seal.",
      "4. Fry in hot oil until golden and crispy.",
      "5. Drain and roll in sugar while warm."
    ]
  },
  {
    name: "Macaroni Fruit Salad",
    description: "A creamy fruit salad with elbow macaroni and cheese.",
    servings: 10,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Elbow macaroni", grams: 200 },
      { name: "Fruit cocktail", grams: 400 },
      { name: "Nata de coco", grams: 200 },
      { name: "Kaong", grams: 200 },
      { name: "All-purpose cream", grams: 250 },
      { name: "Condensed milk (condensada)", grams: 200 },
      { name: "Keso (cheese)", grams: 100 },
    ],
    instructions: [
      "1. Cook macaroni according to package directions, then drain and cool.",
      "2. Combine macaroni, fruit cocktail, nata de coco, and kaong.",
      "3. Add all-purpose cream and condensed milk, then mix well.",
      "4. Add cheese if desired.",
      "5. Chill for at least 4 hours."
    ]
  },
  {
    name: "Pastillas-Covered Marshmallows",
    description: "Marshmallows wrapped in sweet milk pastillas and coated with sugar.",
    servings: 10,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Marshmallows", grams: 200 },
      { name: "Powdered milk (gatas na pulbos)", grams: 200 },
      { name: "Condensed milk (condensada)", grams: 390 },
      { name: "Asukal (sugar)", grams: 100 },
      { name: "Gawgaw (cornstarch)", grams: 20 },
    ],
    instructions: [
      "1. Combine powdered milk and condensed milk to form a dough.",
      "2. Flatten a portion and wrap around a marshmallow.",
      "3. Roll into a ball and coat with sugar.",
      "4. Lightly dust with cornstarch.",
      "5. Repeat and chill before serving."
    ]
  },
  {
    name: "Steamed Cassava Cake",
    description: "A moist steamed cake made from grated cassava and coconut milk.",
    servings: 10,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Kamoteng kahoy (cassava)", grams: 700 },
      { name: "Gata (coconut milk)", grams: 240 },
      { name: "Condensed milk (condensada)", grams: 390 },
      { name: "Itlog (egg)", grams: 100 },
      { name: "Mantikilya (butter)", grams: 90 },
    ],
    instructions: [
      "1. Combine grated cassava, coconut milk, condensed milk, eggs, and melted butter.",
      "2. Pour into a greased mold.",
      "3. Steam for 45–55 minutes until set.",
      "4. Cool before slicing.",
      "5. Serve with butter or sugar if desired."
    ]
  },
  {
    name: "Caramelized Butternut Squash",
    description: "Sweet and buttery caramelized butternut squash with cinnamon.",
    servings: 4,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Kalabasa (squash)", grams: 500 },
      { name: "Asukal (sugar)", grams: 100 },
      { name: "Mantikilya (butter)", grams: 50 },
      { name: "Cinnamon", grams: 3 },
      { name: "Asin (salt)", grams: 2 },
    ],
    instructions: [
      "1. Melt butter in a pan over medium heat.",
      "2. Add squash cubes and cook until slightly tender.",
      "3. Sprinkle with brown sugar, cinnamon, and salt.",
      "4. Continue cooking until caramelized and tender.",
      "5. Serve warm."
    ]
  },
  {
    name: "Sweet Potato Pie",
    description: "A spiced pie filled with mashed sweet potatoes.",
    servings: 8,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Kamote (sweet potato)", grams: 500 },
      { name: "Pie crust", grams: 250 },
      { name: "Itlog (egg)", grams: 100 },
      { name: "Evaporated milk (evaporada)", grams: 200 },
      { name: "Asukal (sugar)", grams: 150 },
      { name: "Cinnamon", grams: 3 },
      { name: "Mantikilya (butter)", grams: 60 },
    ],
    instructions: [
      "1. Preheat oven to 175°C.",
      "2. Combine mashed sweet potatoes, condensed milk, melted butter, eggs, and cinnamon.",
      "3. Pour into prepared pie crust.",
      "4. Bake for 45–50 minutes until set.",
      "5. Cool before serving."
    ]
  },
  {
    name: "Latik",
    description: "Caramelized coconut cream used as a topping for rice cakes.",
    servings: 6,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Kakang gata (coconut cream)", grams: 400 },
      { name: "Asukal (sugar)", grams: 100 },
    ],
    instructions: [
      "1. Simmer coconut cream in a pan over medium heat.",
      "2. Stir occasionally until oil separates and solids turn golden.",
      "3. Add brown sugar and cook until thickened and caramelized.",
      "4. Use as a topping for rice cakes and desserts."
    ]
  },
  {
    name: "No-Steam Easy Flan",
    description: "A simple baked custard flan without steaming.",
    servings: 6,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Itlog (egg)", grams: 300 },
      { name: "Condensed milk (condensada)", grams: 390 },
      { name: "Evaporated milk (evaporada)", grams: 240 },
      { name: "Asukal (sugar)", grams: 100 },
      { name: "Vanilla extract", grams: 5 },
    ],
    instructions: [
      "1. Combine egg yolks, condensed milk, evaporated milk, sugar, and vanilla.",
      "2. Pour into a mold or baking dish.",
      "3. Bake in a water bath at 175°C for 45–50 minutes until set.",
      "4. Cool and refrigerate before serving."
    ]
  },
  {
    name: "Macapuno Balls",
    description: "Sweet macapuno balls coated in powdered milk.",
    servings: 8,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Macapuno strings", grams: 200 },
      { name: "Condensed milk (condensada)", grams: 200 },
      { name: "Gawgaw (cornstarch)", grams: 40 },
      { name: "Powdered milk (gatas na pulbos)", grams: 100 },
    ],
    instructions: [
      "1. Combine macapuno, condensed milk, cornstarch, and water in a saucepan.",
      "2. Cook over low heat, stirring constantly until thick.",
      "3. Cool slightly, then shape into balls.",
      "4. Roll in powdered milk and chill before serving."
    ]
  },
  {
    name: "Hopia",
    description: "Flaky pastry filled with mung bean or ube filling.",
    servings: 10,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Harina (all-purpose flour)", grams: 250 },
      { name: "Asukal (sugar)", grams: 30 },
      { name: "Shortening", grams: 80 },
      { name: "Asin (salt)", grams: 2 },
      { name: "Mung beans (munggo)", grams: 200 },
      { name: "Mantika (cooking oil)", grams: 30 },
    ],
    instructions: [
      "1. Combine flour, sugar, and salt, then cut in shortening. Add water to form a dough and rest for 30 minutes.",
      "2. Cook mung bean paste with sugar and oil until thickened. Cool.",
      "3. Divide dough, flatten, and fill with mung bean or ube filling.",
      "4. Seal, shape into balls, and flatten slightly.",
      "5. Pan-fry over low heat until golden on both sides."
    ]
  },
  {
    name: "Taisan",
    description: "A buttery Filipino sponge cake topped with cheese.",
    servings: 8,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Cake flour", grams: 120 },
      { name: "Itlog (egg)", grams: 200 },
      { name: "Asukal (sugar)", grams: 150 },
      { name: "Mantikilya (butter)", grams: 60 },
      { name: "Fresh milk (gatas)", grams: 60 },
      { name: "Keso (cheese)", grams: 80 },
    ],
    instructions: [
      "1. Preheat oven to 175°C.",
      "2. Beat eggs and sugar until light and fluffy.",
      "3. Fold in cake flour, butter, and milk.",
      "4. Pour batter into a greased pan and top with grated cheese.",
      "5. Bake for 20–25 minutes until golden.",
      "6. Cool and slice."
    ]
  },
  {
    name: "Mango Bars",
    description: "Sweet and tangy mango bars with a buttery crumb topping.",
    servings: 10,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Mangga (mango)", grams: 400 },
      { name: "Harina (all-purpose flour)", grams: 180 },
      { name: "Mantikilya (butter)", grams: 150 },
      { name: "Asukal (sugar)", grams: 150 },
      { name: "Itlog (egg)", grams: 100 },
      { name: "Condensed milk (condensada)", grams: 200 },
    ],
    instructions: [
      "1. Preheat oven to 175°C.",
      "2. Cream butter and sugar, add eggs, then add flour to form a dough.",
      "3. Press half the dough into a greased baking pan.",
      "4. Spread mangoes and condensed milk over the crust.",
      "5. Crumble the remaining dough over the top.",
      "6. Bake for 30–35 minutes until golden. Cool and cut into bars."
    ]
  },
  {
    name: "Calamansi Pie",
    description: "A tangy calamansi custard pie with whipped cream topping.",
    servings: 8,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Pie crust", grams: 250 },
      { name: "Calamansi", grams: 120 },
      { name: "Condensed milk (condensada)", grams: 390 },
      { name: "Itlog (egg)", grams: 200 },
      { name: "Whipped cream", grams: 150 },
    ],
    instructions: [
      "1. Bake the pie crust and let cool.",
      "2. Combine calamansi juice, condensed milk, and egg yolks.",
      "3. Pour into the crust and bake at 175°C for 20–25 minutes until set.",
      "4. Cool and top with whipped cream before serving."
    ]
  },
  {
    name: "Pianono",
    description: "A rolled sponge cake filled with jam or ube halaya.",
    servings: 8,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Cake flour", grams: 90 },
      { name: "Itlog (egg)", grams: 300 },
      { name: "Asukal (sugar)", grams: 150 },
      { name: "Mantikilya (butter)", grams: 60 },
      { name: "Fresh milk (gatas)", grams: 60 },
      { name: "Ube halaya", grams: 200 },
    ],
    instructions: [
      "1. Preheat oven to 190°C and line a jelly roll pan with parchment.",
      "2. Beat egg whites until stiff, gradually add sugar.",
      "3. Add egg yolks one at a time.",
      "4. Fold in cake flour, butter, and milk.",
      "5. Pour into pan and bake for 12–15 minutes.",
      "6. Turn onto a sugared towel, roll while warm, then cool, unroll, spread with ube halaya, and re-roll."
    ]
  },
  {
    name: "Mango Sago",
    description: "A chilled mango dessert with sago pearls and creamy milk.",
    servings: 6,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Mangga (mango)", grams: 400 },
      { name: "Sago pearls", grams: 150 },
      { name: "Condensed milk (condensada)", grams: 200 },
      { name: "All-purpose cream", grams: 250 },
      { name: "Evaporated milk (evaporada)", grams: 120 },
    ],
    instructions: [
      "1. Cook sago pearls according to package directions, then drain.",
      "2. Combine condensed milk, all-purpose cream, and evaporated milk.",
      "3. Add cooked sago and diced mangoes, then stir gently.",
      "4. Chill for at least 2 hours before serving."
    ]
  },
  {
    name: "Buko Pandan",
    description: "A chilled coconut and pandan gelatin dessert with cream.",
    servings: 8,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Buko (young coconut meat)", grams: 300 },
      { name: "Colored gelatin", grams: 150 },
      { name: "Sago pearls", grams: 100 },
      { name: "Nata de coco", grams: 200 },
      { name: "All-purpose cream", grams: 250 },
      { name: "Condensed milk (condensada)", grams: 200 },
    ],
    instructions: [
      "1. Prepare pandan gelatin according to package directions, let set, then cube.",
      "2. Cook sago pearls and set aside.",
      "3. Combine young coconut meat, pandan gelatin, sago, and nata de coco in a bowl.",
      "4. Add all-purpose cream and condensed milk, then mix well.",
      "5. Chill before serving."
    ]
  },
  {
    name: "Ube Ice Cream",
    description: "A creamy no-churn ube ice cream made with ube halaya.",
    servings: 8,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Ube halaya", grams: 250 },
      { name: "All-purpose cream", grams: 500 },
      { name: "Condensed milk (condensada)", grams: 390 },
      { name: "Ube flavoring", grams: 5 },
    ],
    instructions: [
      "1. Whip chilled all-purpose cream until doubled in volume.",
      "2. Add condensed milk, ube halaya, and ube extract. Fold until combined.",
      "3. Pour into a freezer-safe container.",
      "4. Cover and freeze for at least 6 hours or overnight."
    ]
  },

  // ==================== ULAM / MAIN DISHES ====================
  {
    name: "Chicken Inasal",
    description: "Grilled chicken marinated in calamansi, lemongrass, and annatto oil.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Manok (chicken)", grams: 800 },
      { name: "Tanglad (lemongrass)", grams: 30 },
      { name: "Calamansi", grams: 60 },
      { name: "Suka (vinegar)", grams: 60 },
      { name: "Toyo (soy sauce)", grams: 30 },
      { name: "Bawang (garlic)", grams: 20 },
      { name: "Luya (ginger)", grams: 20 },
      { name: "Asukal (sugar)", grams: 20 },
      { name: "Atsuete (annatto seeds)", grams: 15 },
    ],
    instructions: [
      "1. Combine calamansi juice, vinegar, soy sauce, garlic, ginger, lemongrass, and sugar for the marinade.",
      "2. Marinate chicken for at least 4 hours or overnight.",
      "3. Prepare annatto oil by heating oil with annatto seeds, then strain.",
      "4. Grill chicken over hot coals, basting with annatto oil.",
      "5. Cook until charred and cooked through. Serve with rice."
    ]
  },
  {
    name: "Chicken Bistek",
    description: "Chicken simmered in calamansi and soy sauce with onion rings.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Manok (chicken)", grams: 700 },
      { name: "Calamansi", grams: 60 },
      { name: "Toyo (soy sauce)", grams: 60 },
      { name: "Sibuyas (onion)", grams: 100 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Paminta (black pepper)", grams: 3 },
      { name: "Mantika (cooking oil)", grams: 40 },
    ],
    instructions: [
      "1. Marinate chicken in calamansi juice, soy sauce, garlic, and pepper for 30 minutes.",
      "2. Heat oil and fry chicken until golden. Set aside.",
      "3. Sauté onion rings until soft.",
      "4. Return chicken to the pan, pour in the marinade, and simmer until sauce thickens.",
      "5. Serve hot with rice."
    ]
  },
  {
    name: "Chicken Mechado",
    description: "Chicken stewed in tomato sauce with potatoes and carrots.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Manok (chicken)", grams: 700 },
      { name: "Tomato sauce", grams: 240 },
      { name: "Patatas (potato)", grams: 200 },
      { name: "Karot (carrot)", grams: 150 },
      { name: "Atsal (bell pepper)", grams: 80 },
      { name: "Toyo (soy sauce)", grams: 60 },
      { name: "Calamansi", grams: 60 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Sibuyas (onion)", grams: 40 },
    ],
    instructions: [
      "1. Marinate chicken in soy sauce and calamansi juice for 30 minutes.",
      "2. Sauté garlic and onion, then add chicken and brown.",
      "3. Pour in tomato sauce and marinade. Simmer until chicken is tender.",
      "4. Add potatoes, carrots, and bell pepper. Cook until tender.",
      "5. Serve hot."
    ]
  },
  {
    name: "Chicken Afritada sa Gata",
    description: "Chicken stewed in tomato sauce and coconut milk with vegetables.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Manok (chicken)", grams: 700 },
      { name: "Gata (coconut milk)", grams: 240 },
      { name: "Tomato sauce", grams: 240 },
      { name: "Patatas (potato)", grams: 200 },
      { name: "Karot (carrot)", grams: 150 },
      { name: "Atsal (bell pepper)", grams: 80 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Sibuyas (onion)", grams: 40 },
    ],
    instructions: [
      "1. Sauté garlic and onion, then add chicken and brown.",
      "2. Pour in tomato sauce and coconut milk. Bring to a boil.",
      "3. Add potatoes and carrots. Simmer until tender.",
      "4. Add bell pepper and cook for another 2 minutes.",
      "5. Serve hot with rice."
    ]
  },
  {
    name: "Kinamatisang Manok",
    description: "Chicken simmered in fresh tomatoes with fish sauce.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Manok (chicken)", grams: 700 },
      { name: "Kamatis (tomato)", grams: 300 },
      { name: "Sibuyas (onion)", grams: 40 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Patis (fish sauce)", grams: 30 },
      { name: "Paminta (black pepper)", grams: 3 },
    ],
    instructions: [
      "1. Sauté garlic and onion, then add tomatoes and cook until softened.",
      "2. Add chicken and cook until lightly browned.",
      "3. Pour in fish sauce and water. Simmer until chicken is tender.",
      "4. Season with pepper. Serve hot."
    ]
  },
  {
    name: "Chicken Liver and Gizzard in Oyster Sauce",
    description: "Chicken liver and gizzard sautéed in savory oyster sauce.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Atay ng manok (chicken liver)", grams: 300 },
      { name: "Balunbalunan (chicken gizzard)", grams: 300 },
      { name: "Oyster sauce", grams: 60 },
      { name: "Toyo (soy sauce)", grams: 30 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Sibuyas (onion)", grams: 40 },
      { name: "Atsal (bell pepper)", grams: 80 },
    ],
    instructions: [
      "1. Sauté garlic and onion, then add gizzard and cook for a few minutes.",
      "2. Add liver and cook until no longer pink.",
      "3. Pour in oyster sauce and soy sauce. Stir well.",
      "4. Add bell pepper and cook for another 2 minutes.",
      "5. Serve hot."
    ]
  },
  {
    name: "Chicken Gizzard Ginataan",
    description: "Chicken gizzard simmered in coconut milk with ginger and chili.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Balunbalunan (chicken gizzard)", grams: 500 },
      { name: "Gata (coconut milk)", grams: 480 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Sibuyas (onion)", grams: 40 },
      { name: "Luya (ginger)", grams: 20 },
      { name: "Siling labuyo (bird's eye chili)", grams: 10 },
      { name: "Patis (fish sauce)", grams: 15 },
    ],
    instructions: [
      "1. Boil gizzard until tender, then set aside.",
      "2. Sauté garlic, onion, and ginger.",
      "3. Add gizzard and cook for a few minutes.",
      "4. Pour in coconut milk, bring to a boil, then simmer until sauce thickens.",
      "5. Add chili and fish sauce. Cook for another 2 minutes."
    ]
  },
  {
    name: "Salted Egg Chicken",
    description: "Crispy chicken coated in a creamy salted egg sauce.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Manok pecho (chicken breast)", grams: 500 },
      { name: "Maalat na itlog (salted egg)", grams: 150 },
      { name: "Mantikilya (butter)", grams: 30 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Evaporated milk (evaporada)", grams: 60 },
      { name: "Siling labuyo (bird's eye chili)", grams: 10 },
      { name: "Curry leaves", grams: 5 },
    ],
    instructions: [
      "1. Fry chicken slices until golden and cooked through. Set aside.",
      "2. Melt butter and sauté garlic.",
      "3. Add mashed salted eggs and cook for a minute.",
      "4. Pour in evaporated milk and stir until a creamy sauce forms.",
      "5. Return chicken to the pan and coat with sauce.",
      "6. Add chili and curry leaves. Serve hot."
    ]
  },
  {
    name: "Creamy Pininyahang Manok",
    description: "Chicken simmered in pineapple juice and evaporated milk.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Manok (chicken)", grams: 700 },
      { name: "Pinya (pineapple)", grams: 240 },
      { name: "Evaporated milk (evaporada)", grams: 240 },
      { name: "Atsal (bell pepper)", grams: 80 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Sibuyas (onion)", grams: 40 },
    ],
    instructions: [
      "1. Sauté garlic and onion, then add chicken and brown.",
      "2. Pour in pineapple juice and evaporated milk. Bring to a boil.",
      "3. Add pineapple chunks and bell pepper. Simmer until chicken is tender.",
      "4. Serve hot with rice."
    ]
  },
  {
    name: "Chicken Ala King",
    description: "Creamy chicken with mushrooms and bell pepper served over rice.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Manok pecho (chicken breast)", grams: 500 },
      { name: "Kabute (mushroom)", grams: 200 },
      { name: "Atsal (bell pepper)", grams: 80 },
      { name: "Fresh milk (gatas)", grams: 240 },
      { name: "All-purpose cream", grams: 120 },
      { name: "Mantikilya (butter)", grams: 30 },
      { name: "Harina (all-purpose flour)", grams: 20 },
    ],
    instructions: [
      "1. Season and fry chicken until cooked. Set aside.",
      "2. Melt butter, add flour, and cook for a minute to make a roux.",
      "3. Gradually whisk in milk and cream until thickened.",
      "4. Add mushrooms and bell pepper, then cook for 2 minutes.",
      "5. Return chicken to the pan and coat with sauce. Serve over rice."
    ]
  },
  {
    name: "Sinantomas",
    description: "Pork ribs marinated in pineapple juice and soy sauce with sweet potatoes.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Pork ribs", grams: 800 },
      { name: "Kamote (sweet potato)", grams: 300 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Sibuyas (onion)", grams: 40 },
      { name: "Kamatis (tomato)", grams: 100 },
      { name: "Toyo (soy sauce)", grams: 60 },
      { name: "Pinya (pineapple)", grams: 240 },
      { name: "Ketchup", grams: 30 },
      { name: "Keso (cheese)", grams: 50 },
    ],
    instructions: [
      "1. Marinate pork ribs in soy sauce, pineapple juice, and ketchup for at least 1 hour.",
      "2. Sauté garlic, onion, and tomato.",
      "3. Add marinated pork ribs and cook until browned.",
      "4. Pour in marinade and water to cover. Simmer until pork is tender.",
      "5. Add sweet potatoes and cook until tender.",
      "6. Top with cheese if desired. Serve hot."
    ]
  },
  {
    name: "Pork Hamonado",
    description: "Sweet pork belly braised in pineapple juice and soy sauce.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Liempo (pork belly)", grams: 800 },
      { name: "Pinya (pineapple)", grams: 480 },
      { name: "Bawang (garlic)", grams: 20 },
      { name: "Toyo (soy sauce)", grams: 120 },
      { name: "Asukal (sugar)", grams: 50 },
    ],
    instructions: [
      "1. Combine pork belly, pineapple juice, soy sauce, garlic, and brown sugar in a pot.",
      "2. Bring to a boil, then simmer until pork is tender.",
      "3. Add pineapple chunks and cook for another 10 minutes.",
      "4. Adjust seasoning. Serve hot with rice."
    ]
  },
  {
    name: "Paksiw na Baboy",
    description: "Pork belly simmered in vinegar, soy sauce, and garlic.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Liempo (pork belly)", grams: 700 },
      { name: "Bawang (garlic)", grams: 20 },
      { name: "Suka (vinegar)", grams: 60 },
      { name: "Toyo (soy sauce)", grams: 60 },
      { name: "Dahon ng laurel (bay leaves)", grams: 2 },
      { name: "Peppercorns", grams: 3 },
      { name: "Asukal (sugar)", grams: 15 },
    ],
    instructions: [
      "1. Combine pork, garlic, vinegar, soy sauce, bay leaves, and peppercorns in a pot.",
      "2. Bring to a boil, then simmer until pork is tender.",
      "3. Add sugar and adjust seasoning.",
      "4. Serve hot with rice."
    ]
  },
  {
    name: "Pork Mechado",
    description: "Pork stewed in tomato sauce with potatoes and carrots.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Baboy (pork, kasim/shoulder)", grams: 700 },
      { name: "Toyo (soy sauce)", grams: 45 },
      { name: "Calamansi", grams: 30 },
      { name: "Tomato sauce", grams: 240 },
      { name: "Patatas (potato)", grams: 200 },
      { name: "Karot (carrot)", grams: 150 },
      { name: "Atsal (bell pepper)", grams: 80 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Sibuyas (onion)", grams: 40 },
    ],
    instructions: [
      "1. Marinate pork in soy sauce and calamansi juice for at least 1 hour.",
      "2. Sauté garlic and onion, then add pork and brown.",
      "3. Pour in tomato sauce and marinade, adding water if needed.",
      "4. Simmer until pork is tender.",
      "5. Add potatoes, carrots, and bell pepper. Cook until tender."
    ]
  },
  {
    name: "Pork Bagnet",
    description: "Crispy deep-fried pork belly, a Northern Luzon specialty.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Liempo (pork belly)", grams: 1000 },
      { name: "Asin (salt)", grams: 15 },
      { name: "Paminta (black pepper)", grams: 5 },
      { name: "Bawang (garlic)", grams: 20 },
      { name: "Dahon ng laurel (bay leaves)", grams: 2 },
      { name: "Mantika (cooking oil)", grams: 500 },
    ],
    instructions: [
      "1. Combine pork belly, salt, pepper, garlic, and bay leaves with water to cover.",
      "2. Boil until pork is tender, then drain and cool.",
      "3. Heat oil and deep-fry pork belly until crispy and golden.",
      "4. Drain on paper towels. Slice and serve."
    ]
  },
  {
    name: "Pork Dinakdakan",
    description: "Grilled pork face and ears in a creamy calamansi dressing.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Pork face", grams: 500 },
      { name: "Tenga ng baboy (pork ear)", grams: 300 },
      { name: "Sibuyas (onion)", grams: 80 },
      { name: "Calamansi", grams: 60 },
      { name: "Siling labuyo (bird's eye chili)", grams: 15 },
      { name: "Mayonnaise", grams: 120 },
      { name: "Asin (salt)", grams: 5 },
      { name: "Paminta (black pepper)", grams: 3 },
    ],
    instructions: [
      "1. Boil pork face and ears until tender, then grill and chop into small pieces.",
      "2. Combine chopped pork with onions, calamansi juice, chili, and mayonnaise.",
      "3. Mix well and season with salt and pepper.",
      "4. Chill before serving."
    ]
  },
  {
    name: "Pork Menudo",
    description: "Pork and liver stewed in tomato sauce with potatoes and raisins.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Baboy (pork, kasim/shoulder)", grams: 500 },
      { name: "Atay ng baboy (pork liver)", grams: 250 },
      { name: "Tomato sauce", grams: 240 },
      { name: "Patatas (potato)", grams: 200 },
      { name: "Karot (carrot)", grams: 150 },
      { name: "Atsal (bell pepper)", grams: 80 },
      { name: "Pasas (raisins)", grams: 40 },
      { name: "Toyo (soy sauce)", grams: 30 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Sibuyas (onion)", grams: 40 },
    ],
    instructions: [
      "1. Marinate pork in soy sauce for 30 minutes.",
      "2. Sauté garlic and onion, then add pork and brown.",
      "3. Add liver and cook for a few minutes.",
      "4. Pour in tomato sauce and water. Simmer until pork is tender.",
      "5. Add potatoes, carrots, bell pepper, and raisins. Cook until tender."
    ]
  },
  {
    name: "Dinuguan",
    description: "Pork simmered in a rich, savory pork blood sauce.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Baboy (pork, kasim/shoulder)", grams: 500 },
      { name: "Dugo ng baboy (pork blood)", grams: 500 },
      { name: "Suka (vinegar)", grams: 60 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Sibuyas (onion)", grams: 40 },
      { name: "Siling labuyo (bird's eye chili)", grams: 15 },
      { name: "Dahon ng laurel (bay leaves)", grams: 2 },
      { name: "Patis (fish sauce)", grams: 15 },
    ],
    instructions: [
      "1. Sauté garlic and onion, then add pork and brown.",
      "2. Pour in vinegar and let it boil without stirring for a few minutes.",
      "3. Add pork blood, chili, bay leaves, and fish sauce. Stir.",
      "4. Simmer until sauce thickens and pork is tender.",
      "5. Serve with puto or rice."
    ]
  },
  {
    name: "Pork Binagoongan",
    description: "Pork belly sautéed in shrimp paste with tomatoes and chili.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Liempo (pork belly)", grams: 700 },
      { name: "Bagoong alamang (shrimp paste)", grams: 60 },
      { name: "Kamatis (tomato)", grams: 200 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Sibuyas (onion)", grams: 40 },
      { name: "Suka (vinegar)", grams: 30 },
      { name: "Siling labuyo (bird's eye chili)", grams: 15 },
      { name: "Asukal (sugar)", grams: 15 },
    ],
    instructions: [
      "1. Boil pork belly until tender. Set aside.",
      "2. Sauté garlic, onion, and tomatoes.",
      "3. Add shrimp paste and cook for a minute.",
      "4. Add boiled pork and vinegar. Simmer for a few minutes.",
      "5. Add chili and sugar. Cook until sauce thickens."
    ]
  },
  {
    name: "Pork Asado",
    description: "Sweet and savory braised pork in soy sauce and brown sugar.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Baboy (pork, kasim/shoulder)", grams: 700 },
      { name: "Toyo (soy sauce)", grams: 120 },
      { name: "Asukal (sugar)", grams: 80 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Mantika (cooking oil)", grams: 30 },
    ],
    instructions: [
      "1. Marinate pork in soy sauce, brown sugar, and garlic for at least 1 hour.",
      "2. Heat oil and sear the pork until browned.",
      "3. Pour in marinade and water. Bring to a boil.",
      "4. Simmer until pork is tender and sauce thickens.",
      "5. Serve with rice."
    ]
  },
  {
    name: "Pork Giniling",
    description: "Ground pork stewed with potatoes, carrots, and tomato sauce.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Giniling na baboy (ground pork)", grams: 500 },
      { name: "Patatas (potato)", grams: 200 },
      { name: "Karot (carrot)", grams: 150 },
      { name: "Tomato sauce", grams: 240 },
      { name: "Gisantes (green peas)", grams: 80 },
      { name: "Atsal (bell pepper)", grams: 80 },
      { name: "Pasas (raisins)", grams: 40 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Sibuyas (onion)", grams: 40 },
    ],
    instructions: [
      "1. Sauté garlic and onion, then add ground pork and brown.",
      "2. Pour in tomato sauce and a little water. Simmer for 10 minutes.",
      "3. Add potatoes, carrots, peas, bell pepper, and raisins.",
      "4. Cook until vegetables are tender.",
      "5. Season to taste and serve hot."
    ]
  },
  {
    name: "Pork Nilaga",
    description: "Clear pork soup with potatoes, cabbage, and corn.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Baboy (pork, kasim/shoulder)", grams: 700 },
      { name: "Patatas (potato)", grams: 200 },
      { name: "Repolyo (cabbage)", grams: 150 },
      { name: "Mais (corn)", grams: 200 },
      { name: "Sibuyas (onion)", grams: 40 },
      { name: "Peppercorns", grams: 3 },
      { name: "Patis (fish sauce)", grams: 15 },
    ],
    instructions: [
      "1. Combine pork, onion, peppercorns, and water in a pot. Boil and simmer until pork is tender.",
      "2. Add potatoes and corn. Cook until tender.",
      "3. Add cabbage and fish sauce. Cook for another 2 minutes.",
      "4. Serve hot."
    ]
  },
  {
    name: "Pork Pata Humba",
    description: "Pork hock braised with black beans, banana blossoms, and soy sauce.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Pork pata (pork hock)", grams: 1000 },
      { name: "Toyo (soy sauce)", grams: 120 },
      { name: "Suka (vinegar)", grams: 60 },
      { name: "Asukal (sugar)", grams: 100 },
      { name: "Tausi (fermented black beans)", grams: 60 },
      { name: "Puso ng saging (banana blossom/heart)", grams: 100 },
      { name: "Dahon ng laurel (bay leaves)", grams: 2 },
      { name: "Bawang (garlic)", grams: 20 },
    ],
    instructions: [
      "1. Combine pork pata, soy sauce, vinegar, brown sugar, garlic, and bay leaves with water to cover.",
      "2. Boil and simmer until pork is tender.",
      "3. Add black beans and banana blossoms. Cook for another 10 minutes.",
      "4. Serve hot with rice."
    ]
  },
  {
    name: "Paksiw na Pata with Pineapple",
    description: "Pork hock simmered in vinegar and soy sauce with pineapple.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Pork pata (pork hock)", grams: 1000 },
      { name: "Suka (vinegar)", grams: 60 },
      { name: "Toyo (soy sauce)", grams: 60 },
      { name: "Pinya (pineapple)", grams: 240 },
      { name: "Bawang (garlic)", grams: 20 },
      { name: "Asukal (sugar)", grams: 30 },
      { name: "Dahon ng laurel (bay leaves)", grams: 2 },
    ],
    instructions: [
      "1. Combine pork pata, vinegar, soy sauce, garlic, bay leaves, and pineapple juice with water to cover.",
      "2. Boil and simmer until pork is tender.",
      "3. Add pineapple chunks and brown sugar. Cook for another 10 minutes.",
      "4. Serve hot."
    ]
  },
  {
    name: "Pork and Potato Stew",
    description: "Pork stewed with potatoes, carrots, and tomato sauce.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Baboy (pork, kasim/shoulder)", grams: 700 },
      { name: "Patatas (potato)", grams: 250 },
      { name: "Tomato sauce", grams: 240 },
      { name: "Karot (carrot)", grams: 150 },
      { name: "Atsal (bell pepper)", grams: 80 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Sibuyas (onion)", grams: 40 },
    ],
    instructions: [
      "1. Sauté garlic and onion, then add pork and brown.",
      "2. Pour in tomato sauce and water. Simmer until pork is tender.",
      "3. Add potatoes, carrots, and bell pepper. Cook until tender.",
      "4. Serve hot."
    ]
  },
  {
    name: "Beef Caldereta",
    description: "Rich beef stew with liver spread, peanut butter, and cheese.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Baka (beef, brisket/shank)", grams: 800 },
      { name: "Tomato sauce", grams: 240 },
      { name: "Liver spread", grams: 100 },
      { name: "Patatas (potato)", grams: 200 },
      { name: "Karot (carrot)", grams: 150 },
      { name: "Atsal (bell pepper)", grams: 80 },
      { name: "Keso (cheese)", grams: 80 },
      { name: "Peanut butter", grams: 40 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Sibuyas (onion)", grams: 40 },
    ],
    instructions: [
      "1. Sauté garlic and onion, then add beef and brown.",
      "2. Pour in tomato sauce and water. Simmer until beef is tender.",
      "3. Add liver spread, peanut butter, and cheese. Stir well.",
      "4. Add potatoes, carrots, and bell pepper. Cook until tender.",
      "5. Serve hot."
    ]
  },
  {
    name: "Beef Mechado",
    description: "Beef stewed in tomato sauce and soy sauce with vegetables.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Baka (beef, brisket/shank)", grams: 800 },
      { name: "Tomato sauce", grams: 240 },
      { name: "Toyo (soy sauce)", grams: 60 },
      { name: "Patatas (potato)", grams: 200 },
      { name: "Karot (carrot)", grams: 150 },
      { name: "Atsal (bell pepper)", grams: 80 },
      { name: "Calamansi", grams: 30 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Sibuyas (onion)", grams: 40 },
    ],
    instructions: [
      "1. Marinate beef in soy sauce and calamansi juice for at least 1 hour.",
      "2. Sauté garlic and onion, then add beef and brown.",
      "3. Pour in tomato sauce and marinade with water. Simmer until beef is tender.",
      "4. Add potatoes, carrots, and bell pepper. Cook until tender.",
      "5. Serve hot."
    ]
  },
  {
    name: "Beef Salpicao",
    description: "Garlicky beef tenderloin cubes in a buttery soy-oyster sauce.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Beef tenderloin", grams: 500 },
      { name: "Bawang (garlic)", grams: 30 },
      { name: "Mantikilya (butter)", grams: 30 },
      { name: "Oyster sauce", grams: 30 },
      { name: "Toyo (soy sauce)", grams: 30 },
      { name: "Worcestershire sauce", grams: 15 },
    ],
    instructions: [
      "1. Melt butter in a pan and sauté garlic until golden.",
      "2. Add beef and cook over high heat until browned.",
      "3. Pour in oyster sauce, soy sauce, and Worcestershire sauce.",
      "4. Stir and cook for another 2 minutes. Serve hot."
    ]
  },
  {
    name: "Beef Nilaga",
    description: "Clear beef soup with potatoes, cabbage, and corn.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Baka (beef, brisket/shank)", grams: 800 },
      { name: "Patatas (potato)", grams: 200 },
      { name: "Repolyo (cabbage)", grams: 150 },
      { name: "Mais (corn)", grams: 200 },
      { name: "Sibuyas (onion)", grams: 40 },
      { name: "Peppercorns", grams: 3 },
      { name: "Patis (fish sauce)", grams: 15 },
    ],
    instructions: [
      "1. Combine beef, onion, peppercorns, and water. Boil and simmer for 2–3 hours until beef is tender.",
      "2. Add potatoes and corn. Cook until tender.",
      "3. Add cabbage and fish sauce. Cook for another 2 minutes.",
      "4. Serve hot."
    ]
  },
  {
    name: "Beef Pares",
    description: "Sweet and savory braised beef brisket served with broth.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Baka (beef, brisket/shank)", grams: 800 },
      { name: "Toyo (soy sauce)", grams: 60 },
      { name: "Star anise", grams: 5 },
      { name: "Asukal (sugar)", grams: 60 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Luya (ginger)", grams: 20 },
      { name: "Beef broth", grams: 960 },
    ],
    instructions: [
      "1. Combine beef, soy sauce, star anise, brown sugar, garlic, ginger, and beef broth in a pot.",
      "2. Boil and simmer until beef is tender.",
      "3. Slice the beef and serve with the broth.",
      "4. Serve with rice or noodles."
    ]
  },
  {
    name: "Beef Asado",
    description: "Beef braised in soy sauce, calamansi, and tomato sauce.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Baka (beef, brisket/shank)", grams: 800 },
      { name: "Toyo (soy sauce)", grams: 60 },
      { name: "Calamansi", grams: 60 },
      { name: "Asukal (sugar)", grams: 60 },
      { name: "Tomato sauce", grams: 240 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Dahon ng laurel (bay leaves)", grams: 2 },
    ],
    instructions: [
      "1. Marinate beef in soy sauce, calamansi juice, sugar, and garlic for at least 1 hour.",
      "2. Heat oil and sear beef until browned.",
      "3. Pour in marinade and tomato sauce. Add bay leaves.",
      "4. Simmer until beef is tender and sauce thickens.",
      "5. Serve hot."
    ]
  },
  {
    name: "Kinamatisang Baka",
    description: "Beef simmered in fresh tomatoes with fish sauce.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Baka (beef, brisket/shank)", grams: 800 },
      { name: "Kamatis (tomato)", grams: 300 },
      { name: "Sibuyas (onion)", grams: 40 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Patis (fish sauce)", grams: 30 },
      { name: "Paminta (black pepper)", grams: 3 },
    ],
    instructions: [
      "1. Sauté garlic and onion, then add tomatoes and cook until softened.",
      "2. Add beef and cook until browned.",
      "3. Pour in fish sauce and water. Simmer until beef is tender.",
      "4. Season with pepper. Serve hot."
    ]
  },
  {
    name: "Beef and Broccoli",
    description: "Stir-fried beef and broccoli in a savory soy-oyster sauce.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Beef tenderloin", grams: 500 },
      { name: "Broccoli", grams: 300 },
      { name: "Toyo (soy sauce)", grams: 60 },
      { name: "Oyster sauce", grams: 30 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Luya (ginger)", grams: 15 },
      { name: "Gawgaw (cornstarch)", grams: 15 },
    ],
    instructions: [
      "1. Marinate beef in soy sauce and cornstarch for 30 minutes.",
      "2. Sauté garlic and ginger, then add beef and cook until browned.",
      "3. Add broccoli and oyster sauce. Stir-fry for a few minutes.",
      "4. Pour in cornstarch mixture and cook until sauce thickens.",
      "5. Serve hot."
    ]
  },
  {
    name: "Beef with Mushroom",
    description: "Stir-fried beef with mushrooms in a savory sauce.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Beef tenderloin", grams: 500 },
      { name: "Kabute (mushroom)", grams: 200 },
      { name: "Toyo (soy sauce)", grams: 60 },
      { name: "Oyster sauce", grams: 30 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Sibuyas (onion)", grams: 40 },
      { name: "Gawgaw (cornstarch)", grams: 15 },
    ],
    instructions: [
      "1. Marinate beef in soy sauce for 30 minutes.",
      "2. Sauté garlic and onion, then add beef and brown.",
      "3. Add mushrooms and oyster sauce. Stir-fry for a few minutes.",
      "4. Pour in cornstarch mixture and cook until sauce thickens.",
      "5. Serve hot."
    ]
  },
  {
    name: "Balbacua",
    description: "Rich beef skin and shank stew with peanuts and banana blossoms.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Beef skin", grams: 500 },
      { name: "Baka (beef, brisket/shank)", grams: 500 },
      { name: "Mani (peanuts)", grams: 80 },
      { name: "Puso ng saging (banana blossom/heart)", grams: 100 },
      { name: "Tomato sauce", grams: 240 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Sibuyas (onion)", grams: 40 },
      { name: "Dahon ng laurel (bay leaves)", grams: 2 },
      { name: "Peppercorns", grams: 3 },
    ],
    instructions: [
      "1. Combine beef skin and shank with water. Boil and simmer for 2–3 hours until tender.",
      "2. Add peanuts, banana blossoms, tomato sauce, garlic, onion, and spices.",
      "3. Simmer for another 30 minutes.",
      "4. Serve hot."
    ]
  },
  {
    name: "Ginataang Bangus",
    description: "Milkfish simmered in coconut milk with ginger and chili.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Bangus (milkfish)", grams: 700 },
      { name: "Gata (coconut milk)", grams: 480 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Sibuyas (onion)", grams: 40 },
      { name: "Luya (ginger)", grams: 20 },
      { name: "Siling labuyo (bird's eye chili)", grams: 10 },
      { name: "Patis (fish sauce)", grams: 15 },
    ],
    instructions: [
      "1. Sauté garlic, onion, and ginger.",
      "2. Pour in coconut milk and bring to a boil.",
      "3. Add bangus and simmer until cooked.",
      "4. Add chili and fish sauce. Cook for another 2 minutes.",
      "5. Serve hot."
    ]
  },
  {
    name: "Fish Pochero",
    description: "Fish stewed in tomato sauce with potatoes, saba, and cabbage.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Isda (generic fish)", grams: 700 },
      { name: "Tomato sauce", grams: 240 },
      { name: "Patatas (potato)", grams: 200 },
      { name: "Saging na saba (plantain)", grams: 200 },
      { name: "Repolyo (cabbage)", grams: 150 },
      { name: "Atsal (bell pepper)", grams: 80 },
      { name: "Bawang (garlic)", grams: 15 },
    ],
    instructions: [
      "1. Sauté garlic and onion, then pour in tomato sauce and water. Bring to a boil.",
      "2. Add fish and simmer until cooked.",
      "3. Add potatoes, saba banana, cabbage, and bell pepper.",
      "4. Cook until vegetables are tender. Serve hot."
    ]
  },
  {
    name: "Tulingan Bistek",
    description: "Tuna steaks simmered in calamansi and soy sauce with onion rings.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Tulingan (bullet tuna)", grams: 800 },
      { name: "Calamansi", grams: 60 },
      { name: "Toyo (soy sauce)", grams: 120 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Sibuyas (onion)", grams: 100 },
      { name: "Paminta (black pepper)", grams: 3 },
      { name: "Mantika (cooking oil)", grams: 30 },
    ],
    instructions: [
      "1. Marinate tulingan in calamansi juice, soy sauce, garlic, and pepper for 30 minutes.",
      "2. Heat oil and fry fish until golden. Set aside.",
      "3. Sauté onion rings until soft.",
      "4. Return fish to the pan, pour in the marinade, and simmer for a few minutes.",
      "5. Serve hot."
    ]
  },
  {
    name: "Sarciadong Isda",
    description: "Fried fish simmered in a fresh tomato and egg sauce.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Isda (generic fish)", grams: 700 },
      { name: "Itlog (egg)", grams: 150 },
      { name: "Kamatis (tomato)", grams: 200 },
      { name: "Sibuyas (onion)", grams: 40 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Patis (fish sauce)", grams: 15 },
    ],
    instructions: [
      "1. Sauté garlic, onion, and tomatoes.",
      "2. Add the fried fish and cook for a minute.",
      "3. Pour in the beaten eggs and fish sauce. Cook until eggs are set.",
      "4. Serve hot."
    ]
  },
  {
    name: "Ginataang Tulingan",
    description: "Tuna simmered in coconut milk with ginger, chili, and vinegar.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Tulingan (bullet tuna)", grams: 800 },
      { name: "Gata (coconut milk)", grams: 480 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Sibuyas (onion)", grams: 40 },
      { name: "Luya (ginger)", grams: 20 },
      { name: "Siling labuyo (bird's eye chili)", grams: 10 },
      { name: "Suka (vinegar)", grams: 30 },
    ],
    instructions: [
      "1. Combine tulingan, garlic, onion, ginger, chili, vinegar, and coconut milk in a pot.",
      "2. Bring to a boil, then simmer until fish is cooked.",
      "3. Serve hot."
    ]
  },
  {
    name: "Sinanglay na Tilapia",
    description: "Tilapia stuffed with tomatoes and wrapped in pechay, simmered in coconut milk.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Tilapia", grams: 700 },
      { name: "Pechay (bok choy)", grams: 200 },
      { name: "Gata (coconut milk)", grams: 360 },
      { name: "Kamatis (tomato)", grams: 150 },
      { name: "Sibuyas (onion)", grams: 40 },
      { name: "Luya (ginger)", grams: 20 },
      { name: "Tanglad (lemongrass)", grams: 20 },
    ],
    instructions: [
      "1. Stuff tilapia with tomatoes, onion, and ginger.",
      "2. Wrap each fish in pechay leaves.",
      "3. Combine coconut milk and lemongrass in a pot. Bring to a boil.",
      "4. Add the wrapped fish and simmer until cooked.",
      "5. Serve hot."
    ]
  },
  {
    name: "Inihaw na Bangus",
    description: "Grilled milkfish stuffed with tomatoes and onion.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Bangus (milkfish)", grams: 800 },
      { name: "Kamatis (tomato)", grams: 200 },
      { name: "Sibuyas (onion)", grams: 60 },
      { name: "Calamansi", grams: 60 },
      { name: "Toyo (soy sauce)", grams: 30 },
      { name: "Asin (salt)", grams: 5 },
      { name: "Paminta (black pepper)", grams: 3 },
    ],
    instructions: [
      "1. Stuff bangus with tomatoes and onion.",
      "2. Combine calamansi juice, soy sauce, salt, and pepper for basting.",
      "3. Grill fish over hot coals, basting with the sauce.",
      "4. Cook until charred and cooked through.",
      "5. Serve with rice."
    ]
  },
  {
    name: "Kinilaw na Tanigue",
    description: "Fresh tanigue cured in vinegar and calamansi with ginger and chili.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Tanigue (Spanish mackerel)", grams: 500 },
      { name: "Suka (vinegar)", grams: 120 },
      { name: "Calamansi", grams: 60 },
      { name: "Luya (ginger)", grams: 20 },
      { name: "Sibuyas (onion)", grams: 60 },
      { name: "Siling labuyo (bird's eye chili)", grams: 15 },
      { name: "Pipino (cucumber)", grams: 100 },
    ],
    instructions: [
      "1. Combine vinegar, calamansi juice, ginger, onion, and chili in a bowl.",
      "2. Add tanigue cubes and mix well.",
      "3. Chill for at least 30 minutes to allow the fish to cure in the acid.",
      "4. Add cucumber before serving. Serve cold."
    ]
  },
  {
    name: "Tinolang Isda",
    description: "Clear fish soup with ginger, green papaya, and chili leaves.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Isda (generic fish)", grams: 700 },
      { name: "Luya (ginger)", grams: 20 },
      { name: "Papaya (green papaya)", grams: 200 },
      { name: "Dahon ng sili (chili leaves)", grams: 50 },
      { name: "Sibuyas (onion)", grams: 40 },
      { name: "Patis (fish sauce)", grams: 15 },
    ],
    instructions: [
      "1. Bring water to a boil with ginger and onion.",
      "2. Add fish and simmer until cooked.",
      "3. Add green papaya and cook until tender.",
      "4. Add chili leaves and fish sauce. Cook for another 2 minutes.",
      "5. Serve hot."
    ]
  },
  {
    name: "Sinaing na Tulingan",
    description: "Tulingan slow-cooked with dried kamias, garlic, and ginger.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Tulingan (bullet tuna)", grams: 1000 },
      { name: "Kamias (bilimbi)", grams: 60 },
      { name: "Bawang (garlic)", grams: 20 },
      { name: "Luya (ginger)", grams: 20 },
      { name: "Asin (salt)", grams: 10 },
      { name: "Liempo (pork belly)", grams: 100 },
    ],
    instructions: [
      "1. Line a pot with banana leaves.",
      "2. Arrange tulingan, kamias, garlic, and ginger in the pot.",
      "3. Add a little water and salt, plus pork fat if using.",
      "4. Cover and simmer over low heat for 2–3 hours until fish is tender.",
      "5. Serve hot."
    ]
  },
  {
    name: "Ginataang Talong with Malunggay and Tofu",
    description: "Eggplant and tofu simmered in coconut milk with malunggay leaves.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Talong (eggplant)", grams: 400 },
      { name: "Tokwa (tofu)", grams: 300 },
      { name: "Malunggay (moringa leaves)", grams: 80 },
      { name: "Gata (coconut milk)", grams: 480 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Sibuyas (onion)", grams: 40 },
      { name: "Luya (ginger)", grams: 15 },
      { name: "Bagoong alamang (shrimp paste)", grams: 30 },
      { name: "Siling labuyo (bird's eye chili)", grams: 15 },
    ],
    instructions: [
      "1. Fry tofu until golden. Set aside.",
      "2. Sauté garlic, onion, and ginger.",
      "3. Pour in coconut milk and bring to a simmer. Add shrimp paste.",
      "4. Add eggplants and cook until tender.",
      "5. Add fried tofu and chili. Simmer for 3–5 minutes.",
      "6. Turn off heat, add malunggay leaves, and cover for 2 minutes.",
      "7. Serve hot with rice."
    ]
  },
  {
    name: "Ginisang Puso ng Saging",
    description: "Banana blossom sautéed with pork, garlic, and vinegar.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Puso ng saging (banana blossom/heart)", grams: 500 },
      { name: "Baboy (pork, kasim/shoulder)", grams: 250 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Sibuyas (onion)", grams: 40 },
      { name: "Kamatis (tomato)", grams: 100 },
      { name: "Patis (fish sauce)", grams: 15 },
      { name: "Suka (vinegar)", grams: 30 },
    ],
    instructions: [
      "1. Sauté garlic, onion, and tomato.",
      "2. Add pork and cook until browned.",
      "3. Add banana blossom and fish sauce. Stir.",
      "4. Pour in vinegar and a little water. Simmer until banana blossom is tender.",
      "5. Serve hot."
    ]
  },
  {
    name: "Ginisang Pechay at Giniling",
    description: "Pechay sautéed with ground pork in oyster sauce.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Pechay (bok choy)", grams: 400 },
      { name: "Giniling na baboy (ground pork)", grams: 250 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Sibuyas (onion)", grams: 40 },
      { name: "Kamatis (tomato)", grams: 100 },
      { name: "Oyster sauce", grams: 30 },
    ],
    instructions: [
      "1. Sauté garlic and onion, then add ground pork and brown.",
      "2. Add tomato and oyster sauce. Stir.",
      "3. Add pechay stems first, cook for a minute, then add leaves.",
      "4. Stir-fry until pechay is wilted but still crisp.",
      "5. Serve hot."
    ]
  },
  {
    name: "Laing na Gabi",
    description: "Dried taro leaves simmered in coconut milk with pork and shrimp paste.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Dahon ng laing (dried taro leaves)", grams: 100 },
      { name: "Gata (coconut milk)", grams: 720 },
      { name: "Kakang gata (coconut cream)", grams: 480 },
      { name: "Baboy (pork, kasim/shoulder)", grams: 250 },
      { name: "Bagoong alamang (shrimp paste)", grams: 30 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Sibuyas (onion)", grams: 40 },
      { name: "Luya (ginger)", grams: 15 },
      { name: "Siling labuyo (bird's eye chili)", grams: 15 },
    ],
    instructions: [
      "1. Combine coconut milk, pork, garlic, onion, and ginger in a pot. Bring to a boil.",
      "2. Add dried taro leaves and shrimp paste. Stir.",
      "3. Simmer over low heat for 30–40 minutes until leaves are tender and sauce is thick.",
      "4. Add coconut cream and chili. Cook for another 10 minutes.",
      "5. Serve hot with rice."
    ]
  },
  //SNACKS RECIPE
  {
    name: "Turon",
    description: "Crispy lumpia rolls filled with saba banana and jackfruit.",
    servings: 6,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Saging na saba (plantain)", grams: 600 },
      { name: "Langka (jackfruit)", grams: 200 },
      { name: "Lumpia wrappers", grams: 200 },
      { name: "Asukal (sugar)", grams: 100 },
      { name: "Mantika (cooking oil)", grams: 300 },
    ],
    instructions: [
      "1. Place banana and jackfruit on a lumpia wrapper.",
      "2. Sprinkle with brown sugar.",
      "3. Roll tightly and seal with water.",
      "4. Heat oil over medium heat.",
      "5. Fry until golden and crispy.",
      "6. Drain and serve warm."
    ]
  },
  {
    name: "Banana Cue",
    description: "Caramelized saba bananas on skewers.",
    servings: 6,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Saging na saba (plantain)", grams: 600 },
      { name: "Asukal (sugar)", grams: 200 },
      { name: "Mantika (cooking oil)", grams: 300 },
    ],
    instructions: [
      "1. Peel the bananas.",
      "2. Heat oil and fry bananas for several minutes.",
      "3. Add brown sugar.",
      "4. Cook until the sugar melts and coats the bananas.",
      "5. Turn gently until caramelized.",
      "6. Serve warm."
    ]
  },
  {
    name: "Kamote Cue",
    description: "Caramelized sweet potato slices on skewers.",
    servings: 4,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Kamote (sweet potato)", grams: 500 },
      { name: "Asukal (sugar)", grams: 200 },
      { name: "Mantika (cooking oil)", grams: 300 },
    ],
    instructions: [
      "1. Peel and slice sweet potatoes.",
      "2. Fry until partially cooked.",
      "3. Add brown sugar.",
      "4. Cook until caramelized.",
      "5. Turn carefully to coat.",
      "6. Drain and serve."
    ]
  },
  {
    name: "Maruya",
    description: "Banana fritters fried until golden.",
    servings: 4,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Saging na saba (plantain)", grams: 400 },
      { name: "Harina (all-purpose flour)", grams: 120 },
      { name: "Asukal (sugar)", grams: 100 },
      { name: "Baking powder", grams: 4 },
      { name: "Itlog (egg)", grams: 50 },
      { name: "Mantika (cooking oil)", grams: 250 },
    ],
    instructions: [
      "1. Mash the bananas lightly.",
      "2. Mix flour, sugar, and baking powder.",
      "3. Add egg and water.",
      "4. Mix in bananas.",
      "5. Scoop batter into hot oil.",
      "6. Flatten and fry both sides until golden.",
      "7. Drain and serve."
    ]
  },
  {
    name: "Camote Fries",
    description: "Crispy sweet potato fries.",
    servings: 3,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Kamote (sweet potato)", grams: 500 },
      { name: "Gawgaw (cornstarch)", grams: 30 },
      { name: "Asin (salt)", grams: 3 },
      { name: "Mantika (cooking oil)", grams: 250 },
    ],
    instructions: [
      "1. Peel and cut sweet potatoes into strips.",
      "2. Soak briefly in water and dry thoroughly.",
      "3. Toss with cornstarch and salt.",
      "4. Fry until crisp and golden.",
      "5. Drain and serve with ketchup or cheese dip."
    ]
  },
  {
    name: "Carioca",
    description: "Fried glutinous rice balls coated in caramel.",
    servings: 4,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Glutinous rice flour", grams: 180 },
      { name: "Asukal (sugar)", grams: 100 },
      { name: "Mantika (cooking oil)", grams: 250 },
    ],
    instructions: [
      "1. Mix rice flour and water into a soft dough.",
      "2. Form small balls.",
      "3. Fry until golden.",
      "4. Combine brown sugar and water in a pan.",
      "5. Cook until syrupy.",
      "6. Add rice balls and coat with caramel.",
      "7. Serve warm."
    ]
  },
  {
    name: "Banana Fritters",
    description: "Sweet battered banana fritters.",
    servings: 4,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Saging na hinog (ripe banana)", grams: 400 },
      { name: "Harina (all-purpose flour)", grams: 120 },
      { name: "Asukal (sugar)", grams: 100 },
      { name: "Itlog (egg)", grams: 50 },
      { name: "Mantika (cooking oil)", grams: 250 },
    ],
    instructions: [
      "1. Mash bananas.",
      "2. Mix with flour, sugar, egg, and water.",
      "3. Heat oil.",
      "4. Drop spoonfuls of batter into oil.",
      "5. Fry until golden on both sides.",
      "6. Drain and serve."
    ]
  },
  {
    name: "Saging con Yelo",
    description: "Sweet saba bananas over crushed ice with evaporated milk.",
    servings: 4,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Saging na saba (plantain)", grams: 400 },
      { name: "Ice (crushed)", grams: 400 },
      { name: "Evaporated milk (evaporada)", grams: 240 },
      { name: "Asukal (sugar)", grams: 100 },
    ],
    instructions: [
      "1. Cook bananas with sugar and water until tender.",
      "2. Cool completely.",
      "3. Put crushed ice into glasses.",
      "4. Add bananas.",
      "5. Pour over evaporated milk.",
      "6. Serve immediately."
    ]
  },
  {
    name: "Banana Bread Filipino Style",
    description: "Moist banana bread loaf.",
    servings: 8,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Saging na hinog (ripe banana)", grams: 300 },
      { name: "Harina (all-purpose flour)", grams: 180 },
      { name: "Asukal (sugar)", grams: 100 },
      { name: "Itlog (egg)", grams: 50 },
      { name: "Mantikilya (butter)", grams: 120 },
      { name: "Baking soda", grams: 5 },
    ],
    instructions: [
      "1. Mash bananas.",
      "2. Mix in egg, butter, and sugar.",
      "3. Add flour and baking soda.",
      "4. Mix until just combined.",
      "5. Pour into a greased loaf pan.",
      "6. Bake at 180°C for 45–55 minutes.",
      "7. Cool before slicing."
    ]
  },
  {
    name: "Banana Turon Cheesecake Rolls",
    description: "Turon rolls with a creamy cream cheese filling.",
    servings: 3,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Saging na saba (plantain)", grams: 400 },
      { name: "Cream cheese", grams: 90 },
      { name: "Lumpia wrappers", grams: 100 },
      { name: "Asukal (sugar)", grams: 50 },
      { name: "Mantika (cooking oil)", grams: 250 },
    ],
    instructions: [
      "1. Place banana and cream cheese on each wrapper.",
      "2. Sprinkle with brown sugar.",
      "3. Roll tightly and seal.",
      "4. Fry until golden.",
      "5. Drain and serve warm."
    ]
  },
  {
    name: "Kwek-Kwek",
    description: "Orange-battered deep-fried quail eggs.",
    servings: 4,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Itlog ng pugo (quail eggs)", grams: 300 },
      { name: "Harina (all-purpose flour)", grams: 120 },
      { name: "Gawgaw (cornstarch)", grams: 60 },
      { name: "Baking powder", grams: 4 },
      { name: "Food coloring", grams: 3 },
      { name: "Asin (salt)", grams: 3 },
      { name: "Paminta (black pepper)", grams: 2 },
      { name: "Mantika (cooking oil)", grams: 300 },
    ],
    instructions: [
      "1. Peel eggs.",
      "2. Mix flour, cornstarch, baking powder, and seasonings.",
      "3. Add water and food coloring.",
      "4. Coat eggs in batter.",
      "5. Fry until crispy.",
      "6. Drain and serve with vinegar sauce."
    ]
  },
  {
    name: "Tokneneng",
    description: "Orange-battered deep-fried chicken eggs.",
    servings: 4,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Itlog (egg)", grams: 300 },
      { name: "Harina (all-purpose flour)", grams: 120 },
      { name: "Gawgaw (cornstarch)", grams: 60 },
      { name: "Baking powder", grams: 4 },
      { name: "Food coloring", grams: 3 },
      { name: "Mantika (cooking oil)", grams: 300 },
    ],
    instructions: [
      "1. Peel eggs.",
      "2. Prepare a thick orange batter.",
      "3. Dip eggs into batter.",
      "4. Fry until golden.",
      "5. Drain.",
      "6. Serve with vinegar or sweet sauce."
    ]
  },
  {
    name: "Fish Balls",
    description: "Street-style fried fish balls on skewers.",
    servings: 4,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Fish balls", grams: 500 },
      { name: "Mantika (cooking oil)", grams: 300 },
      { name: "Sweet chili sauce", grams: 60 },
      { name: "Suka (vinegar)", grams: 60 },
    ],
    instructions: [
      "1. Heat oil.",
      "2. Fry fish balls until golden and heated through.",
      "3. Drain.",
      "4. Place on skewers.",
      "5. Serve with your favorite street-food sauce."
    ]
  },
  {
    name: "Squid Balls",
    description: "Street-style fried squid balls on skewers.",
    servings: 4,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Squid balls", grams: 500 },
      { name: "Mantika (cooking oil)", grams: 300 },
      { name: "Sweet chili sauce", grams: 60 },
      { name: "Suka (vinegar)", grams: 60 },
    ],
    instructions: [
      "1. Heat oil over medium heat.",
      "2. Fry squid balls until golden.",
      "3. Drain well.",
      "4. Skewer if desired.",
      "5. Serve with dipping sauce."
    ]
  },
  {
    name: "Kikiam",
    description: "Crispy pork and vegetable rolls in bean curd sheets.",
    servings: 6,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Giniling na baboy (ground pork)", grams: 300 },
      { name: "Karot (carrot)", grams: 60 },
      { name: "Sibuyas (onion)", grams: 40 },
      { name: "Bawang (garlic)", grams: 10 },
      { name: "Toyo (soy sauce)", grams: 15 },
      { name: "Paminta (black pepper)", grams: 2 },
      { name: "Bean curd sheets (tawpe)", grams: 100 },
      { name: "Mantika (cooking oil)", grams: 300 },
    ],
    instructions: [
      "1. Mix pork, vegetables, and seasonings.",
      "2. Spread filling onto bean curd sheets.",
      "3. Roll tightly.",
      "4. Steam until cooked.",
      "5. Cool and slice.",
      "6. Fry until crispy.",
      "7. Serve with sauce."
    ]
  },
  {
    name: "Chicken Skin",
    description: "Crispy deep-fried chicken skin.",
    servings: 4,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Chicken skin (balat ng manok)", grams: 500 },
      { name: "Harina (all-purpose flour)", grams: 60 },
      { name: "Asin (salt)", grams: 3 },
      { name: "Paminta (black pepper)", grams: 2 },
      { name: "Mantika (cooking oil)", grams: 300 },
    ],
    instructions: [
      "1. Wash and dry chicken skin thoroughly.",
      "2. Season with salt and pepper.",
      "3. Lightly coat with flour.",
      "4. Fry until very crispy.",
      "5. Drain excess oil.",
      "6. Serve with vinegar or spicy sauce."
    ]
  },
  {
    name: "Isaw",
    description: "Grilled chicken intestines on skewers.",
    servings: 4,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Chicken intestines (isaw ng manok)", grams: 500 },
      { name: "Sibuyas (onion)", grams: 40 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Asin (salt)", grams: 5 },
      { name: "Paminta (black pepper)", grams: 3 },
      { name: "Suka (vinegar)", grams: 100 },
    ],
    instructions: [
      "1. Clean the intestines thoroughly.",
      "2. Boil with onion, garlic, salt, and pepper until tender.",
      "3. Drain and cool.",
      "4. Thread onto skewers.",
      "5. Grill until lightly charred.",
      "6. Serve with spiced vinegar."
    ]
  },
  {
    name: "Proben",
    description: "Crispy fried chicken proventriculus.",
    servings: 4,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Chicken proventriculus (proben)", grams: 500 },
      { name: "Harina (all-purpose flour)", grams: 60 },
      { name: "Asin (salt)", grams: 3 },
      { name: "Paminta (black pepper)", grams: 2 },
      { name: "Mantika (cooking oil)", grams: 300 },
    ],
    instructions: [
      "1. Clean the chicken parts.",
      "2. Boil until tender.",
      "3. Season with salt and pepper.",
      "4. Coat lightly with flour.",
      "5. Deep-fry until crispy.",
      "6. Serve with vinegar."
    ]
  },
  {
    name: "Tokwa Fries",
    description: "Crispy tofu sticks served with dipping sauce.",
    servings: 4,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Tokwa (tofu)", grams: 500 },
      { name: "Gawgaw (cornstarch)", grams: 60 },
      { name: "Asin (salt)", grams: 3 },
      { name: "Paminta (black pepper)", grams: 2 },
      { name: "Mantika (cooking oil)", grams: 300 },
    ],
    instructions: [
      "1. Cut tofu into sticks.",
      "2. Pat dry.",
      "3. Season and coat with cornstarch.",
      "4. Fry until crisp.",
      "5. Drain.",
      "6. Serve with sweet chili or vinegar sauce."
    ]
  },
  {
    name: "Tokwat Baboy",
    description: "Tofu and pork in a vinegar-soy dressing.",
    servings: 4,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Tokwa (tofu)", grams: 400 },
      { name: "Liempo (pork belly)", grams: 300 },
      { name: "Suka (vinegar)", grams: 120 },
      { name: "Toyo (soy sauce)", grams: 60 },
      { name: "Sibuyas (onion)", grams: 40 },
      { name: "Paminta (black pepper)", grams: 3 },
    ],
    instructions: [
      "1. Boil pork until tender.",
      "2. Cut into pieces.",
      "3. Fry tofu until golden.",
      "4. Combine vinegar, soy sauce, onion, and pepper.",
      "5. Add pork and tofu.",
      "6. Let sit briefly before serving."
    ]
  },
  {
    name: "Lumpiang Togue",
    description: "Crispy spring rolls filled with bean sprouts and vegetables.",
    servings: 6,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Togue (bean sprouts)", grams: 200 },
      { name: "Karot (carrot)", grams: 80 },
      { name: "Baguio beans", grams: 100 },
      { name: "Sibuyas (onion)", grams: 40 },
      { name: "Bawang (garlic)", grams: 10 },
      { name: "Toyo (soy sauce)", grams: 30 },
      { name: "Lumpia wrappers", grams: 200 },
      { name: "Mantika (cooking oil)", grams: 300 },
    ],
    instructions: [
      "1. Sauté garlic and onion.",
      "2. Add vegetables.",
      "3. Season with soy sauce.",
      "4. Cook briefly and cool.",
      "5. Wrap the filling.",
      "6. Fry until crispy.",
      "7. Serve with vinegar."
    ]
  },
  {
    name: "Lumpiang Sarwa",
    description: "Fresh vegetable lumpia with peanut sauce.",
    servings: 6,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Lumpia wrappers", grams: 200 },
      { name: "Repolyo (cabbage)", grams: 200 },
      { name: "Karot (carrot)", grams: 100 },
      { name: "Hipon (shrimp)", grams: 200 },
      { name: "Lettuce", grams: 80 },
      { name: "Peanut sauce", grams: 120 },
    ],
    instructions: [
      "1. Cook vegetables until tender-crisp.",
      "2. Add shrimp or chicken.",
      "3. Place lettuce and filling inside a wrapper.",
      "4. Roll carefully.",
      "5. Top with peanut sauce.",
      "6. Serve fresh."
    ]
  },
  {
    name: "Cheese Sticks",
    description: "Crispy lumpia-wrapped cheese sticks.",
    servings: 4,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Keso (cheese)", grams: 200 },
      { name: "Lumpia wrappers", grams: 200 },
      { name: "Mantika (cooking oil)", grams: 300 },
    ],
    instructions: [
      "1. Place cheese on wrapper.",
      "2. Roll tightly.",
      "3. Seal with water.",
      "4. Fry until golden.",
      "5. Drain.",
      "6. Serve with sweet chili sauce."
    ]
  },
  {
    name: "Potato Cheese Balls",
    description: "Fried potato and cheese balls.",
    servings: 4,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Patatas (potato)", grams: 400 },
      { name: "Keso (cheese)", grams: 120 },
      { name: "Itlog (egg)", grams: 50 },
      { name: "Panko breadcrumbs", grams: 120 },
      { name: "Asin (salt)", grams: 3 },
      { name: "Paminta (black pepper)", grams: 2 },
      { name: "Mantika (cooking oil)", grams: 300 },
    ],
    instructions: [
      "1. Boil and mash potatoes.",
      "2. Mix with cheese and seasonings.",
      "3. Form balls.",
      "4. Dip in beaten egg.",
      "5. Coat with breadcrumbs.",
      "6. Fry until golden."
    ]
  },
  {
    name: "Corn Cheese Balls",
    description: "Fried corn and cheese balls.",
    servings: 4,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Mais (corn)", grams: 200 },
      { name: "Keso (cheese)", grams: 120 },
      { name: "Harina (all-purpose flour)", grams: 60 },
      { name: "Itlog (egg)", grams: 50 },
      { name: "Panko breadcrumbs", grams: 120 },
      { name: "Mantika (cooking oil)", grams: 300 },
    ],
    instructions: [
      "1. Mix corn, cheese, flour, and egg.",
      "2. Form into balls.",
      "3. Coat with breadcrumbs.",
      "4. Fry until golden.",
      "5. Drain and serve."
    ]
  },
  {
    name: "Chicken Cheese Balls",
    description: "Fried shredded chicken and cheese balls.",
    servings: 4,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Manok (chicken)", grams: 400 },
      { name: "Keso (cheese)", grams: 120 },
      { name: "Itlog (egg)", grams: 50 },
      { name: "Panko breadcrumbs", grams: 120 },
      { name: "Asin (salt)", grams: 3 },
      { name: "Paminta (black pepper)", grams: 2 },
      { name: "Mantika (cooking oil)", grams: 300 },
    ],
    instructions: [
      "1. Combine chicken and cheese.",
      "2. Season.",
      "3. Form small balls.",
      "4. Dip in egg.",
      "5. Coat with breadcrumbs.",
      "6. Fry until golden."
    ]
  },
  {
    name: "Ube Cheese Lumpia",
    description: "Crispy lumpia with ube halaya and cheese.",
    servings: 4,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Ube halaya", grams: 240 },
      { name: "Keso (cheese)", grams: 150 },
      { name: "Lumpia wrappers", grams: 200 },
      { name: "Asukal (sugar)", grams: 60 },
      { name: "Mantika (cooking oil)", grams: 300 },
    ],
    instructions: [
      "1. Place ube and cheese on each wrapper.",
      "2. Sprinkle with sugar.",
      "3. Roll and seal.",
      "4. Fry until golden and crisp.",
      "5. Drain and serve warm."
    ]
  },
  {
    name: "Mango Cheese Lumpia",
    description: "Crispy lumpia with fresh mango and cheese.",
    servings: 4,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Mangga (mango)", grams: 300 },
      { name: "Keso (cheese)", grams: 150 },
      { name: "Lumpia wrappers", grams: 200 },
      { name: "Asukal (sugar)", grams: 60 },
      { name: "Mantika (cooking oil)", grams: 300 },
    ],
    instructions: [
      "1. Slice mango into strips.",
      "2. Place mango and cheese on wrapper.",
      "3. Sprinkle lightly with sugar.",
      "4. Roll and seal.",
      "5. Fry until golden.",
      "6. Drain before serving."
    ]
  },
  {
    name: "Pancit Canton",
    description: "Stir-fried canton noodles with meat and vegetables.",
    servings: 4,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Pancit canton noodles", grams: 250 },
      { name: "Manok (chicken)", grams: 200 },
      { name: "Karot (carrot)", grams: 100 },
      { name: "Repolyo (cabbage)", grams: 150 },
      { name: "Atsal (bell pepper)", grams: 80 },
      { name: "Toyo (soy sauce)", grams: 30 },
      { name: "Bawang (garlic)", grams: 10 },
    ],
    instructions: [
      "1. Sauté garlic and meat.",
      "2. Add vegetables.",
      "3. Add water and soy sauce.",
      "4. Add noodles.",
      "5. Toss until noodles are tender and liquid is absorbed.",
      "6. Serve hot."
    ]
  },
  {
    name: "Pancit Bihon",
    description: "Stir-fried rice noodles with chicken and vegetables.",
    servings: 4,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Pancit bihon (rice noodles)", grams: 250 },
      { name: "Manok (chicken)", grams: 200 },
      { name: "Karot (carrot)", grams: 100 },
      { name: "Repolyo (cabbage)", grams: 150 },
      { name: "Toyo (soy sauce)", grams: 30 },
      { name: "Chicken broth", grams: 480 },
      { name: "Bawang (garlic)", grams: 10 },
    ],
    instructions: [
      "1. Sauté garlic and chicken.",
      "2. Add vegetables.",
      "3. Add broth and soy sauce.",
      "4. Add soaked bihon.",
      "5. Cook until noodles absorb the liquid.",
      "6. Serve with calamansi."
    ]
  },
  {
    name: "Pancit Palabok",
    description: "Rice noodles with thick shrimp sauce and toppings.",
    servings: 4,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Palabok noodles", grams: 250 },
      { name: "Shrimp broth", grams: 480 },
      { name: "Harina (all-purpose flour)", grams: 30 },
      { name: "Atsuete (annatto seeds)", grams: 10 },
      { name: "Hipon (shrimp)", grams: 200 },
      { name: "Itlog (egg)", grams: 100 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Spring onions (dahon ng sibuyas)", grams: 30 },
    ],
    instructions: [
      "1. Cook noodles and drain.",
      "2. Prepare shrimp broth.",
      "3. Thicken broth with flour.",
      "4. Add annatto oil.",
      "5. Pour sauce over noodles.",
      "6. Top with shrimp, egg, garlic, and spring onions."
    ]
  },
  {
    name: "Pancit Malabon",
    description: "Thick rice noodles with seafood sauce and toppings.",
    servings: 4,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Palabok noodles", grams: 250 },
      { name: "Shrimp broth", grams: 480 },
      { name: "Hipon (shrimp)", grams: 200 },
      { name: "Tinapa flakes (smoked fish)", grams: 100 },
      { name: "Itlog (egg)", grams: 100 },
      { name: "Bawang (garlic)", grams: 15 },
    ],
    instructions: [
      "1. Cook noodles.",
      "2. Prepare a thick seafood sauce.",
      "3. Place noodles on a serving plate.",
      "4. Pour sauce over them.",
      "5. Add seafood and toppings.",
      "6. Serve warm."
    ]
  },
  {
    name: "Pancit Habhab",
    description: "Lucban-style noodles served on banana leaves.",
    servings: 4,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Lucban noodles (habhab)", grams: 250 },
      { name: "Baboy (pork, kasim/shoulder)", grams: 200 },
      { name: "Repolyo (cabbage)", grams: 150 },
      { name: "Karot (carrot)", grams: 100 },
      { name: "Toyo (soy sauce)", grams: 30 },
      { name: "Bawang (garlic)", grams: 10 },
      { name: "Sibuyas (onion)", grams: 40 },
    ],
    instructions: [
      "1. Sauté garlic and onion.",
      "2. Add pork.",
      "3. Add vegetables.",
      "4. Add noodles and soy sauce.",
      "5. Toss until cooked.",
      "6. Serve traditionally on a banana leaf."
    ]
  },
  {
    name: "Filipino Spaghetti",
    description: "Sweet-style spaghetti with hotdogs and banana ketchup.",
    servings: 6,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Spaghetti noodles", grams: 250 },
      { name: "Giniling na baboy (ground pork)", grams: 250 },
      { name: "Hotdogs (Filipino-style)", grams: 200 },
      { name: "Tomato sauce", grams: 240 },
      { name: "Banana ketchup", grams: 120 },
      { name: "Asukal (sugar)", grams: 15 },
      { name: "Keso (cheese)", grams: 100 },
    ],
    instructions: [
      "1. Cook spaghetti.",
      "2. Brown the meat.",
      "3. Add hotdogs.",
      "4. Add tomato sauce and banana ketchup.",
      "5. Add sugar.",
      "6. Simmer for 10–15 minutes.",
      "7. Toss with pasta.",
      "8. Add cheese."
    ]
  },
  {
    name: "Arroz Caldo",
    description: "Savory chicken rice porridge with ginger and garlic.",
    servings: 4,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Bigas (uncooked rice)", grams: 200 },
      { name: "Manok (chicken)", grams: 500 },
      { name: "Luya (ginger)", grams: 20 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Sibuyas (onion)", grams: 40 },
      { name: "Patis (fish sauce)", grams: 15 },
      { name: "Itlog (egg)", grams: 100 },
    ],
    instructions: [
      "1. Sauté garlic, onion, and ginger.",
      "2. Add chicken.",
      "3. Add rice and broth.",
      "4. Simmer until rice becomes soft.",
      "5. Season with fish sauce.",
      "6. Serve with boiled egg and toasted garlic."
    ]
  },
  {
    name: "Goto",
    description: "Savory beef tripe rice porridge.",
    servings: 4,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Bigas (uncooked rice)", grams: 200 },
      { name: "Beef tripe (tuwalya)", grams: 250 },
      { name: "Luya (ginger)", grams: 20 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Sibuyas (onion)", grams: 40 },
      { name: "Beef broth", grams: 1200 },
      { name: "Patis (fish sauce)", grams: 15 },
    ],
    instructions: [
      "1. Clean and boil tripe until tender.",
      "2. Sauté aromatics.",
      "3. Add rice and broth.",
      "4. Add chopped tripe.",
      "5. Simmer until thick.",
      "6. Season and serve hot."
    ]
  },
  {
    name: "Lugaw",
    description: "Simple Filipino rice porridge with ginger and egg.",
    servings: 4,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Bigas (uncooked rice)", grams: 200 },
      { name: "Luya (ginger)", grams: 15 },
      { name: "Bawang (garlic)", grams: 10 },
      { name: "Asin (salt)", grams: 3 },
      { name: "Itlog (egg)", grams: 100 },
    ],
    instructions: [
      "1. Combine rice and water.",
      "2. Add ginger and garlic.",
      "3. Simmer until creamy.",
      "4. Season with salt.",
      "5. Top with boiled egg.",
      "6. Add soy sauce or fish sauce if desired."
    ]
  },
  {
    name: "Fried Siomai",
    description: "Steamed then fried pork siomai.",
    servings: 6,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Giniling na baboy (ground pork)", grams: 500 },
      { name: "Karot (carrot)", grams: 80 },
      { name: "Sibuyas (onion)", grams: 40 },
      { name: "Itlog (egg)", grams: 50 },
      { name: "Toyo (soy sauce)", grams: 30 },
      { name: "Paminta (black pepper)", grams: 3 },
      { name: "Siomai wrappers", grams: 200 },
      { name: "Mantika (cooking oil)", grams: 300 },
    ],
    instructions: [
      "1. Mix filling ingredients.",
      "2. Wrap in siomai wrappers.",
      "3. Steam until cooked.",
      "4. Cool slightly.",
      "5. Fry until crispy.",
      "6. Serve with chili sauce."
    ]
  },
  {
    name: "Bibingka",
    description: "Classic Filipino baked rice cake with cheese and salted egg.",
    servings: 6,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Rice flour", grams: 240 },
      { name: "Asukal (sugar)", grams: 100 },
      { name: "Gata (coconut milk)", grams: 240 },
      { name: "Itlog (egg)", grams: 100 },
      { name: "Baking powder", grams: 5 },
      { name: "Keso (cheese)", grams: 80 },
      { name: "Maalat na itlog (salted egg)", grams: 60 },
    ],
    instructions: [
      "1. Mix flour, sugar, and baking powder.",
      "2. Add eggs and coconut milk.",
      "3. Pour into banana-leaf-lined molds.",
      "4. Top with cheese and salted egg.",
      "5. Bake at 200°C until cooked and lightly browned.",
      "6. Brush with butter before serving."
    ]
  },
  {
    name: "Puto",
    description: "Classic steamed Filipino rice cake.",
    servings: 8,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Rice flour", grams: 240 },
      { name: "Asukal (sugar)", grams: 100 },
      { name: "Baking powder", grams: 12 },
      { name: "Gata (coconut milk)", grams: 120 },
    ],
    instructions: [
      "1. Combine dry ingredients.",
      "2. Add liquids.",
      "3. Mix until smooth.",
      "4. Pour into molds.",
      "5. Steam for 12–15 minutes.",
      "6. Cool slightly and serve."
    ]
  },
  {
    name: "Puto Cheese",
    description: "Steamed puto topped with cheese.",
    servings: 8,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Harina (all-purpose flour)", grams: 240 },
      { name: "Asukal (sugar)", grams: 100 },
      { name: "Baking powder", grams: 12 },
      { name: "Fresh milk (gatas)", grams: 240 },
      { name: "Itlog (egg)", grams: 100 },
      { name: "Keso (cheese)", grams: 100 },
    ],
    instructions: [
      "1. Mix flour, sugar, and baking powder.",
      "2. Add milk and eggs.",
      "3. Mix until smooth.",
      "4. Pour into molds.",
      "5. Add cheese on top.",
      "6. Steam 12–15 minutes."
    ]
  },
  {
    name: "Puto Pao",
    description: "Steamed puto filled with savory pork filling.",
    servings: 8,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Harina (all-purpose flour)", grams: 240 },
      { name: "Asukal (sugar)", grams: 100 },
      { name: "Giniling na baboy (ground pork)", grams: 250 },
      { name: "Sibuyas (onion)", grams: 40 },
      { name: "Bawang (garlic)", grams: 10 },
      { name: "Toyo (soy sauce)", grams: 30 },
      { name: "Asukal (sugar)", grams: 15 },
    ],
    instructions: [
      "1. Prepare savory pork filling by sautéing pork, garlic, and onion.",
      "2. Add soy sauce and a little sugar.",
      "3. Pour puto batter halfway into molds.",
      "4. Add filling.",
      "5. Cover with more batter.",
      "6. Steam until cooked."
    ]
  },
  {
    name: "Kutsinta",
    description: "Chewy brown rice cakes topped with coconut.",
    servings: 8,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Rice flour", grams: 120 },
      { name: "Harina (all-purpose flour)", grams: 60 },
      { name: "Asukal (sugar)", grams: 200 },
      { name: "Lihiya (lye water)", grams: 5 },
      { name: "Atsuete (annatto seeds)", grams: 10 },
      { name: "Niyog (grated coconut)", grams: 100 },
    ],
    instructions: [
      "1. Mix flour, sugar, and water.",
      "2. Add annatto and lye water.",
      "3. Strain.",
      "4. Pour into molds.",
      "5. Steam for 20–25 minutes.",
      "6. Cool and top with coconut."
    ]
  },
  {
    name: "Palitaw",
    description: "Boiled rice cakes coated in coconut and sugar.",
    servings: 6,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Glutinous rice flour", grams: 240 },
      { name: "Niyog (grated coconut)", grams: 100 },
      { name: "Asukal (sugar)", grams: 100 },
      { name: "Linga (sesame seeds)", grams: 20 },
    ],
    instructions: [
      "1. Mix flour with enough water to make dough.",
      "2. Flatten small pieces.",
      "3. Boil water.",
      "4. Drop rice cakes into water.",
      "5. Remove when they float.",
      "6. Coat with coconut, sugar, and sesame."
    ]
  },
  {
    name: "Suman",
    description: "Sweet glutinous rice steamed in banana leaves.",
    servings: 8,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Malagkit (glutinous rice)", grams: 400 },
      { name: "Gata (coconut milk)", grams: 400 },
      { name: "Asukal (sugar)", grams: 100 },
      { name: "Dahon ng saging (banana leaves)", grams: 100 },
    ],
    instructions: [
      "1. Cook rice with coconut milk and sugar.",
      "2. Soften banana leaves.",
      "3. Place rice onto leaves.",
      "4. Roll and fold securely.",
      "5. Steam for 45–60 minutes.",
      "6. Serve with sugar or coconut caramel."
    ]
  },
  {
    name: "Suman sa Lihiya",
    description: "Glutinous rice cakes with lye water steamed in banana leaves.",
    servings: 8,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Malagkit (glutinous rice)", grams: 400 },
      { name: "Lihiya (lye water)", grams: 5 },
      { name: "Gata (coconut milk)", grams: 400 },
      { name: "Dahon ng saging (banana leaves)", grams: 100 },
      { name: "Asukal (sugar)", grams: 100 },
    ],
    instructions: [
      "1. Mix rice with coconut milk and lye water.",
      "2. Wrap portions in banana leaves.",
      "3. Steam until rice is completely cooked.",
      "4. Cool slightly.",
      "5. Serve with sugar or coconut caramel."
    ]
  },
  {
    name: "Sapin-Sapin",
    description: "Layered glutinous rice cake with ube and food coloring.",
    servings: 10,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Glutinous rice flour", grams: 360 },
      { name: "Gata (coconut milk)", grams: 480 },
      { name: "Asukal (sugar)", grams: 200 },
      { name: "Ube flavoring", grams: 5 },
      { name: "Food coloring", grams: 3 },
    ],
    instructions: [
      "1. Mix flour, coconut milk, and sugar.",
      "2. Divide into three portions.",
      "3. Color/flavor each portion differently.",
      "4. Steam the first layer.",
      "5. Add the second layer and steam.",
      "6. Add the third layer and steam until fully cooked.",
      "7. Cool before slicing."
    ]
  },
  {
    name: "Biko",
    description: "Sweet glutinous rice cake with coconut caramel topping.",
    servings: 8,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Malagkit (glutinous rice)", grams: 400 },
      { name: "Gata (coconut milk)", grams: 480 },
      { name: "Asukal (sugar)", grams: 200 },
      { name: "Asin (salt)", grams: 2 },
    ],
    instructions: [
      "1. Cook glutinous rice.",
      "2. Combine coconut milk and brown sugar.",
      "3. Add rice.",
      "4. Stir over low heat until thick.",
      "5. Transfer to a greased tray.",
      "6. Cool and slice."
    ]
  },
  {
    name: "Ginataang Mais",
    description: "Sweet corn and glutinous rice in coconut milk.",
    servings: 4,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Mais (corn)", grams: 300 },
      { name: "Malagkit (glutinous rice)", grams: 200 },
      { name: "Gata (coconut milk)", grams: 960 },
      { name: "Asukal (sugar)", grams: 100 },
      { name: "Asin (salt)", grams: 2 },
    ],
    instructions: [
      "1. Cook rice in coconut milk.",
      "2. Add corn.",
      "3. Add sugar and salt.",
      "4. Simmer until creamy.",
      "5. Serve warm or chilled."
    ]
  },
  {
    name: "Ginataang Bilo-Bilo",
    description: "Sweet coconut milk soup with rice balls and root crops.",
    servings: 4,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Glutinous rice flour", grams: 120 },
      { name: "Gata (coconut milk)", grams: 480 },
      { name: "Saging na saba (plantain)", grams: 200 },
      { name: "Kamote (sweet potato)", grams: 200 },
      { name: "Langka (jackfruit)", grams: 100 },
      { name: "Asukal (sugar)", grams: 100 },
    ],
    instructions: [
      "1. Make small rice balls from glutinous rice flour and water.",
      "2. Simmer coconut milk.",
      "3. Add sweet potato and rice balls.",
      "4. Add banana and jackfruit.",
      "5. Sweeten to taste.",
      "6. Cook until everything is tender."
    ]
  },
  {
    name: "Kalamay",
    description: "Sticky sweet glutinous rice cake.",
    servings: 8,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Glutinous rice flour", grams: 240 },
      { name: "Gata (coconut milk)", grams: 480 },
      { name: "Asukal (sugar)", grams: 200 },
      { name: "Asin (salt)", grams: 2 },
    ],
    instructions: [
      "1. Mix all ingredients.",
      "2. Cook over low heat.",
      "3. Stir continuously.",
      "4. Continue until very thick and sticky.",
      "5. Transfer to a greased dish.",
      "6. Cool before serving."
    ]
  },
  {
    name: "Maja Blanca",
    description: "Creamy coconut corn pudding.",
    servings: 8,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Gata (coconut milk)", grams: 960 },
      { name: "Gawgaw (cornstarch)", grams: 120 },
      { name: "Asukal (sugar)", grams: 180 },
      { name: "Mais (corn)", grams: 200 },
      { name: "Niyog (grated coconut)", grams: 60 },
    ],
    instructions: [
      "1. Combine coconut milk, sugar, and cornstarch.",
      "2. Cook over medium-low heat while stirring.",
      "3. Add corn.",
      "4. Continue until thick.",
      "5. Pour into a dish.",
      "6. Chill until firm.",
      "7. Top with toasted coconut."
    ]
  },
  {
    name: "Pichi-Pichi",
    description: "Steamed cassava cakes coated in grated coconut.",
    servings: 8,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Kamoteng kahoy (cassava)", grams: 400 },
      { name: "Asukal (sugar)", grams: 100 },
      { name: "Lihiya (lye water)", grams: 5 },
      { name: "Niyog (grated coconut)", grams: 100 },
    ],
    instructions: [
      "1. Mix cassava, water, sugar, and lye water.",
      "2. Pour into molds.",
      "3. Steam 30–40 minutes.",
      "4. Cool.",
      "5. Roll in grated coconut."
    ]
  },
  {
    name: "Cassava Cake",
    description: "Baked cassava cake with coconut milk and condensed milk.",
    servings: 10,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Kamoteng kahoy (cassava)", grams: 400 },
      { name: "Condensed milk (condensada)", grams: 390 },
      { name: "Gata (coconut milk)", grams: 400 },
      { name: "Itlog (egg)", grams: 100 },
      { name: "Asukal (sugar)", grams: 100 },
    ],
    instructions: [
      "1. Combine all ingredients.",
      "2. Pour into a greased baking dish.",
      "3. Bake at 180°C for about 45–60 minutes.",
      "4. Cool before slicing.",
      "5. Add a coconut-milk topping if desired."
    ]
  },
  {
    name: "Bibingkang Kanin",
    description: "Baked sweet rice cake with cheese topping.",
    servings: 8,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Kanin (cooked rice)", grams: 400 },
      { name: "Gata (coconut milk)", grams: 240 },
      { name: "Asukal (sugar)", grams: 100 },
      { name: "Itlog (egg)", grams: 100 },
      { name: "Keso (cheese)", grams: 80 },
    ],
    instructions: [
      "1. Blend or mash cooked rice.",
      "2. Mix with coconut milk, sugar, and eggs.",
      "3. Pour into a greased pan.",
      "4. Top with cheese.",
      "5. Bake at 180°C until firm and lightly browned.",
      "6. Cool before slicing."
    ]
  },
  {
    name: "Sinukmani",
    description: "Sticky sweet rice cake with coconut milk.",
    servings: 8,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Malagkit (glutinous rice)", grams: 400 },
      { name: "Gata (coconut milk)", grams: 480 },
      { name: "Asukal (sugar)", grams: 200 },
      { name: "Asin (salt)", grams: 2 },
    ],
    instructions: [
      "1. Cook rice with coconut milk.",
      "2. Add sugar and salt.",
      "3. Stir until thick and sticky.",
      "4. Transfer to a tray.",
      "5. Cool and slice."
    ]
  },
  {
    name: "Espasol",
    description: "Cylindrical rice cakes coated in toasted rice flour.",
    servings: 8,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Glutinous rice flour", grams: 240 },
      { name: "Gata (coconut milk)", grams: 240 },
      { name: "Asukal (sugar)", grams: 100 },
      { name: "Rice flour", grams: 100 },
    ],
    instructions: [
      "1. Toast rice flour until lightly fragrant.",
      "2. Cook coconut milk and sugar.",
      "3. Gradually add rice flour.",
      "4. Stir until thick.",
      "5. Spread onto a tray.",
      "6. Cool and cut into pieces.",
      "7. Coat with toasted rice flour."
    ]
  },
  {
    name: "Tibok-Tibok",
    description: "Creamy carabao milk pudding with toasted coconut.",
    servings: 8,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Gatas ng kalabaw (carabao milk)", grams: 960 },
      { name: "Asukal (sugar)", grams: 100 },
      { name: "Gawgaw (cornstarch)", grams: 60 },
      { name: "Asin (salt)", grams: 2 },
      { name: "Niyog (grated coconut)", grams: 50 },
    ],
    instructions: [
      "1. Mix milk, sugar, and cornstarch.",
      "2. Cook over low heat.",
      "3. Stir constantly until thick.",
      "4. Pour into a dish.",
      "5. Chill until firm.",
      "6. Top with toasted coconut if desired."
    ]
  },
  {
    name: "Ube Halaya",
    description: "Rich and creamy purple yam jam.",
    servings: 8,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Ube (purple yam)", grams: 500 },
      { name: "Condensed milk (condensada)", grams: 390 },
      { name: "Gata (coconut milk)", grams: 240 },
      { name: "Asukal (sugar)", grams: 100 },
      { name: "Mantikilya (butter)", grams: 30 },
    ],
    instructions: [
      "1. Combine all ingredients in a pan.",
      "2. Cook over low heat.",
      "3. Stir continuously.",
      "4. Cook until very thick.",
      "5. Add butter.",
      "6. Transfer to a container and cool."
    ]
  },
  {
    name: "Kalamay Ube",
    description: "Sticky ube glutinous rice cake.",
    servings: 8,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Ube (purple yam)", grams: 200 },
      { name: "Glutinous rice flour", grams: 240 },
      { name: "Gata (coconut milk)", grams: 480 },
      { name: "Asukal (sugar)", grams: 200 },
    ],
    instructions: [
      "1. Mix all ingredients.",
      "2. Cook over low heat.",
      "3. Stir continuously.",
      "4. Continue until sticky and thick.",
      "5. Transfer to a greased tray.",
      "6. Cool and slice."
    ]
  },
  {
    name: "Camote Halaya",
    description: "Sweet mashed sweet potato jam.",
    servings: 8,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Kamote (sweet potato)", grams: 500 },
      { name: "Gata (coconut milk)", grams: 240 },
      { name: "Asukal (sugar)", grams: 100 },
      { name: "Mantikilya (butter)", grams: 30 },
    ],
    instructions: [
      "1. Mash sweet potatoes.",
      "2. Combine with coconut milk and sugar.",
      "3. Cook over low heat.",
      "4. Stir until thick.",
      "5. Add butter.",
      "6. Cool and serve."
    ]
  },
  {
    name: "Pastillas de Leche",
    description: "Soft milk candy cylinders coated in sugar.",
    servings: 8,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Powdered milk (gatas na pulbos)", grams: 120 },
      { name: "Condensed milk (condensada)", grams: 200 },
      { name: "Asukal (sugar)", grams: 100 },
    ],
    instructions: [
      "1. Mix powdered milk and condensed milk.",
      "2. Knead into a soft dough.",
      "3. Shape into small cylinders or balls.",
      "4. Roll in sugar.",
      "5. Wrap individually if desired.",
      "6. Chill before serving."
    ]
  },
  {
    name: "Yema",
    description: "Sweet custard candy balls rolled in sugar.",
    servings: 8,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Condensed milk (condensada)", grams: 390 },
      { name: "Itlog (egg)", grams: 80 },
      { name: "Mantikilya (butter)", grams: 15 },
      { name: "Asukal (sugar)", grams: 100 },
    ],
    instructions: [
      "1. Combine condensed milk and egg yolks.",
      "2. Cook over low heat.",
      "3. Stir constantly.",
      "4. Add butter.",
      "5. Continue until thick.",
      "6. Cool.",
      "7. Form into balls and roll in sugar."
    ]
  },
  {
    name: "Polvoron",
    description: "Crumbly milk powder candy.",
    servings: 10,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Harina (all-purpose flour)", grams: 240 },
      { name: "Powdered milk (gatas na pulbos)", grams: 120 },
      { name: "Asukal (sugar)", grams: 200 },
      { name: "Mantikilya (butter)", grams: 200 },
    ],
    instructions: [
      "1. Toast flour in a dry pan.",
      "2. Add powdered milk and sugar.",
      "3. Mix thoroughly.",
      "4. Add melted butter.",
      "5. Press mixture firmly into polvoron molds.",
      "6. Unmold carefully.",
      "7. Chill before serving."
    ]
  },
  {
    name: "Peanut Kisses",
    description: "Baked peanut meringue kisses.",
    servings: 8,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Mani (peanuts)", grams: 200 },
      { name: "Asukal (sugar)", grams: 100 },
      { name: "Itlog (egg)", grams: 100 },
      { name: "Vanilla extract", grams: 5 },
    ],
    instructions: [
      "1. Grind peanuts finely.",
      "2. Beat egg whites until foamy.",
      "3. Add sugar and vanilla.",
      "4. Fold in peanuts.",
      "5. Form small mounds.",
      "6. Bake at 160°C until lightly golden.",
      "7. Cool before serving."
    ]
  },
  {
    name: "Turones de Mani",
    description: "Crispy lumpia rolls filled with peanut-sugar mixture.",
    servings: 8,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Mani (peanuts)", grams: 200 },
      { name: "Asukal (sugar)", grams: 100 },
      { name: "Lumpia wrappers", grams: 200 },
      { name: "Mantika (cooking oil)", grams: 300 },
    ],
    instructions: [
      "1. Mix peanuts and sugar.",
      "2. Place a small amount on each wrapper.",
      "3. Roll tightly.",
      "4. Seal with water.",
      "5. Fry until golden.",
      "6. Drain and cool."
    ]
  },
  {
    name: "Carioca with Coconut Caramel",
    description: "Glutinous rice balls in coconut caramel sauce.",
    servings: 4,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Glutinous rice flour", grams: 180 },
      { name: "Asukal (sugar)", grams: 100 },
      { name: "Gata (coconut milk)", grams: 60 },
      { name: "Mantika (cooking oil)", grams: 250 },
    ],
    instructions: [
      "1. Form rice-flour dough into balls.",
      "2. Fry until golden.",
      "3. Combine brown sugar and coconut milk.",
      "4. Cook until syrupy.",
      "5. Add fried balls.",
      "6. Coat thoroughly and serve."
    ]
  },
  {
    name: "Mais con Yelo",
    description: "Sweet corn over crushed ice with milk.",
    servings: 4,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Mais (corn)", grams: 300 },
      { name: "Ice (crushed)", grams: 400 },
      { name: "Evaporated milk (evaporada)", grams: 240 },
      { name: "Asukal (sugar)", grams: 100 },
      { name: "Keso (cheese)", grams: 50 },
    ],
    instructions: [
      "1. Place corn in a glass.",
      "2. Add crushed ice.",
      "3. Add sugar.",
      "4. Pour in evaporated milk.",
      "5. Add cheese if desired.",
      "6. Mix before eating."
    ]
  },
  {
    name: "Pandesal",
    description: "Classic Filipino bread rolls coated in breadcrumbs.",
    servings: 12,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Harina (all-purpose flour)", grams: 480 },
      { name: "Asukal (sugar)", grams: 100 },
      { name: "Asin (salt)", grams: 5 },
      { name: "Yeast (lebadura)", grams: 10 },
      { name: "Fresh milk (gatas)", grams: 360 },
      { name: "Itlog (egg)", grams: 50 },
      { name: "Mantikilya (butter)", grams: 60 },
      { name: "Panko breadcrumbs", grams: 100 },
    ],
    instructions: [
      "1. Mix flour, sugar, salt, and yeast.",
      "2. Add milk, egg, and butter.",
      "3. Knead until smooth.",
      "4. Let rise for about 1 hour.",
      "5. Shape into small rolls.",
      "6. Coat with breadcrumbs.",
      "7. Let rise again.",
      "8. Bake at 180°C for 15–20 minutes."
    ]
  },
  {
    name: "Spanish Bread",
    description: "Sweet rolled bread with butter-sugar-breadcrumb filling.",
    servings: 12,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Harina (all-purpose flour)", grams: 480 },
      { name: "Asukal (sugar)", grams: 100 },
      { name: "Yeast (lebadura)", grams: 10 },
      { name: "Fresh milk (gatas)", grams: 240 },
      { name: "Itlog (egg)", grams: 50 },
      { name: "Mantikilya (butter)", grams: 120 },
      { name: "Panko breadcrumbs", grams: 60 },
    ],
    instructions: [
      "1. Prepare pandesal dough.",
      "2. Mix butter, sugar, and breadcrumbs for filling.",
      "3. Flatten dough portions.",
      "4. Add filling.",
      "5. Roll into logs.",
      "6. Let rise.",
      "7. Bake at 180°C until golden."
    ]
  },
  {
    name: "Ensaymada",
    description: "Soft coiled brioche topped with butter, sugar, and cheese.",
    servings: 10,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Harina (all-purpose flour)", grams: 360 },
      { name: "Asukal (sugar)", grams: 100 },
      { name: "Yeast (lebadura)", grams: 10 },
      { name: "Itlog (egg)", grams: 100 },
      { name: "Fresh milk (gatas)", grams: 180 },
      { name: "Mantikilya (butter)", grams: 60 },
      { name: "Keso (cheese)", grams: 80 },
    ],
    instructions: [
      "1. Mix flour, sugar, and yeast.",
      "2. Add eggs, milk, and butter.",
      "3. Knead until smooth.",
      "4. Let rise.",
      "5. Form into coils.",
      "6. Bake at 180°C until golden.",
      "7. Brush with butter.",
      "8. Top with sugar and cheese."
    ]
  },
  {
    name: "Pan de Coco",
    description: "Sweet bread rolls filled with coconut and brown sugar.",
    servings: 10,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Harina (all-purpose flour)", grams: 360 },
      { name: "Yeast (lebadura)", grams: 10 },
      { name: "Asukal (sugar)", grams: 100 },
      { name: "Fresh milk (gatas)", grams: 180 },
      { name: "Itlog (egg)", grams: 50 },
      { name: "Mantikilya (butter)", grams: 60 },
      { name: "Niyog (grated coconut)", grams: 180 },
      { name: "Asukal (sugar)", grams: 100 },
    ],
    instructions: [
      "1. Prepare soft bread dough.",
      "2. Let rise until doubled.",
      "3. Cook coconut and brown sugar until sticky.",
      "4. Divide dough into portions.",
      "5. Fill with coconut mixture.",
      "6. Seal and shape.",
      "7. Bake at 180°C until golden."
    ]
  },
  {
    name: "Pan de Ube",
    description: "Sweet bread rolls filled with ube halaya.",
    servings: 10,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Harina (all-purpose flour)", grams: 360 },
      { name: "Yeast (lebadura)", grams: 10 },
      { name: "Asukal (sugar)", grams: 100 },
      { name: "Fresh milk (gatas)", grams: 180 },
      { name: "Itlog (egg)", grams: 50 },
      { name: "Mantikilya (butter)", grams: 60 },
      { name: "Ube halaya", grams: 200 },
    ],
    instructions: [
      "1. Prepare and allow bread dough to rise.",
      "2. Divide into pieces.",
      "3. Flatten each piece.",
      "4. Add ube filling.",
      "5. Seal and shape.",
      "6. Brush with egg wash.",
      "7. Bake at 180°C until golden."
    ]
  },
  {
    name: "Ube Cheese Bread",
    description: "Sweet bread rolls filled with ube and cheese.",
    servings: 10,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Harina (all-purpose flour)", grams: 360 },
      { name: "Yeast (lebadura)", grams: 10 },
      { name: "Asukal (sugar)", grams: 100 },
      { name: "Fresh milk (gatas)", grams: 180 },
      { name: "Itlog (egg)", grams: 50 },
      { name: "Mantikilya (butter)", grams: 60 },
      { name: "Ube halaya", grams: 200 },
      { name: "Keso (cheese)", grams: 100 },
    ],
    instructions: [
      "1. Divide bread dough.",
      "2. Add ube and cheese.",
      "3. Seal carefully.",
      "4. Place on baking tray.",
      "5. Let rise.",
      "6. Brush with egg wash.",
      "7. Bake at 180°C until golden."
    ]
  },
  {
    name: "Cheese Ensaymada",
    description: "Ensaymada generously topped with butter, sugar, and cheese.",
    servings: 10,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Harina (all-purpose flour)", grams: 360 },
      { name: "Asukal (sugar)", grams: 100 },
      { name: "Yeast (lebadura)", grams: 10 },
      { name: "Itlog (egg)", grams: 100 },
      { name: "Fresh milk (gatas)", grams: 180 },
      { name: "Mantikilya (butter)", grams: 120 },
      { name: "Keso (cheese)", grams: 100 },
    ],
    instructions: [
      "1. Prepare ensaymada dough.",
      "2. Shape into coils.",
      "3. Bake until golden.",
      "4. Brush generously with butter.",
      "5. Sprinkle with sugar.",
      "6. Cover with grated cheese."
    ]
  },
  {
    name: "Pandesal with Ube",
    description: "Pandesal rolls filled with ube halaya.",
    servings: 12,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Harina (all-purpose flour)", grams: 480 },
      { name: "Asukal (sugar)", grams: 100 },
      { name: "Yeast (lebadura)", grams: 10 },
      { name: "Fresh milk (gatas)", grams: 360 },
      { name: "Mantikilya (butter)", grams: 60 },
      { name: "Ube halaya", grams: 200 },
      { name: "Panko breadcrumbs", grams: 100 },
    ],
    instructions: [
      "1. Divide dough into portions.",
      "2. Flatten each piece.",
      "3. Place ube in the center.",
      "4. Seal completely.",
      "5. Roll in breadcrumbs.",
      "6. Let rise.",
      "7. Bake at 180°C for 15–20 minutes."
    ]
  },
  {
    name: "Pandesal with Dulce de Leche",
    description: "Pandesal rolls filled with dulce de leche.",
    servings: 12,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Harina (all-purpose flour)", grams: 480 },
      { name: "Asukal (sugar)", grams: 100 },
      { name: "Yeast (lebadura)", grams: 10 },
      { name: "Fresh milk (gatas)", grams: 360 },
      { name: "Mantikilya (butter)", grams: 60 },
      { name: "Dulce de leche", grams: 200 },
      { name: "Panko breadcrumbs", grams: 100 },
    ],
    instructions: [
      "1. Flatten dough.",
      "2. Add dulce de leche.",
      "3. Seal tightly.",
      "4. Coat with breadcrumbs.",
      "5. Let rise.",
      "6. Bake at 180°C until golden."
    ]
  },
  {
    name: "Pandesal French Toast",
    description: "Pandesal dipped in egg and milk, pan-fried in butter.",
    servings: 3,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Harina (all-purpose flour)", grams: 240 },
      { name: "Itlog (egg)", grams: 100 },
      { name: "Fresh milk (gatas)", grams: 120 },
      { name: "Asukal (sugar)", grams: 30 },
      { name: "Mantikilya (butter)", grams: 30 },
    ],
    instructions: [
      "1. Whisk eggs, milk, and sugar.",
      "2. Slice pandesal in half.",
      "3. Dip into egg mixture.",
      "4. Cook in buttered pan.",
      "5. Brown both sides.",
      "6. Serve with syrup, fruit, or condensed milk."
    ]
  },
  {
    name: "Pandesal Bread Pudding",
    description: "Baked pandesal bread pudding with raisins.",
    servings: 6,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Harina (all-purpose flour)", grams: 240 },
      { name: "Fresh milk (gatas)", grams: 480 },
      { name: "Itlog (egg)", grams: 100 },
      { name: "Asukal (sugar)", grams: 100 },
      { name: "Vanilla extract", grams: 5 },
      { name: "Pasas (raisins)", grams: 60 },
    ],
    instructions: [
      "1. Tear pandesal into pieces.",
      "2. Mix milk, eggs, sugar, and vanilla.",
      "3. Pour over bread.",
      "4. Let soak for 10 minutes.",
      "5. Transfer to baking dish.",
      "6. Bake at 180°C for 35–45 minutes.",
      "7. Cool before serving."
    ]
  },
  {
    name: "Otap",
    description: "Crispy oval Filipino cookies topped with sugar.",
    servings: 10,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Harina (all-purpose flour)", grams: 240 },
      { name: "Mantikilya (butter)", grams: 120 },
      { name: "Asukal (sugar)", grams: 100 },
      { name: "Asin (salt)", grams: 2 },
    ],
    instructions: [
      "1. Make a soft dough from flour, water, and salt.",
      "2. Roll thinly.",
      "3. Brush with butter.",
      "4. Fold and roll repeatedly for layers.",
      "5. Cut into oval pieces.",
      "6. Sprinkle with sugar.",
      "7. Bake until crisp and golden."
    ]
  },
  {
    name: "Pilipit",
    description: "Twisted fried dough coated in sugar syrup.",
    servings: 6,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Harina (all-purpose flour)", grams: 240 },
      { name: "Asukal (sugar)", grams: 100 },
      { name: "Itlog (egg)", grams: 50 },
      { name: "Mantika (cooking oil)", grams: 250 },
    ],
    instructions: [
      "1. Mix flour, sugar, egg, and water.",
      "2. Knead into soft dough.",
      "3. Form thin ropes.",
      "4. Twist each piece.",
      "5. Fry until golden.",
      "6. Coat with sugar syrup."
    ]
  },
  {
    name: "Shakoy",
    description: "Twisted fried dough coated in sugar.",
    servings: 8,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Harina (all-purpose flour)", grams: 240 },
      { name: "Yeast (lebadura)", grams: 10 },
      { name: "Asukal (sugar)", grams: 100 },
      { name: "Mantika (cooking oil)", grams: 250 },
    ],
    instructions: [
      "1. Mix flour, yeast, sugar, and water.",
      "2. Knead until smooth.",
      "3. Let rise for about 1 hour.",
      "4. Shape into twisted strips.",
      "5. Fry until golden.",
      "6. Roll in sugar."
    ]
  },
  {
    name: "Empanada",
    description: "Fried or baked stuffed dough turnovers.",
    servings: 8,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Harina (all-purpose flour)", grams: 240 },
      { name: "Mantikilya (butter)", grams: 120 },
      { name: "Asin (salt)", grams: 3 },
      { name: "Giniling na baboy (ground pork)", grams: 250 },
      { name: "Patatas (potato)", grams: 100 },
      { name: "Karot (carrot)", grams: 80 },
      { name: "Sibuyas (onion)", grams: 40 },
      { name: "Toyo (soy sauce)", grams: 30 },
      { name: "Itlog (egg)", grams: 100 },
    ],
    instructions: [
      "1. Make dough by combining flour, butter, salt, and water.",
      "2. Chill for 20 minutes.",
      "3. Cook the meat and vegetables.",
      "4. Add soy sauce and chopped egg.",
      "5. Roll dough into circles.",
      "6. Fill and fold.",
      "7. Seal edges.",
      "8. Fry until golden or bake at 180°C until browned."
    ]
  },
  {
    name: "Siopao",
    description: "Steamed Filipino buns with savory pork or chicken filling.",
    servings: 10,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Harina (all-purpose flour)", grams: 360 },
      { name: "Yeast (lebadura)", grams: 10 },
      { name: "Asukal (sugar)", grams: 100 },
      { name: "Baboy (pork, kasim/shoulder)", grams: 250 },
    ],
    instructions: [
      "1. Make a soft yeast dough.",
      "2. Let rise until doubled.",
      "3. Divide into pieces.",
      "4. Flatten each piece.",
      "5. Add filling.",
      "6. Gather edges and seal.",
      "7. Steam for 15–20 minutes.",
      "8. Serve hot."
    ]
  },
  {
    name: "Filipino Cheese Bread",
    description: "Soft bread rolls filled with cheese.",
    servings: 10,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Harina (all-purpose flour)", grams: 240 },
      { name: "Asukal (sugar)", grams: 30 },
      { name: "Yeast (lebadura)", grams: 5 },
      { name: "Fresh milk (gatas)", grams: 120 },
      { name: "Itlog (egg)", grams: 50 },
      { name: "Mantikilya (butter)", grams: 30 },
      { name: "Keso (cheese)", grams: 150 },
      { name: "Panko breadcrumbs", grams: 60 },
    ],
    instructions: [
      "1. Combine flour, sugar, and yeast.",
      "2. Add milk, egg, and butter.",
      "3. Knead until smooth.",
      "4. Let rise for 1 hour.",
      "5. Fill with cheese.",
      "6. Shape into rolls.",
      "7. Coat lightly with breadcrumbs.",
      "8. Bake at 180°C for 15–20 minutes."
    ]
  },
  {
    name: "Filipino Banana Pancakes",
    description: "Fluffy pancakes made with ripe bananas.",
    servings: 3,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Saging na hinog (ripe banana)", grams: 200 },
      { name: "Harina (all-purpose flour)", grams: 120 },
      { name: "Itlog (egg)", grams: 50 },
      { name: "Fresh milk (gatas)", grams: 180 },
      { name: "Asukal (sugar)", grams: 30 },
      { name: "Baking powder", grams: 5 },
    ],
    instructions: [
      "1. Mash bananas.",
      "2. Add egg and milk.",
      "3. Mix in flour, sugar, and baking powder.",
      "4. Heat a lightly greased pan.",
      "5. Pour batter into small circles.",
      "6. Cook both sides until golden.",
      "7. Serve with condensed milk or caramelized bananas."
    ]
  },
  {
    name: "Champorado",
    description: "Sweet chocolate rice porridge with evaporated milk.",
    servings: 4,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Malagkit (glutinous rice)", grams: 200 },
      { name: "Cacao tablea", grams: 60 },
      { name: "Asukal (sugar)", grams: 100 },
      { name: "Evaporated milk (evaporada)", grams: 120 },
    ],
    instructions: [
      "1. Cook rice in water until soft.",
      "2. Add tablea.",
      "3. Stir until chocolate melts.",
      "4. Add sugar.",
      "5. Cook until thick and creamy.",
      "6. Serve with evaporated milk."
    ]
  },
  {
    name: "Halo-Halo",
    description: "Shaved ice dessert with mixed sweets, ube, and leche flan.",
    servings: 4,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Ice (crushed)", grams: 400 },
      { name: "Evaporated milk (evaporada)", grams: 240 },
      { name: "Saging na saba (plantain)", grams: 150 },
      { name: "Langka (jackfruit)", grams: 100 },
      { name: "Nata de coco", grams: 100 },
      { name: "Kaong", grams: 100 },
      { name: "Ube halaya", grams: 100 },
      { name: "No-Steam Easy Flan", grams: 100 },
      { name: "Ice cream (sorbetes)", grams: 100 },
    ],
    instructions: [
      "1. Place assorted ingredients into a tall glass.",
      "2. Fill with crushed ice.",
      "3. Pour evaporated milk over the ice.",
      "4. Add ube and leche flan.",
      "5. Add ice cream if desired.",
      "6. Serve immediately and mix before eating."
    ]
  },
  {
    name: "Avocado con Yelo",
    description: "Chilled avocado dessert with milk and crushed ice.",
    servings: 2,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Avocado", grams: 400 },
      { name: "Ice (crushed)", grams: 400 },
      { name: "Evaporated milk (evaporada)", grams: 240 },
      { name: "Asukal (sugar)", grams: 80 },
      { name: "Condensed milk (condensada)", grams: 60 },
    ],
    instructions: [
      "1. Scoop avocado into a glass.",
      "2. Add sugar.",
      "3. Add crushed ice.",
      "4. Pour evaporated milk over the top.",
      "5. Add condensed milk if desired.",
      "6. Mix before serving."
    ]
  },
  {
    name: "Puto Calasiao",
    description: "Small soft fermented rice cakes from Calasiao.",
    servings: 10,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Rice flour", grams: 240 },
      { name: "Asukal (sugar)", grams: 200 },
      { name: "Yeast (lebadura)", grams: 5 },
    ],
    instructions: [
      "1. Mix rice flour, sugar, yeast, and water.",
      "2. Cover and allow to ferment overnight.",
      "3. Stir gently.",
      "4. Pour into small molds.",
      "5. Steam until soft and cooked.",
      "6. Cool slightly before serving."
    ]
  },
  {
    name: "Puto Lanson",
    description: "Steamed cassava and coconut cakes.",
    servings: 8,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Kamoteng kahoy (cassava)", grams: 400 },
      { name: "Asukal (sugar)", grams: 100 },
      { name: "Niyog (grated coconut)", grams: 100 },
      { name: "Asin (salt)", grams: 2 },
    ],
    instructions: [
      "1. Mix cassava, sugar, coconut, and salt.",
      "2. Form small cakes.",
      "3. Wrap or place in banana leaves.",
      "4. Steam until cooked.",
      "5. Serve warm with grated coconut."
    ]
  },
  {
    name: "Peanut-Cheese Balls",
    description: "Fried peanut and cheese balls with breadcrumb coating.",
    servings: 6,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Mani (peanuts)", grams: 150 },
      { name: "Keso (cheese)", grams: 120 },
      { name: "Harina (all-purpose flour)", grams: 60 },
      { name: "Itlog (egg)", grams: 50 },
      { name: "Panko breadcrumbs", grams: 120 },
      { name: "Mantika (cooking oil)", grams: 300 },
    ],
    instructions: [
      "1. Mix peanuts, cheese, flour, and egg.",
      "2. Form into small balls.",
      "3. Coat with breadcrumbs.",
      "4. Fry until golden.",
      "5. Drain and serve with a sweet chili dip."
    ]
  },
  {
    name: "Sweet Potato Cheese Balls",
    description: "Fried mashed sweet potato and cheese balls.",
    servings: 6,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Kamote (sweet potato)", grams: 400 },
      { name: "Keso (cheese)", grams: 120 },
      { name: "Itlog (egg)", grams: 50 },
      { name: "Panko breadcrumbs", grams: 120 },
      { name: "Mantika (cooking oil)", grams: 300 },
    ],
    instructions: [
      "1. Mix mashed sweet potato with cheese.",
      "2. Form into balls.",
      "3. Dip in egg.",
      "4. Coat with breadcrumbs.",
      "5. Fry until golden and crispy.",
      "6. Serve warm."
    ]
  },
  {
    name: "Filipino-Style Corn Fritters",
    description: "Fried corn fritters served with ketchup or chili sauce.",
    servings: 6,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Mais (corn)", grams: 300 },
      { name: "Harina (all-purpose flour)", grams: 120 },
      { name: "Itlog (egg)", grams: 50 },
      { name: "Asukal (sugar)", grams: 15 },
      { name: "Asin (salt)", grams: 3 },
      { name: "Paminta (black pepper)", grams: 2 },
      { name: "Mantika (cooking oil)", grams: 250 },
    ],
    instructions: [
      "1. Mix corn, flour, egg, and water.",
      "2. Add sugar, salt, and pepper.",
      "3. Heat oil.",
      "4. Scoop batter into the pan.",
      "5. Flatten slightly.",
      "6. Fry both sides until golden.",
      "7. Drain and serve with ketchup or chili sauce."
    ]
  },
  // FROM PANLASANG PINOY SITE
  {
    name: "Tortang Noodles at Sardinas",
    description: "Noodle and sardine omelet topped with a savory sardine sauce.",
    servings: 2,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Instant noodles", grams: 85 },
      { name: "Sardinas (canned sardines)", grams: 140 },
      { name: "Itlog (egg)", grams: 100 },
      { name: "Harina (all-purpose flour)", grams: 15 },
      { name: "Sibuyas (onion)", grams: 30 },
      { name: "Spring onions (dahon ng sibuyas)", grams: 25 },
      { name: "Mantika (cooking oil)", grams: 55 },
      { name: "Asin (salt)", grams: 2 },
      { name: "Paminta (black pepper)", grams: 1 },
    ],
    instructions: [
      "1. Boil water, cook the instant noodles until soft, then drain.",
      "2. Separate sardine fish from the sauce; mash the fish. Add eggs, salt and pepper; mix.",
      "3. Add cooked noodles, then flour and green onion; mix well.",
      "4. Heat oil; scoop about 1/2 cup mixture per omelet, cook 1 1/2 minutes per side. Repeat.",
      "5. Sauce: heat oil, sauté onion, pour in sardine sauce, cook 30 seconds, add remaining green onion.",
      "6. Top omelets with the sauce and serve."
    ]
  },
  {
    name: "Sardines Fish Ball with Sweet and Sour Sauce",
    description: "Fried sardine balls served with a sweet and sour dipping sauce.",
    servings: 4,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Sardinas (canned sardines)", grams: 300 },
      { name: "Pechay (bok choy)", grams: 60 },
      { name: "Knorr Liquid Seasoning", grams: 10 },
      { name: "Spring onions (dahon ng sibuyas)", grams: 15 },
      { name: "Bread crumbs", grams: 90 },
      { name: "Asukal (sugar)", grams: 12 },
      { name: "Suka (vinegar)", grams: 25 },
      { name: "Itlog (egg)", grams: 100 },
      { name: "Gawgaw (cornstarch)", grams: 7 },
      { name: "Mantika (cooking oil)", grams: 400 },
    ],
    instructions: [
      "1. Open the sardines and separate the fish from the sauce with a sieve.",
      "2. Sweet and sour sauce: heat sardine sauce, add vinegar and boil, stir in sugar, thicken with cornstarch mixed with water. Set aside.",
      "3. Mash sardines; add pechay and 1 egg; mix.",
      "4. Add liquid seasoning and about 3 tbsp breadcrumbs; mix.",
      "5. Beat remaining egg. Scoop 2 tbsp mixture, form a ball, dip in egg, roll in breadcrumbs.",
      "6. Deep-fry over low to medium heat until golden brown. Serve with sauce."
    ]
  },
  {
    name: "Ukoy Dulong",
    description: "Crispy silverfish and bean sprout fritters.",
    servings: 4,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Dulong (silverfish)", grams: 120 },
      { name: "Togue (bean sprouts)", grams: 200 },
      { name: "Mantika (cooking oil)", grams: 350 },
      { name: "Gawgaw (cornstarch)", grams: 60 },
      { name: "Harina (all-purpose flour)", grams: 60 },
      { name: "Baking powder", grams: 2 },
      { name: "Asin (salt)", grams: 3 },
      { name: "Paminta (black pepper)", grams: 2 },
      { name: "Garlic powder", grams: 1 },
      { name: "Onion powder", grams: 1 },
      { name: "Itlog (egg)", grams: 50 },
    ],
    instructions: [
      "1. Combine the batter ingredients, dry first, then egg and water. Mix well.",
      "2. Add the dulong and bean sprouts; stir gently.",
      "3. Heat oil. Put about 1/2 cup of mixture on a saucer, slide into hot oil.",
      "4. Cook until golden brown and crisp on one side, then flip.",
      "5. Drain on paper towels. Serve with spicy vinegar."
    ]
  },
  {
    name: "Fried Tilapia",
    description: "Simple crispy fried tilapia.",
    servings: 3,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Tilapia", grams: 700 },
      { name: "Asin (salt)", grams: 8 },
      { name: "Mantika (cooking oil)", grams: 200 },
    ],
    instructions: [
      "1. Rub salt all over the fish, including the insides.",
      "2. Heat oil in a wide frying pan.",
      "3. Fry the tilapia, covered with the lid slightly open, on medium heat about 6 to 10 minutes per side until crisp.",
      "4. Serve with your favorite condiments and side dish."
    ]
  },
  {
    name: "Tanigue Fish Steak ala Bistek",
    description: "Tanigue steaks simmered in soy sauce and lemon with onion rings.",
    servings: 6,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Tanigue (Spanish mackerel)", grams: 1400 },
      { name: "Sibuyas (onion)", grams: 300 },
      { name: "Lemon", grams: 60 },
      { name: "Toyo (soy sauce)", grams: 90 },
      { name: "Bawang (garlic)", grams: 20 },
      { name: "Asin (salt)", grams: 30 },
      { name: "Asukal (sugar)", grams: 5 },
      { name: "Paminta (black pepper)", grams: 1 },
      { name: "Mantika (cooking oil)", grams: 200 },
    ],
    instructions: [
      "1. Rub salt all over the fish steaks; rest 20 minutes.",
      "2. Heat 1/2 cup oil and fry the fish 3 to 5 minutes per side until golden brown. Set aside.",
      "3. In a pot, heat 3 to 4 tbsp oil and sauté garlic until light brown.",
      "4. Add 1/3 of the onions and sauté until soft.",
      "5. Pour in soy sauce, lemon juice, and water; bring to a boil. Add sugar and pepper.",
      "6. Add the fried fish, cover, cook 3 minutes on medium heat.",
      "7. Turn the fish, add remaining onions, cover, and cook 3 to 5 minutes more. Serve with rice."
    ]
  },
  {
    name: "Ginisang Upo with Sardinas",
    description: "Bottle gourd sautéed with canned sardines in tomato sauce.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Upo (bottle gourd)", grams: 600 },
      { name: "Sardinas (canned sardines)", grams: 310 },
      { name: "Sibuyas (onion)", grams: 60 },
      { name: "Kamatis (tomato)", grams: 150 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Patis (fish sauce)", grams: 30 },
      { name: "Paminta (black pepper)", grams: 1 },
      { name: "Mantika (cooking oil)", grams: 40 },
    ],
    instructions: [
      "1. Heat oil; sauté onion and garlic.",
      "2. Add tomato and cook until soft.",
      "3. Add the sliced upo and sauté 3 minutes.",
      "4. Pour in the sardines and stir. Add water, boil, and cook 3 to 5 minutes.",
      "5. Season with fish sauce and pepper. Serve."
    ]
  },
  {
    name: "Fish Lumpia",
    description: "Crispy spring rolls filled with flaked milkfish and vegetables.",
    servings: 5,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Bangus (milkfish)", grams: 600 },
      { name: "Lumpia wrappers", grams: 160 },
      { name: "Celery", grams: 40 },
      { name: "Sibuyas (onion)", grams: 60 },
      { name: "Karot (carrot)", grams: 80 },
      { name: "Flat leaf parsley", grams: 20 },
      { name: "Singkamas (jicama)", grams: 120 },
      { name: "Asin (salt)", grams: 8 },
      { name: "Paminta (black pepper)", grams: 1 },
      { name: "Itlog (egg)", grams: 50 },
      { name: "Mantika (cooking oil)", grams: 400 },
    ],
    instructions: [
      "1. Preheat oven to 188°C. Bake the bangus 15 minutes until flaky. Cool, then flake the meat.",
      "2. Heat 3 tbsp oil; sauté onion and celery, add carrot and sauté 30 seconds.",
      "3. Add parsley and fish flakes; cook 1 minute. Add salt and pepper, cook 30 seconds, transfer to a bowl.",
      "4. Add the jicama and egg; season and mix well.",
      "5. Cut wrappers into triangles. Place 1 to 2 tbsp filling near the base, shape, fold in sides, and roll up. Seal tip with egg white or water.",
      "6. Fry in hot oil 2 to 3 minutes per side until golden brown. Drain and serve with dipping sauce."
    ]
  },
  {
    name: "Fried Galunggong with Salted Egg and Tomato Salad",
    description: "Crispy fried round scad with a salted egg and tomato salad.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Galunggong (round scad)", grams: 800 },
      { name: "Asin (salt)", grams: 25 },
      { name: "Mantika (cooking oil)", grams: 120 },
      { name: "Maalat na itlog (salted egg)", grams: 70 },
      { name: "Kamatis (tomato)", grams: 150 },
      { name: "Spring onions (dahon ng sibuyas)", grams: 10 },
      { name: "Patis (fish sauce)", grams: 5 },
    ],
    instructions: [
      "1. Rub salt over the fish, including the cavity; rest 15 minutes.",
      "2. Combine the salad ingredients with fish sauce and toss gently.",
      "3. Heat oil in a pan. Fry the fish until one side is brown and crispy, then flip and do the same on the other side.",
      "4. Drain and serve with the salad and spicy vinegar."
    ]
  },
  {
    name: "Ginisang Tuna",
    description: "Canned albacore tuna sautéed with onions and parsley.",
    servings: 2,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Tuna (albacore, canned)", grams: 340 },
      { name: "Flat leaf parsley", grams: 5 },
      { name: "Sibuyas (onion)", grams: 60 },
      { name: "Lime", grams: 50 },
      { name: "Chicken broth", grams: 120 },
      { name: "Asin (salt)", grams: 2 },
      { name: "Paminta (black pepper)", grams: 1 },
      { name: "Mantika (cooking oil)", grams: 20 },
    ],
    instructions: [
      "1. Open the tuna and discard the water.",
      "2. Heat oil in a pan and sauté the onion for 1 minute.",
      "3. Add the tuna and sauté 2 to 3 minutes.",
      "4. Pour in the chicken broth, cover, and cook on medium heat 3 to 5 minutes until it almost evaporates.",
      "5. Add parsley, salt and pepper; squeeze lime over the tuna and stir. Serve."
    ]
  },
  {
    name: "Crispy Tilapia Sticks",
    description: "Panko-crusted tilapia strips fried until crispy.",
    servings: 4,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Tilapia", grams: 450 },
      { name: "Garlic powder", grams: 2 },
      { name: "Onion powder", grams: 2 },
      { name: "Asin (salt)", grams: 5 },
      { name: "Paminta (black pepper)", grams: 1 },
      { name: "Itlog (egg)", grams: 100 },
      { name: "Panko breadcrumbs", grams: 100 },
      { name: "Mantika (cooking oil)", grams: 400 },
    ],
    instructions: [
      "1. Mix salt, garlic powder, onion powder, and pepper; rub all over the tilapia strips.",
      "2. Heat the oil in a deep pot.",
      "3. Dip each strip in beaten egg, then coat well in Panko.",
      "4. Deep fry on medium heat until golden brown.",
      "5. Drain on paper towels. Serve with ranch dressing or tartar sauce."
    ]
  },
  {
    name: "Tuyo Pasta",
    description: "Spaghetti tossed with bottled tuyo and Parmesan.",
    servings: 6,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Spaghetti noodles", grams: 450 },
      { name: "Tuyo (dried fish)", grams: 230 },
      { name: "Parmesan cheese", grams: 30 },
      { name: "Paminta (black pepper)", grams: 1 },
      { name: "Garlic powder", grams: 2 },
      { name: "Dried basil", grams: 2 },
      { name: "Olive oil (extra virgin)", grams: 40 },
    ],
    instructions: [
      "1. Cook the spaghetti per package instructions.",
      "2. Drain the oil from the bottled tuyo; chop or shred the fish finely.",
      "3. In a large bowl, toss the spaghetti, tuyo, and Parmesan.",
      "4. Add garlic powder, dried basil, and pepper; toss until well blended. Serve."
    ]
  },
  {
    name: "Fried Bangus Sinigang sa Miso",
    description: "Crispy fried milkfish in a miso-tamarind soup with spinach.",
    servings: 3,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Bangus (milkfish)", grams: 800 },
      { name: "Spinach", grams: 200 },
      { name: "Kamatis (tomato)", grams: 300 },
      { name: "Miso paste", grams: 45 },
      { name: "Sinigang mix (sampalok)", grams: 40 },
      { name: "Sibuyas (onion)", grams: 200 },
      { name: "Bawang (garlic)", grams: 5 },
      { name: "Paminta (black pepper)", grams: 1 },
      { name: "Patis (fish sauce)", grams: 30 },
      { name: "Asin (salt)", grams: 25 },
      { name: "Mantika (cooking oil)", grams: 180 },
    ],
    instructions: [
      "1. Wash the fish, pat dry, and slice diagonally crosswise about 1 1/4 inch thick.",
      "2. Rub sea salt all over the slices; rest 15 minutes.",
      "3. Heat oil and pan-fry the fish 3 to 4 minutes per side (cover the pan, it splatters).",
      "4. Scoop about 2 tbsp frying oil into a clean pot. Sauté garlic, onion, and tomatoes until soft.",
      "5. Add pepper and miso paste; stir. Pour in water and bring to a boil.",
      "6. Add the sinigang mix and the fried fish; simmer 15 to 18 minutes.",
      "7. Add fish sauce, stir, then add the spinach. Cover, turn off heat, leave covered at least 8 minutes. Serve."
    ]
  },
  {
    name: "Grilled Tilapia",
    description: "Foil-wrapped grilled tilapia stuffed with tomato and onion.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Tilapia", grams: 800 },
      { name: "Kamatis (tomato)", grams: 300 },
      { name: "Sibuyas (onion)", grams: 120 },
      { name: "Lemon", grams: 30 },
      { name: "Asin (salt)", grams: 8 },
      { name: "Paminta (black pepper)", grams: 2 },
      { name: "Mantika (cooking oil)", grams: 30 },
    ],
    instructions: [
      "1. Mix tomato, onion, salt, pepper, and lemon juice.",
      "2. Stuff the mixture into the fish cavity (don't overstuff).",
      "3. Mix the oil with 1 tsp salt and brush over the outside of the fish.",
      "4. Wrap the fish in foil and seal the sides.",
      "5. Grill about 12 minutes per side.",
      "6. Serve with ensaladang talong and steamed rice."
    ]
  },
  {
    name: "Sardines with Misua",
    description: "Misua noodles simmered with canned sardines and toasted garlic.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Sardinas (canned sardines)", grams: 140 },
      { name: "Misua (wheat noodles)", grams: 60 },
      { name: "Patis (fish sauce)", grams: 30 },
      { name: "Paminta (black pepper)", grams: 1 },
      { name: "Bawang (garlic)", grams: 10 },
      { name: "Sibuyas (onion)", grams: 40 },
      { name: "Spring onions (dahon ng sibuyas)", grams: 5 },
      { name: "Mantika (cooking oil)", grams: 30 },
    ],
    instructions: [
      "1. Heat oil in a pot; sauté garlic and onion.",
      "2. Add the sardines with sauce; cook 2 minutes.",
      "3. Add fish sauce and pepper; stir.",
      "4. Add water and bring to a boil.",
      "5. Add the misua and cook 3 to 5 minutes on medium heat.",
      "6. Turn off heat, transfer to a bowl, garnish with toasted garlic and scallions. Serve hot."
    ]
  },
  {
    name: "Sinigang na Salmon Belly",
    description: "Salmon belly in a miso-tamarind broth with vegetables.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Salmon belly", grams: 230 },
      { name: "Sitaw (yardlong beans)", grams: 100 },
      { name: "Okra", grams: 80 },
      { name: "Kamatis (tomato)", grams: 300 },
      { name: "Labanos (radish)", grams: 120 },
      { name: "Mustard leaves", grams: 150 },
      { name: "Sibuyas (onion)", grams: 60 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Luya (ginger)", grams: 30 },
      { name: "Sinigang mix (sampalok)", grams: 45 },
      { name: "Miso paste", grams: 45 },
      { name: "Mantika (cooking oil)", grams: 40 },
      { name: "Patis (fish sauce)", grams: 15 },
      { name: "Paminta (black pepper)", grams: 1 },
    ],
    instructions: [
      "1. Heat oil; sauté garlic until it starts to brown.",
      "2. Add ginger, onion, and half of the tomatoes; sauté until soft.",
      "3. Stir in the miso paste.",
      "4. Add the salmon belly and cook 1 minute.",
      "5. Pour in water and bring to a boil.",
      "6. Add the daikon and sinigang mix; cook 3 minutes.",
      "7. Add okra, string beans, and remaining tomatoes; cook 5 minutes.",
      "8. Season with pepper and fish sauce.",
      "9. Add mustard leaves, turn off heat, cover for 3 minutes. Serve with rice."
    ]
  },
  {
    name: "Laswa",
    description: "Ilonggo vegetable soup with shrimp and native vegetables.",
    servings: 6,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Hipon (shrimp)", grams: 200 },
      { name: "Talong (eggplant)", grams: 300 },
      { name: "Kalabasa (squash)", grams: 200 },
      { name: "Sitaw (yardlong beans)", grams: 150 },
      { name: "Saluyot leaves", grams: 80 },
      { name: "Alugbati", grams: 100 },
      { name: "Amaranth leaves (kulitis)", grams: 80 },
      { name: "Okra", grams: 80 },
      { name: "Kamatis (tomato)", grams: 200 },
      { name: "Sibuyas (onion)", grams: 60 },
      { name: "Bagoong alamang (shrimp paste)", grams: 10 },
      { name: "Asin (salt)", grams: 3 },
      { name: "Paminta (black pepper)", grams: 1 },
    ],
    instructions: [
      "1. Boil water in a pot.",
      "2. Add onion and tomato; cover and boil 5 minutes on medium heat.",
      "3. Add kalabasa and bagoong; boil 5 minutes.",
      "4. Add eggplant, string beans, and okra; cook 4 to 5 minutes.",
      "5. Add the shrimp, cover, and cook 1 minute.",
      "6. Add saluyot, amaranth, and alugbati; stir.",
      "7. Season with salt and pepper. Serve with fried fish on the side."
    ]
  },
  {
    name: "Embutido",
    description: "Filipino-style meatloaf with pork, eggs, sausages, and raisins.",
    servings: 6,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Giniling na baboy (ground pork)", grams: 900 },
      { name: "Vienna sausage", grams: 400 },
      { name: "Itlog (egg)", grams: 250 },
      { name: "Sweet pickle relish", grams: 120 },
      { name: "Tomato sauce", grams: 120 },
      { name: "Keso (cheese)", grams: 200 },
      { name: "Red bell pepper", grams: 150 },
      { name: "Atsal (bell pepper)", grams: 150 },
      { name: "Pasas (raisins)", grams: 220 },
      { name: "Karot (carrot)", grams: 150 },
      { name: "Sibuyas (onion)", grams: 150 },
      { name: "Asin (salt)", grams: 5 },
      { name: "Paminta (black pepper)", grams: 3 },
      { name: "Bread crumbs", grams: 150 },
    ],
    instructions: [
      "1. Place ground pork in a large container.",
      "2. Add bread crumbs and 2 raw eggs; mix well.",
      "3. Add carrots, bell peppers, onion, pickle relish, and cheddar; mix thoroughly.",
      "4. Add raisins, tomato sauce, salt, and pepper; mix well.",
      "5. Flatten meat mixture on a sheet of aluminum foil.",
      "6. Arrange sliced sausage and boiled egg alternately down the middle.",
      "7. Roll foil into a cylinder, enclosing sausage and egg, seal edges tightly.",
      "8. Steam for 1 hour.",
      "9. Chill in the refrigerator until cold, then slice and serve with banana ketchup."
    ]
  },
  {
    name: "Tortang Talong",
    description: "Classic Filipino eggplant omelet.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Talong (eggplant)", grams: 500 },
      { name: "Itlog (egg)", grams: 200 },
      { name: "Asin (salt)", grams: 3 },
      { name: "Mantika (cooking oil)", grams: 70 },
    ],
    instructions: [
      "1. Grill the eggplants directly over a gas flame until charred and soft.",
      "2. Cool, then peel off charred skin, keeping stems attached.",
      "3. Flatten each eggplant with a fork into a wide oval.",
      "4. Beat the eggs with salt in a wide bowl.",
      "5. Dip each flattened eggplant in the egg, coating both sides.",
      "6. Heat about 1 tbsp oil in a pan. Add a coated eggplant and spoon extra egg over bare spots.",
      "7. Fry 3 to 4 minutes until the bottom is golden and set; flip and cook 2 to 3 minutes more.",
      "8. Repeat with the rest. Serve with rice and banana ketchup."
    ]
  },
  {
    name: "Pork Steak",
    description: "Filipino pork chop bistek with soy sauce and calamansi.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Pork chops", grams: 600 },
      { name: "Toyo (soy sauce)", grams: 75 },
      { name: "Calamansi", grams: 60 },
      { name: "Sibuyas (onion)", grams: 200 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Asukal (sugar)", grams: 3 },
      { name: "Mantika (cooking oil)", grams: 120 },
      { name: "Asin (salt)", grams: 3 },
      { name: "Paminta (black pepper)", grams: 1 },
    ],
    instructions: [
      "1. Combine pork chops, soy sauce, and lime juice; marinate at least 1 hour.",
      "2. Heat oil. Pan-fry marinated pork chops on medium heat 3 minutes per side; set aside.",
      "3. In remaining oil, sauté garlic until it starts to brown.",
      "4. Add half of the onions and sauté until soft.",
      "5. Pour in leftover marinade and water. Return pork chops and simmer about 45 minutes until tender.",
      "6. Add sugar, salt, and pepper; stir.",
      "7. Add remaining onions and cook 3 minutes more. Serve."
    ]
  },
  {
    name: "Garlic Butter Shrimp",
    description: "Shrimp stir-fried in garlic butter with lemon-lime soda marinade.",
    servings: 6,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Hipon (shrimp)", grams: 900 },
      { name: "Flat leaf parsley", grams: 8 },
      { name: "Mantikilya (butter)", grams: 60 },
      { name: "Bawang (garlic)", grams: 40 },
      { name: "Lemon-lime soda", grams: 240 },
      { name: "Lemon", grams: 5 },
      { name: "Asin (salt)", grams: 3 },
      { name: "Paminta (black pepper)", grams: 1 },
    ],
    instructions: [
      "1. Marinate the shrimp in the lemon-lime soda for about 10 minutes.",
      "2. Melt the butter in a pan.",
      "3. Add the garlic and cook on low heat until light brown.",
      "4. Add the shrimp, turn heat to high, and stir-fry until shrimp turn orange.",
      "5. Season with pepper, salt, and lemon juice; stir.",
      "6. Add the parsley and cook 30 seconds. Serve hot."
    ]
  },
  {
    name: "Sinigang na Hipon",
    description: "Shrimp in a sour tamarind broth with vegetables.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Hipon (shrimp)", grams: 450 },
      { name: "Sinigang mix (sampalok)", grams: 44 },
      { name: "Kangkong (water spinach)", grams: 150 },
      { name: "Sitaw (yardlong beans)", grams: 100 },
      { name: "Okra", grams: 60 },
      { name: "Talong (eggplant)", grams: 150 },
      { name: "Labanos (radish)", grams: 100 },
      { name: "Kamatis (tomato)", grams: 100 },
      { name: "Sili na mura (green finger chili)", grams: 45 },
      { name: "Sibuyas (onion)", grams: 60 },
      { name: "Patis (fish sauce)", grams: 15 },
      { name: "Paminta (black pepper)", grams: 1 },
    ],
    instructions: [
      "1. Boil the water. Add onion, tomato, and radish; cover and boil 8 minutes.",
      "2. Add the shrimp; cook 1 minute.",
      "3. Add the sinigang mix, stir until dissolved, cover, and cook 3 minutes.",
      "4. Add the green peppers, snake beans, okra, and eggplant; stir and cook 5 minutes.",
      "5. Add the kangkong stalks; season with fish sauce and pepper.",
      "6. Add the kangkong leaves and cook 1 minute. Serve warm with rice."
    ]
  },
  {
    name: "Adobong Pusit",
    description: "Squid adobo simmered in soy sauce, vinegar, and squid ink.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Pusit (squid)", grams: 900 },
      { name: "Sibuyas (onion)", grams: 100 },
      { name: "Kamatis (tomato)", grams: 150 },
      { name: "Toyo (soy sauce)", grams: 120 },
      { name: "Suka (vinegar)", grams: 120 },
      { name: "Bawang (garlic)", grams: 20 },
      { name: "Asukal (sugar)", grams: 5 },
      { name: "Asin (salt)", grams: 3 },
      { name: "Paminta (black pepper)", grams: 1 },
      { name: "Mantika (cooking oil)", grams: 30 },
    ],
    instructions: [
      "1. In a wok, combine soy sauce, vinegar, and water; bring to a boil.",
      "2. Add the squid, wait for it to re-boil, and simmer 5 minutes.",
      "3. Turn off heat and separate squid from liquid; set both aside.",
      "4. In another pot, heat oil and sauté garlic, onions, and tomatoes.",
      "5. Add the squid and cook a few seconds.",
      "6. Pour in the reserved soy-vinegar liquid, bring to a boil, and simmer 3 minutes.",
      "7. Add the ink, salt, pepper, and sugar; simmer 3 more minutes. Serve."
    ]
  },
  {
    name: "Beef Kare-Kare",
    description: "Beef stewed in a thick peanut sauce with annatto and vegetables.",
    servings: 5,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Beef chuck", grams: 900 },
      { name: "Sitaw (yardlong beans)", grams: 200 },
      { name: "Pechay (bok choy)", grams: 300 },
      { name: "Talong (eggplant)", grams: 200 },
      { name: "Ground roasted peanuts", grams: 200 },
      { name: "Annatto powder (atsuete)", grams: 15 },
      { name: "Glutinous rice flour", grams: 20 },
      { name: "Sibuyas (onion)", grams: 100 },
      { name: "Bawang (garlic)", grams: 10 },
      { name: "Mantika (cooking oil)", grams: 60 },
      { name: "Patis (fish sauce)", grams: 40 },
      { name: "Beef broth", grams: 960 },
      { name: "Paminta (black pepper)", grams: 1 },
      { name: "Bagoong alamang (shrimp paste)", grams: 60 },
    ],
    instructions: [
      "1. Heat oil; sauté onion, then add garlic and cook until onion is soft.",
      "2. Sprinkle in pepper. Add beef and cook until light brown.",
      "3. Add ground peanuts; stir and cook 2 minutes.",
      "4. Pour in beef broth, boil, then cover and simmer 60 to 90 minutes until beef is tender.",
      "5. Blanch string beans (2 min), eggplant, and bok choy in boiling water, then shock in ice water.",
      "6. When beef is tender, add fish sauce and a mixture of annatto powder, water, and glutinous rice powder. Cook 3 to 5 minutes until thickened.",
      "7. Serve with blanched vegetables on the side and bagoong alamang on top, with warm rice."
    ]
  },
  {
    name: "Pancit Udon",
    description: "Stir-fried udon noodles with pork, squid balls, and vegetables.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Udon noodles", grams: 360 },
      { name: "Squid balls", grams: 150 },
      { name: "Repolyo (cabbage)", grams: 200 },
      { name: "Karot (carrot)", grams: 100 },
      { name: "Sibuyas (onion)", grams: 80 },
      { name: "Baboy (pork, kasim/shoulder)", grams: 120 },
      { name: "Toyo (soy sauce)", grams: 120 },
      { name: "Lemon", grams: 50 },
      { name: "Spring onions (dahon ng sibuyas)", grams: 30 },
      { name: "Olive oil (extra virgin)", grams: 20 },
      { name: "Mantika (cooking oil)", grams: 40 },
      { name: "Bawang (garlic)", grams: 10 },
      { name: "Asin (salt)", grams: 3 },
      { name: "Paminta (black pepper)", grams: 1 },
    ],
    instructions: [
      "1. Boil water in a deep pot. Add udon and boil 10 to 12 minutes.",
      "2. Drain, transfer to a bowl, and toss with olive oil. Set aside.",
      "3. Heat cooking oil in a wok; sauté onion and garlic.",
      "4. Add pork once onion is soft; cook 2 minutes.",
      "5. Add squid balls; cook 2 minutes.",
      "6. Add carrots and cabbage; stir fry 3 minutes.",
      "7. Slowly add noodles. Pour in soy sauce and squeeze in lemon; stir fry 3 to 5 minutes.",
      "8. Season with salt and pepper, top with green onions, and serve."
    ]
  },
  {
    name: "Menudo with Raisins and Green Peas",
    description: "Pork and liver stew with hotdogs, raisins, and green peas.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Baboy (pork, kasim/shoulder)", grams: 900 },
      { name: "Atay ng baboy (pork liver)", grams: 230 },
      { name: "Hotdogs (Filipino-style)", grams: 150 },
      { name: "Patatas (potato)", grams: 300 },
      { name: "Karot (carrot)", grams: 200 },
      { name: "Sibuyas (onion)", grams: 200 },
      { name: "Bawang (garlic)", grams: 25 },
      { name: "Pasas (raisins)", grams: 80 },
      { name: "Gisantes (green peas)", grams: 120 },
      { name: "Dahon ng laurel (bay leaves)", grams: 2 },
      { name: "Tomato sauce", grams: 425 },
      { name: "Toyo (soy sauce)", grams: 60 },
      { name: "Mantika (cooking oil)", grams: 70 },
      { name: "Maggi Magic Sarap", grams: 8 },
      { name: "Patis (fish sauce)", grams: 15 },
      { name: "Paminta (black pepper)", grams: 2 },
    ],
    instructions: [
      "1. Marinate the pork with soy sauce and half of the garlic for 10 minutes.",
      "2. Heat 2 tbsp oil. Sauté hotdogs 1 minute; set aside. Sauté 1 onion until soft, add liver and sauté 2 minutes; remove and set aside.",
      "3. Heat remaining oil in a pot. Sauté remaining garlic until brown, then remaining onion.",
      "4. Add marinated pork; cook 3 minutes. Pour in tomato sauce and water, cover, and bring to a boil.",
      "5. Add bay leaves and raisins. Simmer until pork is tender (about 30 to 40 minutes). Return liver and hotdogs; stir.",
      "6. Add carrots and potatoes; cover and cook 8 minutes.",
      "7. Add green peas and Magic Sarap; cook 3 minutes.",
      "8. Season with fish sauce and pepper. Serve."
    ]
  },
  {
    name: "Chicken Carbonara",
    description: "Creamy spaghetti carbonara with pancetta and baked chicken.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Spaghetti noodles", grams: 450 },
      { name: "Pancetta", grams: 115 },
      { name: "Manok pecho (chicken breast)", grams: 230 },
      { name: "Heavy whipping cream", grams: 360 },
      { name: "Parmesan cheese", grams: 100 },
      { name: "Itlog (egg)", grams: 120 },
      { name: "Fresh basil", grams: 10 },
      { name: "Flat leaf parsley", grams: 10 },
      { name: "Olive oil (extra virgin)", grams: 30 },
      { name: "Bawang (garlic)", grams: 10 },
      { name: "Asin (salt)", grams: 3 },
      { name: "Paminta (black pepper)", grams: 1 },
      { name: "Lemon", grams: 5 },
    ],
    instructions: [
      "1. Cook the spaghetti per package instructions; set aside.",
      "2. In a large bowl, whisk egg yolks, cream, Parmesan, basil, and parsley; set aside.",
      "3. Heat oil in a wide pot. Add pancetta and cook 5 minutes.",
      "4. Add garlic and cook until light brown.",
      "5. Add shredded baked chicken; stir and cook 1 minute.",
      "6. Add cooked spaghetti and toss.",
      "7. Lower the heat, add the cream and egg mixture, and toss until well distributed.",
      "8. Season with salt and pepper. Serve garnished with grated lemon peel."
    ]
  },
  {
    name: "Pepper Steak",
    description: "Beef sirloin stir-fried with bell peppers in a peppery sauce.",
    servings: 5,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Sirloin (beef)", grams: 450 },
      { name: "Atsal (bell pepper)", grams: 150 },
      { name: "Red bell pepper", grams: 150 },
      { name: "Sibuyas (onion)", grams: 100 },
      { name: "Mantika (cooking oil)", grams: 40 },
      { name: "White pepper", grams: 2 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Gawgaw (cornstarch)", grams: 20 },
      { name: "Oyster sauce", grams: 45 },
      { name: "Shaoxing wine", grams: 25 },
      { name: "Baking soda", grams: 1 },
      { name: "Chicken broth", grams: 180 },
      { name: "Toyo (soy sauce)", grams: 30 },
      { name: "Asukal (sugar)", grams: 3 },
      { name: "Sesame oil", grams: 1 },
    ],
    instructions: [
      "1. Combine sliced sirloin with all marinade ingredients; cover and refrigerate at least 3 hours.",
      "2. Mix all sauce ingredients in a bowl; set aside.",
      "3. Heat 1 tbsp oil in a wok; sauté garlic 10 seconds.",
      "4. Add onion and bell peppers and stir-fry about 1 minute. Remove and set aside.",
      "5. Heat remaining oil in the same wok. Add beef in a single layer and cook 20 to 35 seconds per side.",
      "6. Return vegetables to the wok and stir-fry 20 seconds.",
      "7. Stir the sauce again, pour it in, and cook on high heat, stirring, until it thickens.",
      "8. Season with white pepper. Serve hot with rice."
    ]
  },
  {
    name: "Sauteed Napa Cabbage with Ground Pork",
    description: "Napa cabbage sautéed with ground pork and tomatoes.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Napa cabbage", grams: 680 },
      { name: "Giniling na baboy (ground pork)", grams: 340 },
      { name: "Kamatis (tomato)", grams: 425 },
      { name: "Sibuyas (onion)", grams: 80 },
      { name: "Bawang (garlic)", grams: 5 },
      { name: "Mantika (cooking oil)", grams: 30 },
      { name: "Asin (salt)", grams: 3 },
      { name: "Paminta (black pepper)", grams: 1 },
    ],
    instructions: [
      "1. Heat the oil in a pan.",
      "2. Sauté the garlic and onion.",
      "3. Add diced tomatoes; stir and cook until liquid evaporates.",
      "4. Add ground pork; cook 8 to 12 minutes.",
      "5. Add cabbage; stir and cook 5 minutes.",
      "6. Season with salt and pepper. Serve."
    ]
  },
  {
    name: "Sauteed String Beans with Chicken",
    description: "String beans stir-fried with chicken in soy-oyster sauce.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Sitaw (yardlong beans)", grams: 400 },
      { name: "Manok pecho (chicken breast)", grams: 115 },
      { name: "Bawang (garlic)", grams: 5 },
      { name: "Sibuyas (onion)", grams: 80 },
      { name: "Toyo (soy sauce)", grams: 30 },
      { name: "Oyster sauce", grams: 22 },
      { name: "French fried onion", grams: 50 },
      { name: "Asin (salt)", grams: 3 },
      { name: "Paminta (black pepper)", grams: 1 },
      { name: "Mantika (cooking oil)", grams: 40 },
    ],
    instructions: [
      "1. Heat the oil in a pan.",
      "2. Sauté the garlic and onion.",
      "3. Add the chicken slices; cook 3 minutes.",
      "4. Add soy sauce, oyster sauce, and water; stir, cover, and simmer until water nearly evaporates.",
      "5. Increase heat to high, add string beans, and cook while stirring 3 to 5 minutes.",
      "6. Season with salt and pepper. Top with French fried onion and serve."
    ]
  },
  {
    name: "Breaded Shrimp with Sweet and Sour Sauce",
    description: "Crispy breaded shrimp served with sweet and sour dipping sauce.",
    servings: 6,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Hipon (shrimp)", grams: 900 },
      { name: "Itlog (egg)", grams: 100 },
      { name: "Bread crumbs", grams: 90 },
      { name: "Harina (all-purpose flour)", grams: 60 },
      { name: "Asin (salt)", grams: 8 },
      { name: "Paminta (black pepper)", grams: 1 },
      { name: "Mantika (cooking oil)", grams: 400 },
      { name: "Sweet and sour sauce", grams: 180 },
    ],
    instructions: [
      "1. Sprinkle salt and pepper on shrimp; let stand 15 minutes.",
      "2. Heat the oil in a deep pan.",
      "3. Dredge shrimp in flour, dip in beaten eggs, then roll in breadcrumbs.",
      "4. Deep fry 3 to 4 minutes until golden brown.",
      "5. Drain on paper towels. Serve with sweet and sour sauce."
    ]
  },
  {
    name: "Fried Chicken Breast with Creamy Lemon Sauce Dip",
    description: "Crispy fried chicken breast with a creamy lemon dipping sauce.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Manok pecho (chicken breast)", grams: 600 },
      { name: "Harina (all-purpose flour)", grams: 120 },
      { name: "Itlog (egg)", grams: 50 },
      { name: "Asin (salt)", grams: 8 },
      { name: "Paminta (black pepper)", grams: 2 },
      { name: "Mantika (cooking oil)", grams: 400 },
      { name: "Mantikilya (butter)", grams: 30 },
      { name: "Lemon", grams: 45 },
      { name: "Itlog (egg)", grams: 20 },
      { name: "Heavy whipping cream", grams: 240 },
      { name: "Asin (salt)", grams: 2 },
    ],
    instructions: [
      "1. Rub salt and pepper on chicken breasts; set aside.",
      "2. Sauce: melt butter in a saucepan, stir in lemon juice, then pour in the cream and add salt.",
      "3. When mixture is about to boil, add the egg yolk and stir continuously for about a minute until thickened. Set aside.",
      "4. Heat the oil in a frying pan.",
      "5. Dredge chicken in flour, dip in beaten egg, then dredge in flour again.",
      "6. Deep fry on medium heat 7 to 9 minutes until light to golden brown.",
      "7. Serve with the creamy lemon sauce."
    ]
  },
  {
    name: "Tonkatsu",
    description: "Panko-breaded pork cutlet served with shredded cabbage.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Pork chops", grams: 600 },
      { name: "Panko breadcrumbs", grams: 100 },
      { name: "Itlog (egg)", grams: 50 },
      { name: "Harina (all-purpose flour)", grams: 15 },
      { name: "Repolyo (cabbage)", grams: 200 },
      { name: "Mantika (cooking oil)", grams: 150 },
      { name: "Asin (salt)", grams: 3 },
      { name: "Paminta (black pepper)", grams: 1 },
      { name: "Tonkatsu sauce", grams: 120 },
    ],
    instructions: [
      "1. Rub salt and pepper on pork chops; let stand 15 minutes.",
      "2. Heat the oil in a frying pan.",
      "3. Coat pork chops with flour, dip in beaten egg, then coat completely with Panko.",
      "4. Fry on low to medium heat until golden brown, about 6 to 9 minutes per side.",
      "5. Serve with shredded cabbage and tonkatsu sauce."
    ]
  },

  {
    name: "Chicken Bicol Express",
    description: "Chicken simmered in coconut milk with shrimp paste and chilies.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Manok pecho (chicken breast)", grams: 450 },
      { name: "Chicken cube (bouillon)", grams: 4 },
      { name: "Gata (coconut milk)", grams: 480 },
      { name: "Sili na mura (green finger chili)", grams: 60 },
      { name: "Siling labuyo (bird's eye chili)", grams: 25 },
      { name: "Luya (ginger)", grams: 15 },
      { name: "Bagoong alamang (shrimp paste)", grams: 15 },
      { name: "Sibuyas (onion)", grams: 60 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Mantika (cooking oil)", grams: 40 },
    ],
    instructions: [
      "1. Heat the oil in a pot and sauté the garlic, onion, and ginger.",
      "2. Once the onion softens, add the chicken and chili peppers; cook until lightly browned.",
      "3. Pour in the coconut milk and bring to a boil.",
      "4. Add the chicken cube and cook over low-to-medium heat until the coconut milk reduces by half.",
      "5. Add the bagoong alamang and long green peppers, cover, and cook 2 minutes.",
      "6. Transfer to a serving bowl and serve."
    ]
  },
  {
    name: "Ginisang Sayote at Sardinas",
    description: "Chayote sautéed with canned sardines in tomato sauce.",
    servings: 3,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Sardinas (canned sardines)", grams: 280 },
      { name: "Sayote (chayote)", grams: 600 },
      { name: "Sibuyas (onion)", grams: 60 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Kamatis (tomato)", grams: 100 },
      { name: "Maggi Magic Sarap", grams: 4 },
      { name: "Mantika (cooking oil)", grams: 40 },
    ],
    instructions: [
      "1. Heat the oil in a pan over medium heat and sauté the garlic until it starts to brown.",
      "2. Add the onion and tomato and sauté 1 minute.",
      "3. Add the chayote and sauté 2 minutes.",
      "4. Pour in the sardines and stir gently; cook 30 seconds.",
      "5. Add the water, bring to a boil, then lower the heat and simmer until the sauce reduces by half.",
      "6. Season with Magic Sarap and serve with rice, topped with green onions if desired."
    ]
  },
  {
    name: "Sarciadong Pechay at Itlog",
    description: "Pechay and hard-boiled eggs in a light tomato-egg sauce.",
    servings: 6,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Itlog (egg)", grams: 750 },
      { name: "Maggi Magic Sarap", grams: 8 },
      { name: "Pechay (bok choy)", grams: 600 },
      { name: "Kamatis (tomato)", grams: 400 },
      { name: "Sibuyas (onion)", grams: 80 },
      { name: "Bawang (garlic)", grams: 20 },
      { name: "Patis (fish sauce)", grams: 5 },
      { name: "Paminta (black pepper)", grams: 1 },
      { name: "Mantika (cooking oil)", grams: 40 },
    ],
    instructions: [
      "1. Boil 12 eggs until firm (10–12 minutes), then peel and set aside.",
      "2. Beat the remaining 3 eggs in a bowl.",
      "3. Heat the oil in a wok and sauté the onion 1 minute, then the garlic 1 minute.",
      "4. Add the tomatoes and cook until soft; stir in the fish sauce and pepper.",
      "5. Pour in the water and boil 1–2 minutes.",
      "6. Pour in the beaten eggs in a slow stream, let set briefly, then stir in.",
      "7. Add the pechay and cook 1–2 minutes.",
      "8. Season with Magic Sarap, add the boiled eggs, and cook 1 more minute. Serve with rice."
    ]
  },
  {
    name: "Ginisang Monggo with Kalabasa",
    description: "Mung bean stew with squash, malunggay, and chicharon.",
    servings: 6,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Mung beans (munggo)", grams: 400 },
      { name: "Kalabasa (squash)", grams: 450 },
      { name: "Hibe (salted dried shrimp)", grams: 40 },
      { name: "Malunggay (moringa leaves)", grams: 60 },
      { name: "Spinach", grams: 60 },
      { name: "Kamatis (tomato)", grams: 150 },
      { name: "Sibuyas (onion)", grams: 60 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Chicharon (pork cracklings)", grams: 80 },
      { name: "Maggi Magic Sarap", grams: 8 },
      { name: "Patis (fish sauce)", grams: 45 },
      { name: "Paminta (black pepper)", grams: 1 },
      { name: "Mantika (cooking oil)", grams: 40 },
    ],
    instructions: [
      "1. Soak the mung beans overnight in 1/2 quart of water.",
      "2. Heat the oil in a deep pot, sauté the garlic until browning, then add the onion and tomatoes and cook until soft.",
      "3. Add the dried shrimp and soaked mung beans; stir well.",
      "4. Add the fish sauce and 1 quart of water, cover, and simmer until the beans are soft and the soup is thick.",
      "5. Add the squash and cook until tender.",
      "6. Add the malunggay and spinach and cook 1 minute.",
      "7. Season with pepper and Magic Sarap. Top with chicharon and serve hot with rice."
    ]
  },
  {
    name: "Ginisang Repolyo with Egg",
    description: "Cabbage stir-fried with eggs, carrots, and soy-oyster sauce.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Repolyo (cabbage)", grams: 800 },
      { name: "Itlog (egg)", grams: 250 },
      { name: "Karot (carrot)", grams: 200 },
      { name: "Sibuyas (onion)", grams: 80 },
      { name: "Spring onions (dahon ng sibuyas)", grams: 50 },
      { name: "Bawang (garlic)", grams: 20 },
      { name: "Toyo (soy sauce)", grams: 45 },
      { name: "Oyster sauce", grams: 22 },
      { name: "Sesame oil", grams: 10 },
      { name: "Asin (salt)", grams: 10 },
      { name: "Paminta (black pepper)", grams: 1 },
      { name: "Asukal (sugar)", grams: 2 },
      { name: "Mantika (cooking oil)", grams: 70 },
    ],
    instructions: [
      "1. Toss the cabbage with the salt, let stand 10 minutes, then rinse and set aside.",
      "2. Beat the eggs with a little salt and pepper.",
      "3. Heat 2 tbsp oil in a pan, pour in the eggs, cook until firm, break into small pieces, and remove.",
      "4. Heat the remaining oil and sauté the onion and garlic until the onion softens.",
      "5. Add the carrots and sauté 30 seconds, then the cabbage for 2 minutes.",
      "6. Add the soy sauce, oyster sauce, and sugar (if using); cook 1 minute.",
      "7. Return the eggs to the pan with the green onions and sesame oil, and season with pepper."
    ]
  },
  {
    name: "Fried Eggplant (Talong Okoy)",
    description: "Crispy grated eggplant fritters with a spicy vinegar dip.",
    servings: 4,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Talong (eggplant)", grams: 600 },
      { name: "Itlog (egg)", grams: 100 },
      { name: "Spring onions (dahon ng sibuyas)", grams: 50 },
      { name: "Gawgaw (cornstarch)", grams: 30 },
      { name: "Harina (all-purpose flour)", grams: 60 },
      { name: "Baking powder", grams: 2 },
      { name: "Asin (salt)", grams: 25 },
      { name: "Paminta (black pepper)", grams: 1 },
      { name: "Mantika (cooking oil)", grams: 400 },
      { name: "Suka (vinegar)", grams: 240 },
      { name: "Toyo (soy sauce)", grams: 10 },
      { name: "Sibuyas (onion)", grams: 60 },
      { name: "Siling labuyo (bird's eye chili)", grams: 15 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Asukal (sugar)", grams: 5 },
    ],
    instructions: [
      "1. Grate the eggplants, toss with 4 tsp of the salt, and let stand 10 minutes.",
      "2. Rinse with water, then squeeze the eggplant until completely drained.",
      "3. Mix the flour, cornstarch, and baking powder in a bowl.",
      "4. Beat the eggs in a large bowl; add the eggplant, green onions, remaining salt, and pepper and mix.",
      "5. Gradually stir in the flour mixture until well blended.",
      "6. Heat the oil. Scoop about 3 tbsp of batter per fritter and fry until both sides are brown and crisp. Drain.",
      "7. Dipping sauce: combine the vinegar, sugar, salt, pepper, and soy sauce; microwave 30 seconds and stir. Add the chilies, onion, garlic, and green onion. Serve with the fritters."
    ]
  },
  {
    name: "Garlic Tokwa and Kangkong in Oyster Sauce",
    description: "Fried tofu and water spinach in a garlicky oyster sauce.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Kangkong (water spinach)", grams: 300 },
      { name: "Tokwa (tofu)", grams: 340 },
      { name: "Bawang (garlic)", grams: 40 },
      { name: "Sibuyas (onion)", grams: 80 },
      { name: "Mantika (cooking oil)", grams: 360 },
      { name: "Oyster sauce", grams: 45 },
      { name: "Knorr Liquid Seasoning", grams: 10 },
      { name: "Toyo (soy sauce)", grams: 15 },
      { name: "Gawgaw (cornstarch)", grams: 12 },
      { name: "Asin (salt)", grams: 3 },
      { name: "Paminta (black pepper)", grams: 1 },
    ],
    instructions: [
      "1. Crush and chop the garlic. Cook it in 1/2 cup oil over medium heat until bubbling, then lower to the lowest heat and stir until golden brown.",
      "2. Strain the garlic from the oil and set both aside.",
      "3. Heat the remaining oil with the garlic oil (keep about 3 tbsp aside). Fry the tofu until golden, cool, and dice.",
      "4. Mix all the sauce ingredients in a bowl.",
      "5. Heat the reserved garlic oil in a clean pan and sauté the onion until soft.",
      "6. Add the tofu and sauté 30 seconds, then the kangkong for 1 minute.",
      "7. Pour in the sauce and cook, stirring, until thickened.",
      "8. Add half the fried garlic, season, top with the rest, and serve with rice."
    ]
  },
  {
    name: "Veggie Balls with Manong Sauce",
    description: "Fried vegetable balls served with a sweet-spicy Manong sauce.",
    servings: 8,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Harina (all-purpose flour)", grams: 240 },
      { name: "Gawgaw (cornstarch)", grams: 35 },
      { name: "Baking powder", grams: 8 },
      { name: "Knorr Liquid Seasoning", grams: 20 },
      { name: "Karot (carrot)", grams: 80 },
      { name: "Spring onions (dahon ng sibuyas)", grams: 40 },
      { name: "Gisantes (green peas)", grams: 120 },
      { name: "Kalabasa (squash)", grams: 80 },
      { name: "Onion powder", grams: 5 },
      { name: "Garlic powder", grams: 5 },
      { name: "Paminta (black pepper)", grams: 2 },
      { name: "Mantika (cooking oil)", grams: 400 },
      { name: "Asukal (sugar)", grams: 100 },
      { name: "Star anise", grams: 2 },
      { name: "Siling labuyo (bird's eye chili)", grams: 15 },
      { name: "Suka (vinegar)", grams: 360 },
      { name: "Toyo (soy sauce)", grams: 45 },
    ],
    instructions: [
      "1. Manong sauce: boil water with the star anise, brown sugar, liquid seasoning, garlic powder, onion powder, black pepper, and chili. Simmer 5 minutes.",
      "2. Mix the cornstarch with water, pour in, and stir constantly until thick. Transfer to a bottle and cool.",
      "3. Spicy vinegar dip: mix all its ingredients together and set aside.",
      "4. Veggie balls: combine the flour, cornstarch, and baking powder, then gradually stir in the water.",
      "5. Add the carrot, green onions, kalabasa, and peas, then season with liquid seasoning, onion powder, garlic powder, and pepper.",
      "6. Heat the oil, mold the mixture into balls, and fry over medium heat until golden brown.",
      "7. Skewer on bamboo sticks and serve with the manong sauce or vinegar dip."
    ]
  },
  {
    name: "Crispy Cabbage Rolls",
    description: "Pork-stuffed cabbage rolls breaded in panko and fried until crispy.",
    servings: 6,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Napa cabbage", grams: 400 },
      { name: "Asin (salt)", grams: 3 },
      { name: "Giniling na baboy (ground pork)", grams: 450 },
      { name: "Pork cube (bouillon)", grams: 4 },
      { name: "Sibuyas (onion)", grams: 80 },
      { name: "Bawang (garlic)", grams: 20 },
      { name: "Karot (carrot)", grams: 60 },
      { name: "Spring onions (dahon ng sibuyas)", grams: 40 },
      { name: "Itlog (egg)", grams: 200 },
      { name: "Harina (all-purpose flour)", grams: 100 },
      { name: "Toyo (soy sauce)", grams: 30 },
      { name: "Sesame oil", grams: 10 },
      { name: "Mantika (cooking oil)", grams: 280 },
      { name: "Panko breadcrumbs", grams: 90 },
    ],
    instructions: [
      "1. Boil water with salt, blanch the cabbage leaves 1 minute, then chill in cold water and dry.",
      "2. Heat 3 tbsp oil, sauté the garlic until browning, then the onion until soft. Add the pork and cook until light brown.",
      "3. Add the pork cube, cook 2 minutes, season with salt and pepper, and cool in a large bowl.",
      "4. Mix in the carrot, green onion, 1 egg, flour, soy sauce, and sesame oil.",
      "5. Put 3 tbsp filling on each cabbage leaf, fold in the sides, roll up, and secure with a toothpick.",
      "6. Dredge each roll in flour, dip in beaten egg, then coat in panko.",
      "7. Fry in hot oil until golden on both sides. Drain.",
      "8. Slice into bite-sized pieces and serve with a dipping sauce."
    ]
  },
  {
    name: "Utan nga Langka",
    description: "Young jackfruit simmered in coconut milk with dried fish and bago leaves.",
    servings: 6,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Langka (jackfruit)", grams: 900 },
      { name: "Shrimp cube (bouillon)", grams: 4 },
      { name: "Gata (coconut milk)", grams: 720 },
      { name: "Dahon ng bago (bago leaves)", grams: 100 },
      { name: "Dulong (silverfish)", grams: 100 },
      { name: "Sibuyas (onion)", grams: 120 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Siling labuyo (bird's eye chili)", grams: 15 },
      { name: "Suka (vinegar)", grams: 30 },
      { name: "Patis (fish sauce)", grams: 15 },
      { name: "Paminta (black pepper)", grams: 2 },
      { name: "Mantika (cooking oil)", grams: 40 },
    ],
    instructions: [
      "1. Heat the oil in a large wok and sauté the onion and garlic.",
      "2. When the onion softens, add the dried fish and cook 1 minute.",
      "3. Add the jackfruit and cook, stirring, 2–3 minutes.",
      "4. Add the chilies and bago leaves and stir.",
      "5. Season with 1 tbsp fish sauce, pour in the coconut milk, and bring to a boil.",
      "6. Add the vinegar and cook 5–8 minutes.",
      "7. Add the shrimp cube and cook until the liquid has evaporated.",
      "8. Season with pepper and more fish sauce. Serve with warm rice."
    ]
  },
  {
    name: "Ginataang Hipon, Sitaw at Kalabasa",
    description: "Shrimp, string beans, and squash simmered in coconut milk.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Hipon (shrimp)", grams: 450 },
      { name: "Sitaw (yardlong beans)", grams: 100 },
      { name: "Kalabasa (squash)", grams: 300 },
      { name: "Gata (coconut milk)", grams: 480 },
      { name: "Sibuyas (onion)", grams: 80 },
      { name: "Bagoong alamang (shrimp paste)", grams: 30 },
      { name: "Malunggay (moringa leaves)", grams: 60 },
      { name: "Bawang (garlic)", grams: 10 },
      { name: "Mantika (cooking oil)", grams: 40 },
      { name: "Asin (salt)", grams: 3 },
      { name: "Paminta (black pepper)", grams: 1 },
    ],
    instructions: [
      "1. Heat the oil in a pot and sauté the garlic and onion until the onion is soft.",
      "2. Add the shrimp and cook 1–2 minutes, then remove and set aside.",
      "3. Add the bagoong and pour in the coconut milk; stir and bring to a boil.",
      "4. Add the kalabasa and cook 8–12 minutes until tender.",
      "5. Return the shrimp to the pot, stir, and cook 1 minute.",
      "6. Add the string beans and malunggay and cook 2–3 minutes.",
      "7. Season with salt and pepper and serve."
    ]
  },
  {
    name: "Vegetable Okoy",
    description: "Crispy squash and carrot fritters with a vinegar dip.",
    servings: 4,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Kalabasa (squash)", grams: 230 },
      { name: "Karot (carrot)", grams: 80 },
      { name: "Malunggay (moringa leaves)", grams: 40 },
      { name: "Mantika (cooking oil)", grams: 240 },
      { name: "Gawgaw (cornstarch)", grams: 60 },
      { name: "Harina (all-purpose flour)", grams: 90 },
      { name: "Maggi Magic Sarap", grams: 8 },
      { name: "Itlog (egg)", grams: 50 },
      { name: "Sibuyas (onion)", grams: 60 },
      { name: "Spring onions (dahon ng sibuyas)", grams: 20 },
      { name: "Suka (vinegar)", grams: 180 },
    ],
    instructions: [
      "1. Slice the kalabasa and carrot into matchsticks and toss with the malunggay in a bowl.",
      "2. Beat the egg with the water, gradually whisk in the flour, cornstarch, and Magic Sarap until smooth.",
      "3. Fold the batter into the vegetables until coated.",
      "4. Mix all the dipping sauce ingredients together.",
      "5. Heat the oil in a pan. Slide in about 1/4 cup of the mixture per okoy and fry until golden and crisp, flipping once.",
      "6. Drain on paper towels and serve with the dipping sauce."
    ]
  },
  {
    name: "Eggplant and Sardine Omelet",
    description: "Grilled eggplant omelet topped with sautéed sardines.",
    servings: 2,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Talong (eggplant)", grams: 300 },
      { name: "Sardinas (canned sardines)", grams: 160 },
      { name: "Itlog (egg)", grams: 150 },
      { name: "Kamatis (tomato)", grams: 100 },
      { name: "Sibuyas (onion)", grams: 60 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Spring onions (dahon ng sibuyas)", grams: 30 },
      { name: "Calamansi", grams: 10 },
      { name: "Mantika (cooking oil)", grams: 120 },
      { name: "Asin (salt)", grams: 3 },
      { name: "Paminta (black pepper)", grams: 1 },
    ],
    instructions: [
      "1. Sardine topping: sauté the garlic, onion, and tomato until soft. Add the sardines and about a quarter of the can's sauce and cook 2 minutes. Season with salt and pepper, squeeze in the calamansi, add some green onion, and set aside.",
      "2. Beat the eggs until smooth.",
      "3. Grill the eggplants until soft and steaming from cracks in the skin; cool and peel.",
      "4. Flatten each eggplant on a plate with a fork.",
      "5. Heat the remaining oil in a clean pan.",
      "6. Dip an eggplant in the beaten egg and lay it in the pan. Top with sardines and green onion, then pour some beaten egg over the toppings. Cook until the bottom is golden.",
      "7. Flip gently and cook the other side. Serve with the sardine side up, with rice."
    ]
  },
  {
    name: "Crispy Eggplant Fries",
    description: "Panko-crusted eggplant strips with a creamy mayo-ketchup dip.",
    servings: 2,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Talong (eggplant)", grams: 300 },
      { name: "Harina (all-purpose flour)", grams: 60 },
      { name: "Panko breadcrumbs", grams: 60 },
      { name: "Itlog (egg)", grams: 50 },
      { name: "Asin (salt)", grams: 3 },
      { name: "Mantika (cooking oil)", grams: 300 },
      { name: "Mayonnaise", grams: 60 },
      { name: "Banana ketchup", grams: 45 },
      { name: "Tabasco sauce", grams: 3 },
      { name: "Onion powder", grams: 1 },
      { name: "Garlic powder", grams: 1 },
    ],
    instructions: [
      "1. Slice the eggplant into thick strips.",
      "2. Beat the egg in one bowl; put the flour and panko in separate bowls.",
      "3. Heat the oil in a pot. Coat each strip in flour, dip in egg, and roll in panko.",
      "4. Fry over medium heat until the crumbs are golden brown, then drain on paper towels.",
      "5. Mix the dipping sauce ingredients together.",
      "6. Serve the fries with the dipping sauce as an appetizer."
    ]
  },
  {
    name: "Kalabasa and Corned Beef Nuggets",
    description: "Crispy nuggets made with grated squash and corned beef.",
    servings: 4,
    tags: ["all", "snack", "dessert"],
    ingredients: [
      { name: "Corned beef", grams: 340 },
      { name: "Kalabasa (squash)", grams: 250 },
      { name: "Itlog (egg)", grams: 50 },
      { name: "Garlic powder", grams: 3 },
      { name: "Paminta (black pepper)", grams: 1 },
      { name: "Asin (salt)", grams: 5 },
      { name: "Bread crumbs", grams: 180 },
      { name: "Mantika (cooking oil)", grams: 500 },
    ],
    instructions: [
      "1. Grate the kalabasa with a cheese grater or food processor.",
      "2. Mix the grated kalabasa and corned beef in a bowl.",
      "3. Add the garlic powder, pepper, salt, egg, and 1 cup breadcrumbs and mix well.",
      "4. Heat the oil in a pot.",
      "5. Scoop about 2 tbsp of the mixture, mold into a nugget, and coat in breadcrumbs.",
      "6. Fry each side until golden brown, then drain off the excess oil.",
      "7. Serve with your favorite dipping sauce."
    ]
  },
  {
    name: "Tasty Ginisang Sayote",
    description: "Chayote sautéed with pork belly and carrots.",
    servings: 5,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Sayote (chayote)", grams: 900 },
      { name: "Pork liquid seasoning", grams: 16 },
      { name: "Karot (carrot)", grams: 80 },
      { name: "Liempo (pork belly)", grams: 140 },
      { name: "Sibuyas (onion)", grams: 60 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Paminta (black pepper)", grams: 1 },
    ],
    instructions: [
      "1. Heat a pot and sear the pork until brown and its oil has rendered.",
      "2. Add the onion and garlic and sauté until the onion softens.",
      "3. Pour in 1 1/2 cups water, bring to a boil, cover, and cook on low heat until the liquid has evaporated.",
      "4. Add the sayote and sauté 2–3 minutes.",
      "5. Add the carrots and sauté 2 minutes.",
      "6. Stir in the liquid seasoning, add pepper if you like, pour in 1/4 cup water, cover, and cook 1 minute. Serve."
    ]
  },
  {
    name: "Adobong Sitaw at Kangkong with Chicharon",
    description: "String beans and water spinach adobo topped with chicharon.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Sitaw (yardlong beans)", grams: 200 },
      { name: "Kangkong (water spinach)", grams: 300 },
      { name: "Chicharon (pork cracklings)", grams: 100 },
      { name: "Suka (vinegar)", grams: 45 },
      { name: "Toyo (soy sauce)", grams: 60 },
      { name: "Bawang (garlic)", grams: 20 },
      { name: "Sibuyas (onion)", grams: 60 },
      { name: "Mantika (cooking oil)", grams: 40 },
      { name: "Asin (salt)", grams: 3 },
      { name: "Paminta (black pepper)", grams: 1 },
    ],
    instructions: [
      "1. Heat the oil and sauté the garlic and onion until the onion softens and the garlic is light brown.",
      "2. Pour in the soy sauce, vinegar, and water and bring to a boil.",
      "3. Add the chicharon, cover, and cook 10 minutes on medium heat.",
      "4. Add the sitaw and cook 5 minutes.",
      "5. Add the kangkong stalks and cook 3 minutes, then the leaves for 2 minutes.",
      "6. Season with salt and pepper and serve (top with more chicharon if you like)."
    ]
  },
  {
    name: "Chicken Sotanghon Soup with Patola",
    description: "Glass noodle soup with chicken and luffa in annatto oil.",
    servings: 6,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Manok (chicken)", grams: 680 },
      { name: "Patola (luffa/sponge gourd)", grams: 300 },
      { name: "Sotanghon (glass noodles)", grams: 140 },
      { name: "Bawang (garlic)", grams: 25 },
      { name: "Sibuyas (onion)", grams: 60 },
      { name: "Chicken powder", grams: 15 },
      { name: "Annatto oil (atsuete oil)", grams: 40 },
      { name: "Spring onions (dahon ng sibuyas)", grams: 30 },
      { name: "Patis (fish sauce)", grams: 15 },
      { name: "Paminta (black pepper)", grams: 1 },
    ],
    instructions: [
      "1. Heat the annatto oil over medium heat. Sauté the garlic until lightly golden, then the onion until soft.",
      "2. Add the chicken and cook, stirring, until lightly browned all over.",
      "3. Pour in the water, bring to a boil, add the chicken powder, and simmer 20 minutes until tender, skimming off foam.",
      "4. Add the sotanghon and cook about 3 minutes, stirring gently.",
      "5. Add the patola and cook 2 minutes.",
      "6. Season with fish sauce and pepper, ladle into bowls, and top with roasted garlic and green onions."
    ]
  },
  {
    name: "Crispy Fried Chicken Thighs",
    description: "Buttermilk-marinated chicken thighs double-dredged and fried crispy.",
    servings: 5,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Manok (chicken)", grams: 900 },
      { name: "Evaporated milk (evaporada)", grams: 400 },
      { name: "Calamansi", grams: 20 },
      { name: "Maggi Magic Sarap", grams: 8 },
      { name: "Paminta (black pepper)", grams: 1 },
      { name: "Harina (all-purpose flour)", grams: 180 },
      { name: "Gawgaw (cornstarch)", grams: 60 },
      { name: "Baking powder", grams: 6 },
      { name: "Garlic powder", grams: 3 },
      { name: "Onion powder", grams: 3 },
      { name: "Paprika", grams: 3 },
      { name: "Itlog (egg)", grams: 100 },
      { name: "Mantika (cooking oil)", grams: 400 },
    ],
    instructions: [
      "1. Mix the evaporated milk, calamansi juice, Magic Sarap, and pepper. Add the chicken, coat well, cover, and refrigerate at least 3 hours.",
      "2. Combine all the flour dredge ingredients in a separate bowl.",
      "3. Lift each chicken piece from the marinade and coat in the flour mixture; shake off the excess.",
      "4. Stir the beaten eggs into the leftover marinade.",
      "5. Dip each floured piece in the egg-marinade, then dredge in the flour again, pressing it on.",
      "6. Rest the coated chicken on a wire rack for 15 minutes.",
      "7. Heat the oil to about 350°F and fry in batches, 7–8 minutes per side, until deep golden and cooked through.",
      "8. Drain on a wire rack and serve hot with rice."
    ]
  },
  {
    name: "Pocherong Manok",
    description: "Chicken stew with saba, potatoes, chickpeas, and chorizo.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Manok (chicken)", grams: 900 },
      { name: "Chicken cube (bouillon)", grams: 4 },
      { name: "Saging na saba (plantain)", grams: 300 },
      { name: "Patatas (potato)", grams: 300 },
      { name: "Chickpeas (garbanzos)", grams: 400 },
      { name: "Sitaw (yardlong beans)", grams: 150 },
      { name: "Repolyo (cabbage)", grams: 200 },
      { name: "Pechay (bok choy)", grams: 200 },
      { name: "Sibuyas (onion)", grams: 80 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Kamatis (tomato)", grams: 200 },
      { name: "Chorizo de Bilbao", grams: 80 },
      { name: "Tomato paste", grams: 45 },
      { name: "Mantika (cooking oil)", grams: 240 },
      { name: "Patis (fish sauce)", grams: 15 },
      { name: "Paminta (black pepper)", grams: 1 },
    ],
    instructions: [
      "1. Heat the oil in a wok and fry the bananas and potatoes until they start to brown. Set aside.",
      "2. Leave about 3 tbsp oil in the wok and pan-fry the chicken 2 minutes per side. Remove.",
      "3. Add 2 tbsp more oil and sauté the onion 1 minute.",
      "4. Stir in the garlic until it starts to brown, then add the tomatoes and sauté 1 minute.",
      "5. Add the chorizo, return the chicken, and cook 2 minutes.",
      "6. Add the tomato paste and water and bring to a boil.",
      "7. Stir in the chicken cube.",
      "8. Add the chickpeas, fried potatoes, and bananas and cook 2 minutes.",
      "9. Add the green beans and cabbage, cover, and cook 3 minutes.",
      "10. Season with fish sauce and pepper.",
      "11. Add the bok choy, cover, turn off the heat, and let it steam 2 minutes. Serve with rice."
    ]
  },
  {
    name: "Calderetang Manok",
    description: "Chicken stew with liver spread, bell peppers, and cheese.",
    servings: 5,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Manok (chicken)", grams: 1360 },
      { name: "Atsal (bell pepper)", grams: 150 },
      { name: "Patatas (potato)", grams: 200 },
      { name: "Karot (carrot)", grams: 150 },
      { name: "Tomato sauce", grams: 240 },
      { name: "Liver spread", grams: 85 },
      { name: "Toyo (soy sauce)", grams: 60 },
      { name: "Sibuyas (onion)", grams: 80 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Garlic powder", grams: 5 },
      { name: "Keso (cheese)", grams: 30 },
      { name: "Mantika (cooking oil)", grams: 120 },
      { name: "Lime", grams: 50 },
      { name: "Patis (fish sauce)", grams: 15 },
      { name: "Paminta (black pepper)", grams: 2 },
    ],
    instructions: [
      "1. Marinate the chicken in the soy sauce, garlic powder, pepper, and lime juice for at least 1 hour.",
      "2. Fry the potatoes (3–5 minutes) and carrots (2–3 minutes) until lightly browned. Set aside.",
      "3. Heat about 3 tbsp oil and sauté the onion and minced garlic until the onion softens.",
      "4. Add the marinated chicken and sauté until medium brown.",
      "5. Pour in the tomato sauce and water, cover, and bring to a boil. Simmer 40 minutes.",
      "6. Stir in the liver spread, then add the bell peppers, potato, and carrots.",
      "7. Season with fish sauce and pepper, stir in the grated cheese, and serve with rice."
    ]
  },
  {
    name: "Filipino Chicken Pasta Alfredo",
    description: "Creamy fettuccine Alfredo with chicken flakes and Parmesan.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Chicken flakes in oil", grams: 300 },
      { name: "Fettuccine", grams: 450 },
      { name: "All-purpose cream", grams: 500 },
      { name: "Sibuyas (onion)", grams: 80 },
      { name: "Parmesan cheese", grams: 75 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Mantikilya (butter)", grams: 30 },
      { name: "Flat leaf parsley", grams: 10 },
    ],
    instructions: [
      "1. Cook the pasta according to the package directions and set aside.",
      "2. Melt the butter in a pot and sauté the garlic and onion until the onion softens.",
      "3. Add the chicken flakes and cook 2 minutes.",
      "4. Pour in the cream, bring to a boil, then lower the heat and stir occasionally until the sauce thickens.",
      "5. Stir in the Parmesan.",
      "6. Add the cooked pasta and toss until coated. Top with parsley and serve."
    ]
  },
  {
    name: "Pinoy Chicken Sopas",
    description: "Creamy macaroni soup with shredded chicken, hotdogs, and vegetables.",
    servings: 6,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Manok (chicken)", grams: 450 },
      { name: "Chicken cube (bouillon)", grams: 8 },
      { name: "Hotdogs (Filipino-style)", grams: 120 },
      { name: "Repolyo (cabbage)", grams: 100 },
      { name: "Celery", grams: 60 },
      { name: "Karot (carrot)", grams: 80 },
      { name: "Evaporated milk (evaporada)", grams: 240 },
      { name: "Elbow macaroni", grams: 230 },
      { name: "Sibuyas (onion)", grams: 60 },
      { name: "Bawang (garlic)", grams: 10 },
      { name: "Mantika (cooking oil)", grams: 40 },
      { name: "Patis (fish sauce)", grams: 15 },
      { name: "Paminta (black pepper)", grams: 1 },
    ],
    instructions: [
      "1. Heat the oil and sauté the onion, garlic, and celery for 1 minute.",
      "2. Add the chicken, hotdogs, and 1 tbsp fish sauce; cook 1 minute.",
      "3. Pour in the water and bring to a boil.",
      "4. Add the chicken cubes, cover, and cook on the lowest heat for 10 minutes.",
      "5. Add the macaroni and cook for 18 minutes.",
      "6. Add the cabbage and evaporated milk.",
      "7. Season with pepper and more fish sauce if needed. Serve hot."
    ]
  },
  {
    name: "Pinoy Chicken Curry",
    description: "Filipino chicken curry with coconut milk and vegetables.",
    servings: 6,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Manok (chicken)", grams: 900 },
      { name: "Curry powder", grams: 15 },
      { name: "Patatas (potato)", grams: 200 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Celery", grams: 60 },
      { name: "Red bell pepper", grams: 100 },
      { name: "Sili na mura (green finger chili)", grams: 60 },
      { name: "Sibuyas (onion)", grams: 80 },
      { name: "Luya (ginger)", grams: 20 },
      { name: "Gata (coconut milk)", grams: 480 },
      { name: "All-purpose cream", grams: 120 },
      { name: "Mantika (cooking oil)", grams: 60 },
      { name: "Patis (fish sauce)", grams: 15 },
      { name: "Paminta (black pepper)", grams: 1 },
    ],
    instructions: [
      "1. Heat oil in a pan and fry the potato 1 minute per side. Set aside.",
      "2. In the remaining oil, sauté the garlic, onion, celery, and ginger until the onion softens.",
      "3. Add the chicken and sauté until lightly browned.",
      "4. Add 1 tbsp fish sauce and sauté 1 minute.",
      "5. Pour in the coconut milk and water and bring to a boil.",
      "6. Stir in the curry powder until dissolved, cover, and cook on low-medium heat until the liquid reduces by half.",
      "7. Add the bell pepper and fried potato and cook 5 minutes.",
      "8. Season with fish sauce and pepper, and stir in the cream if using. Serve."
    ]
  },
  {
    name: "Chicken Afritada",
    description: "Chicken stewed in tomato sauce with potatoes, carrots, and hotdogs.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Manok (chicken)", grams: 680 },
      { name: "Patatas (potato)", grams: 300 },
      { name: "Karot (carrot)", grams: 80 },
      { name: "Tomato sauce", grams: 240 },
      { name: "Hotdogs (Filipino-style)", grams: 100 },
      { name: "Gisantes (green peas)", grams: 80 },
      { name: "Dahon ng laurel (bay leaves)", grams: 2 },
      { name: "Sibuyas (onion)", grams: 80 },
      { name: "Bawang (garlic)", grams: 10 },
      { name: "Chicken broth", grams: 720 },
      { name: "Asukal (sugar)", grams: 2 },
      { name: "Mantika (cooking oil)", grams: 40 },
      { name: "Asin (salt)", grams: 3 },
      { name: "Paminta (black pepper)", grams: 1 },
    ],
    instructions: [
      "1. Heat the oil and sauté the onion and garlic until the onion softens.",
      "2. Add the chicken and cook 30 seconds per side.",
      "3. Pour in the tomato sauce and chicken broth, cover, and bring to a boil.",
      "4. Add the bay leaves, cover, and cook on medium heat for 30 minutes.",
      "5. Add the hotdogs and carrot and cook 3 minutes.",
      "6. Add the potato, cover, and cook 8 minutes.",
      "7. Add the green peas and cook 2 minutes.",
      "8. Season with salt and pepper and serve."
    ]
  },
  {
    name: "Sweet and Sour Chicken Meatballs",
    description: "Chicken meatballs in a sweet and sour sauce with bell pepper and carrot.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Giniling na baboy (ground pork)", grams: 450 },
      { name: "Bread crumbs", grams: 60 },
      { name: "Chicken cube (bouillon)", grams: 4 },
      { name: "Itlog (egg)", grams: 50 },
      { name: "Asin (salt)", grams: 2 },
      { name: "Paminta (black pepper)", grams: 1 },
      { name: "Mantika (cooking oil)", grams: 60 },
      { name: "Banana ketchup", grams: 60 },
      { name: "Asukal (sugar)", grams: 60 },
      { name: "Suka (vinegar)", grams: 60 },
      { name: "Atsal (bell pepper)", grams: 60 },
      { name: "Sibuyas (onion)", grams: 30 },
      { name: "Karot (carrot)", grams: 45 },
      { name: "Gawgaw (cornstarch)", grams: 12 },
      { name: "Knorr Liquid Seasoning", grams: 3 },
    ],
    instructions: [
      "1. Mix the ground chicken with the grated chicken cube, salt, pepper, and egg, then gradually mix in the breadcrumbs.",
      "2. Scoop 2 tbsp of mixture at a time and roll into balls.",
      "3. Fry the meatballs in the oil over medium heat, rolling them, until browned. Remove.",
      "4. In the remaining oil, sauté the onion until the layers separate, then add the bell pepper and carrot for 1 minute.",
      "5. Add the water, sugar, vinegar, and banana ketchup and bring to a boil, stirring.",
      "6. Stir in the diluted cornstarch until the sauce thickens.",
      "7. Return the meatballs to the pot, toss to coat, and serve."
    ]
  },
  {
    name: "Pininyahang Manok",
    description: "Chicken simmered in pineapple juice and milk with bell pepper.",
    servings: 6,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Manok (chicken)", grams: 900 },
      { name: "Pinya (pineapple)", grams: 340 },
      { name: "Kamatis (tomato)", grams: 200 },
      { name: "Atsal (bell pepper)", grams: 150 },
      { name: "Karot (carrot)", grams: 80 },
      { name: "Patis (fish sauce)", grams: 40 },
      { name: "Fresh milk (gatas)", grams: 120 },
      { name: "Bawang (garlic)", grams: 10 },
      { name: "Sibuyas (onion)", grams: 80 },
      { name: "Mantika (cooking oil)", grams: 30 },
    ],
    instructions: [
      "1. Marinate the chicken in the pineapple juice from the can for 20–30 minutes.",
      "2. Heat the oil in a pot and sauté the garlic, onion, and tomatoes.",
      "3. Add the chicken and cook until lightly browned.",
      "4. Add the pineapple juice marinade and the milk and bring to a boil.",
      "5. Add the pineapple chunks and simmer 20–30 minutes until the chicken is tender and half the liquid has evaporated.",
      "6. Add the carrots and simmer 5 minutes.",
      "7. Add the bell pepper and fish sauce and simmer 3 minutes. Serve hot."
    ]
  },
  {
    name: "Chicken Feet in Oyster Sauce with Salted Black Beans",
    description: "Braised chicken feet in a savory oyster-black bean sauce.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Manok (chicken)", grams: 680 },
      { name: "Oyster sauce", grams: 30 },
      { name: "Tausi (fermented black beans)", grams: 35 },
      { name: "Mirin", grams: 30 },
      { name: "Bawang (garlic)", grams: 10 },
      { name: "Sibuyas (onion)", grams: 60 },
      { name: "Chili garlic oil", grams: 10 },
      { name: "Mantika (cooking oil)", grams: 340 },
    ],
    instructions: [
      "1. Heat the oil and fry the chicken feet 3 minutes per side. Remove and set aside.",
      "2. Heat 3 tbsp oil in a pressure cooker and sauté the garlic and onion until the onion softens.",
      "3. Add the chicken feet and cook 1 minute.",
      "4. Add the oyster sauce and water and pressure cook for 18 minutes.",
      "5. Release the pressure, pour in the mirin, and add the salted black beans. Cook until the sauce reduces by half.",
      "6. Stir in the chili garlic oil and serve."
    ]
  },
  {
    name: "Quick and Easy Fried Chicken",
    description: "Crispy fried chicken drumsticks marinated in soy-calamansi.",
    servings: 5,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Manok (chicken)", grams: 680 },
      { name: "Knorr Liquid Seasoning", grams: 16 },
      { name: "Harina (all-purpose flour)", grams: 60 },
      { name: "Toyo (soy sauce)", grams: 75 },
      { name: "Calamansi", grams: 30 },
      { name: "Paminta (black pepper)", grams: 1 },
      { name: "Mantika (cooking oil)", grams: 400 },
    ],
    instructions: [
      "1. Cut slits in the drumsticks down to the bone.",
      "2. Put the chicken in a resealable bag with the soy sauce, calamansi juice, liquid seasoning, and pepper. Seal, shake, press out the air, and marinate 10 minutes.",
      "3. Heat the oil in a pot to about 360°F.",
      "4. Put the flour in a lidded container, add 1–2 pieces of chicken at a time, and shake until coated. Shake off the excess.",
      "5. Deep-fry the chicken for 14 minutes.",
      "6. Rest 5 minutes and serve with rice or your favorite sides."
    ]
  },
  {
    name: "Bistek (Beef with Calamansi, Soy and Onions)",
    description: "Thin beef slices marinated in calamansi and soy, served with onion rings.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Ribeye steak", grams: 450 },
      { name: "Sibuyas (onion)", grams: 200 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Toyo (soy sauce)", grams: 120 },
      { name: "Calamansi", grams: 120 },
      { name: "Dahon ng laurel (bay leaves)", grams: 2 },
      { name: "Paminta (black pepper)", grams: 1 },
      { name: "Mantika (cooking oil)", grams: 60 },
    ],
    instructions: [
      "1. Freeze the steak about 1 hour until half frozen, then slice the onion into rounds and the garlic thinly, and put both in a large bowl.",
      "2. Add the soy sauce, calamansi juice, bay leaves, and pepper. Slice the steak across the grain into 1/8-inch slices, add to the bowl, and toss. Marinate 30 minutes.",
      "3. Take out the bay leaves and onions (keep the rounds intact). Strain the meat over a bowl, saving the marinade.",
      "4. Heat 2 tbsp oil in a large skillet over medium-high heat. Cook the bay leaves and onions in a single layer, 1 1/2–2 minutes per side, until deep golden.",
      "5. Lower the heat to medium, add 3 tbsp of the marinade, cover, and cook about 3 minutes until the onions soften. Remove and discard the bay leaves.",
      "6. Wipe out the skillet, add the remaining 2 tbsp oil, and heat until smoking. Cook the steak, stirring, about 4 minutes. Transfer to a platter.",
      "7. Add all the remaining marinade to the pan, boil, then simmer about 6 minutes until slightly thickened. Return the onions to warm.",
      "8. Top the steak with the onions, drizzle with the sauce, and serve with rice."
    ]
  },
  {
    name: "Adobong Kangkong",
    description: "Water spinach adobo in a garlicky oyster sauce.",
    servings: 3,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Oyster sauce", grams: 60 },
      { name: "Kangkong (water spinach)", grams: 150 },
      { name: "Mantika (cooking oil)", grams: 15 },
      { name: "Bawang (garlic)", grams: 15 },
    ],
    instructions: [
      "1. Heat the oil and sauté the kangkong stalks.",
      "2. Add the garlic oyster sauce.",
      "3. When the stalks are cooked, add the leaves and cook 1–2 more minutes.",
      "4. Remove from the heat and serve over hot rice."
    ]
  },
  {
    name: "Sinigang na Sardinas",
    description: "Canned mackerel in a sour miso-tamarind broth with vegetables.",
    servings: 6,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Sardinas (canned sardines)", grams: 1275 },
      { name: "Sinigang mix (sampalok)", grams: 75 },
      { name: "Okra", grams: 100 },
      { name: "Sitaw (yardlong beans)", grams: 150 },
      { name: "Labanos (radish)", grams: 170 },
      { name: "Talong (eggplant)", grams: 400 },
      { name: "Sili na mura (green finger chili)", grams: 80 },
      { name: "Kangkong (water spinach)", grams: 200 },
      { name: "Sibuyas (onion)", grams: 200 },
      { name: "Bawang (garlic)", grams: 25 },
      { name: "Luya (ginger)", grams: 60 },
      { name: "Kamatis (tomato)", grams: 500 },
      { name: "Miso paste", grams: 60 },
      { name: "Mantika (cooking oil)", grams: 40 },
      { name: "Patis (fish sauce)", grams: 15 },
      { name: "Paminta (black pepper)", grams: 2 },
    ],
    instructions: [
      "1. Strain the canned fish, keeping both the fish and the oil.",
      "2. Heat the cooking oil and sauté the onions until the layers separate.",
      "3. Add the ginger and garlic and sauté until the garlic starts to brown.",
      "4. Add the tomatoes and sauté 1 minute.",
      "5. Pour in the reserved canned-fish oil, 1 tbsp fish sauce, and 1/2 tsp pepper. Stir.",
      "6. Add the miso and 1 1/2 quarts water and bring to a boil.",
      "7. Add the daikon and cook on medium heat 5 minutes.",
      "8. Stir in the sinigang mix.",
      "9. Add the eggplant and boil 2 minutes.",
      "10. Add the okra, long green peppers, and string beans.",
      "11. Pour in the remaining water, cover, and re-boil for 2 minutes.",
      "12. Gently add the fish and stir.",
      "13. Add the kangkong and cook 2–3 minutes.",
      "14. Season with more fish sauce and pepper and serve hot."
    ]
  },
  {
    name: "Sinigang na Bangus",
    description: "Milkfish in a sour tamarind broth with vegetables.",
    servings: 3,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Bangus (milkfish)", grams: 900 },
      { name: "Sinigang mix (sampalok)", grams: 40 },
      { name: "Kangkong (water spinach)", grams: 200 },
      { name: "Sitaw (yardlong beans)", grams: 120 },
      { name: "Okra", grams: 60 },
      { name: "Sili na mura (green finger chili)", grams: 30 },
      { name: "Kamatis (tomato)", grams: 150 },
      { name: "Sibuyas (onion)", grams: 100 },
      { name: "Patis (fish sauce)", grams: 40 },
      { name: "Paminta (black pepper)", grams: 1 },
    ],
    instructions: [
      "1. Bring the water to a boil in a wide pot.",
      "2. Add the tomato and onion and let the water boil.",
      "3. Add the bangus, cover, and cook on medium heat 8–12 minutes.",
      "4. Add the sinigang mix, stir, and cook 2 minutes.",
      "5. Add the long green peppers, sitaw, and okra, stir, cover, and cook 5–7 minutes.",
      "6. Add the fish sauce and pepper and stir.",
      "7. Add the kangkong leaves, cover, turn off the heat, and let stand 5 minutes.",
      "8. Serve."
    ]
  },
  {
    name: "Sinigang sa Miso (Bangus)",
    description: "Fried milkfish in a miso-tamarind broth with vegetables.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Bangus (milkfish)", grams: 900 },
      { name: "Sinigang mix (sampalok)", grams: 25 },
      { name: "Kangkong (water spinach)", grams: 200 },
      { name: "Sitaw (yardlong beans)", grams: 120 },
      { name: "Okra", grams: 100 },
      { name: "Sili na mura (green finger chili)", grams: 60 },
      { name: "Kamatis (tomato)", grams: 300 },
      { name: "Miso paste", grams: 30 },
      { name: "Sibuyas (onion)", grams: 100 },
      { name: "Asin (salt)", grams: 10 },
      { name: "Mantika (cooking oil)", grams: 40 },
      { name: "Paminta (black pepper)", grams: 1 },
      { name: "Patis (fish sauce)", grams: 15 },
    ],
    instructions: [
      "1. Rub the salt all over the fish and let it sit 10 minutes.",
      "2. Heat the oil and fry each side of the fish about 1 1/2 minutes. Remove and set aside.",
      "3. In the remaining oil, sauté the onion, half of the tomatoes, and the miso for 2 minutes.",
      "4. Return the fish, pour in the water, and bring to a boil.",
      "5. Cover and cook on low-medium heat for 10 minutes.",
      "6. Add the sinigang mix, stir, and cook 2 minutes.",
      "7. Add the long green peppers, string beans, and okra, stir, cover, and cook 5–7 minutes.",
      "8. Add fish sauce and pepper.",
      "9. Add the kangkong leaves, cover, turn off the heat, and let stand 5 minutes. Serve."
    ]
  },
  {
    name: "Pinangat na Galunggong sa Kamias",
    description: "Round scad simmered with kamias, tomatoes, and pork fat.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Galunggong (round scad)", grams: 450 },
      { name: "Kamias (bilimbi)", grams: 200 },
      { name: "Kamatis (tomato)", grams: 200 },
      { name: "Sibuyas (onion)", grams: 60 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Luya (ginger)", grams: 20 },
      { name: "Sili na mura (green finger chili)", grams: 30 },
      { name: "Pork fat", grams: 45 },
      { name: "Asin (salt)", grams: 5 },
      { name: "Paminta (black pepper)", grams: 2 },
    ],
    instructions: [
      "1. Rub salt on the fish and let it sit 5 minutes.",
      "2. Spread the pork fat in a pot, then add the kamias, onion, tomato, garlic, ginger, and green peppers.",
      "3. Arrange the fish on top and season with pepper.",
      "4. Pour in the water, cover, and turn on the heat. Bring to a boil, then lower the heat and cook 15 minutes.",
      "5. Adjust with salt if needed and cook uncovered until the sauce reduces by half.",
      "6. Serve with warm rice."
    ]
  },

  // REMAINING RECIPES
    // ==================== BATCH 6: 25 MORE RECIPES ====================
  {
    name: "Pork Adobo (Adobong Baboy)",
    description: "Classic pork belly adobo braised in soy sauce, vinegar, and garlic.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Liempo (pork belly)", grams: 800 },
      { name: "Toyo (soy sauce)", grams: 90 },
      { name: "Suka (vinegar)", grams: 90 },
      { name: "Bawang (garlic)", grams: 30 },
      { name: "Dahon ng laurel (bay leaves)", grams: 2 },
      { name: "Peppercorns", grams: 5 },
      { name: "Asukal (sugar)", grams: 10 },
      { name: "Mantika (cooking oil)", grams: 30 },
    ],
    instructions: [
      "1. Marinate pork in soy sauce, garlic, peppercorns, and bay leaves for 30 minutes.",
      "2. Sear pork in hot oil until browned.",
      "3. Pour in the marinade and vinegar. Bring to a boil without stirring, then simmer 40 minutes.",
      "4. Add sugar and simmer until pork is tender and sauce thickens.",
      "5. Serve hot with rice."
    ]
  },
  {
    name: "Lechon Kawali",
    description: "Crispy deep-fried pork belly, boiled then air-dried and fried.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Liempo (pork belly)", grams: 1000 },
      { name: "Asin (salt)", grams: 15 },
      { name: "Paminta (black pepper)", grams: 5 },
      { name: "Bawang (garlic)", grams: 25 },
      { name: "Dahon ng laurel (bay leaves)", grams: 2 },
      { name: "Mantika (cooking oil)", grams: 500 },
      { name: "Lechon sauce", grams: 100 },
    ],
    instructions: [
      "1. Boil pork belly with salt, pepper, garlic, and bay leaves for 45 minutes until tender.",
      "2. Drain and air-dry uncovered in the refrigerator for at least 4 hours.",
      "3. Heat oil in a deep pot. Deep-fry pork belly until crispy and golden brown.",
      "4. Drain on paper towels, chop into serving pieces.",
      "5. Serve with lechon sauce or vinegar dip."
    ]
  },
  {
    name: "Crispy Pata",
    description: "Deep-fried pork hock with crispy skin and tender meat.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Pork pata (pork hock)", grams: 1200 },
      { name: "Bawang (garlic)", grams: 20 },
      { name: "Sibuyas (onion)", grams: 60 },
      { name: "Dahon ng laurel (bay leaves)", grams: 3 },
      { name: "Peppercorns", grams: 5 },
      { name: "Asin (salt)", grams: 15 },
      { name: "Toyo (soy sauce)", grams: 30 },
      { name: "Mantika (cooking oil)", grams: 700 },
    ],
    instructions: [
      "1. Boil pork pata with garlic, onion, bay leaves, peppercorns, salt, and soy sauce for 1 hour until tender.",
      "2. Drain and air-dry for 3–4 hours.",
      "3. Heat oil and deep-fry until skin is crispy and golden.",
      "4. Drain and serve with toyomansi dip."
    ]
  },
  {
    name: "Pork Sisig",
    description: "Sizzling chopped pork face and ears with calamansi and chili.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Pork face", grams: 500 },
      { name: "Tenga ng baboy (pork ear)", grams: 300 },
      { name: "Atay ng baboy (pork liver)", grams: 150 },
      { name: "Sibuyas (onion)", grams: 100 },
      { name: "Calamansi", grams: 60 },
      { name: "Siling labuyo (bird's eye chili)", grams: 20 },
      { name: "Mayonnaise", grams: 60 },
      { name: "Mantikilya (butter)", grams: 30 },
      { name: "Asin (salt)", grams: 3 },
      { name: "Paminta (black pepper)", grams: 2 },
    ],
    instructions: [
      "1. Boil pork face and ears until tender, then grill and chop finely.",
      "2. Grill liver and chop.",
      "3. On a sizzling plate, melt butter and sauté onions.",
      "4. Add the chopped pork and liver, mix in calamansi juice, chili, and mayonnaise.",
      "5. Season with salt and pepper, sizzle for 2 minutes, and serve."
    ]
  },
  {
    name: "Bulalo",
    description: "Beef shank and marrow bone soup with corn and vegetables.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Baka (beef, brisket/shank)", grams: 800 },
      { name: "Marrow bones (buto ng baka)", grams: 500 },
      { name: "Mais (corn)", grams: 300 },
      { name: "Repolyo (cabbage)", grams: 200 },
      { name: "Pechay (bok choy)", grams: 200 },
      { name: "Sibuyas (onion)", grams: 80 },
      { name: "Luya (ginger)", grams: 20 },
      { name: "Peppercorns", grams: 5 },
      { name: "Patis (fish sauce)", grams: 20 },
    ],
    instructions: [
      "1. Boil beef shank and marrow bones with onion, ginger, and peppercorns for 2–3 hours until tender.",
      "2. Add corn and simmer 15 minutes.",
      "3. Add cabbage and pechay, cook 5 minutes.",
      "4. Season with fish sauce and serve hot with rice."
    ]
  },
  {
    name: "Beef Tapa",
    description: "Sweet and savory cured beef strips, a classic breakfast viand.",
    servings: 4,
    tags: ["all", "breakfast", "lunch"],
    ingredients: [
      { name: "Sirloin (beef)", grams: 700 },
      { name: "Toyo (soy sauce)", grams: 90 },
      { name: "Asukal (sugar)", grams: 60 },
      { name: "Bawang (garlic)", grams: 30 },
      { name: "Paminta (black pepper)", grams: 3 },
      { name: "Asin (salt)", grams: 5 },
      { name: "Mantika (cooking oil)", grams: 60 },
    ],
    instructions: [
      "1. Slice beef thinly against the grain.",
      "2. Marinate in soy sauce, sugar, garlic, pepper, and salt overnight.",
      "3. Fry in hot oil until edges are crisp.",
      "4. Serve with garlic fried rice and egg."
    ]
  },
  {
    name: "Pork Tocino",
    description: "Sweet cured pork slices, a Filipino breakfast staple.",
    servings: 6,
    tags: ["all", "breakfast", "lunch"],
    ingredients: [
      { name: "Baboy (pork, kasim/shoulder)", grams: 1000 },
      { name: "Asukal (sugar)", grams: 150 },
      { name: "Asin (salt)", grams: 15 },
      { name: "Bawang (garlic)", grams: 20 },
      { name: "Food coloring", grams: 3 },
      { name: "Mantika (cooking oil)", grams: 60 },
    ],
    instructions: [
      "1. Slice pork thinly.",
      "2. Mix with sugar, salt, garlic, and food coloring. Cure for at least 24 hours in the refrigerator.",
      "3. Pan-fry in a little oil over low heat until caramelized.",
      "4. Serve with garlic fried rice and egg."
    ]
  },
  {
    name: "Longganisa",
    description: "Filipino sweet garlic sausage, pan-fried until caramelized.",
    servings: 6,
    tags: ["all", "breakfast", "lunch"],
    ingredients: [
      { name: "Giniling na baboy (ground pork)", grams: 800 },
      { name: "Asukal (sugar)", grams: 100 },
      { name: "Asin (salt)", grams: 12 },
      { name: "Bawang (garlic)", grams: 30 },
      { name: "Suka (vinegar)", grams: 30 },
      { name: "Paminta (black pepper)", grams: 3 },
      { name: "Food coloring", grams: 3 },
      { name: "Mantika (cooking oil)", grams: 40 },
    ],
    instructions: [
      "1. Mix all ingredients well. Cure in the refrigerator for 24 hours.",
      "2. Form into small logs (or stuff into casings).",
      "3. Pan-fry with a little water until liquid evaporates and sausages caramelize.",
      "4. Serve with garlic fried rice and egg."
    ]
  },
  {
    name: "Pancit Cabagan",
    description: "Isabela-style noodle dish with miki, pork, and vegetables.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Miki (egg noodles)", grams: 400 },
      { name: "Baboy (pork, kasim/shoulder)", grams: 300 },
      { name: "Repolyo (cabbage)", grams: 200 },
      { name: "Karot (carrot)", grams: 100 },
      { name: "Sibuyas (onion)", grams: 60 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Toyo (soy sauce)", grams: 60 },
      { name: "Chicken broth", grams: 480 },
      { name: "Mantika (cooking oil)", grams: 40 },
    ],
    instructions: [
      "1. Sauté garlic and onion, then add pork and cook until browned.",
      "2. Pour in soy sauce and broth, bring to a boil.",
      "3. Add miki noodles and cook until tender.",
      "4. Add cabbage and carrot, toss, and serve hot."
    ]
  },
  {
    name: "Sotanghon Guisado",
    description: "Sautéed glass noodles with pork, shrimp, and vegetables.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Sotanghon (glass noodles)", grams: 250 },
      { name: "Baboy (pork, kasim/shoulder)", grams: 200 },
      { name: "Hipon (shrimp)", grams: 200 },
      { name: "Repolyo (cabbage)", grams: 150 },
      { name: "Karot (carrot)", grams: 100 },
      { name: "Sibuyas (onion)", grams: 60 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Toyo (soy sauce)", grams: 45 },
      { name: "Chicken broth", grams: 480 },
    ],
    instructions: [
      "1. Soak sotanghon in water until soft, then drain.",
      "2. Sauté garlic and onion, add pork and shrimp, and cook until browned.",
      "3. Add vegetables and soy sauce.",
      "4. Pour in broth and add sotanghon. Toss until liquid is absorbed.",
      "5. Serve hot with calamansi."
    ]
  },
  {
    name: "Lomi",
    description: "Thick egg noodle soup with pork, shrimp, and vegetables.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Miki (egg noodles)", grams: 400 },
      { name: "Baboy (pork, kasim/shoulder)", grams: 250 },
      { name: "Hipon (shrimp)", grams: 200 },
      { name: "Repolyo (cabbage)", grams: 150 },
      { name: "Karot (carrot)", grams: 100 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Sibuyas (onion)", grams: 60 },
      { name: "Toyo (soy sauce)", grams: 45 },
      { name: "Chicken broth", grams: 1200 },
      { name: "Gawgaw (cornstarch)", grams: 30 },
      { name: "Itlog (egg)", grams: 100 },
    ],
    instructions: [
      "1. Sauté garlic and onion, add pork and shrimp, and cook.",
      "2. Pour in broth and bring to a boil.",
      "3. Add miki noodles and soy sauce, simmer 5 minutes.",
      "4. Add vegetables and thicken with cornstarch slurry.",
      "5. Stir in beaten eggs. Serve hot."
    ]
  },
  {
    name: "Batchoy",
    description: "Iloilo-style noodle soup with pork, liver, and chicharon.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Miki (egg noodles)", grams: 400 },
      { name: "Baboy (pork, kasim/shoulder)", grams: 300 },
      { name: "Atay ng baboy (pork liver)", grams: 150 },
      { name: "Hipon (shrimp)", grams: 150 },
      { name: "Chicharon (pork cracklings)", grams: 60 },
      { name: "Bawang (garlic)", grams: 25 },
      { name: "Sibuyas (onion)", grams: 60 },
      { name: "Chicken broth", grams: 1500 },
      { name: "Toyo (soy sauce)", grams: 30 },
      { name: "Spring onions (dahon ng sibuyas)", grams: 30 },
    ],
    instructions: [
      "1. Boil pork, liver, and shrimp in broth until cooked. Remove and slice.",
      "2. In a bowl, place miki noodles.",
      "3. Pour hot broth over noodles.",
      "4. Top with sliced pork, liver, shrimp, chicharon, garlic, and spring onions.",
      "5. Season with soy sauce and serve immediately."
    ]
  },
  {
    name: "Mami",
    description: "Hot noodle soup with pork, shrimp, and vegetables.",
    servings: 4,
    tags: ["all", "breakfast", "lunch", "dinner"],
    ingredients: [
      { name: "Miki (egg noodles)", grams: 400 },
      { name: "Baboy (pork, kasim/shoulder)", grams: 250 },
      { name: "Hipon (shrimp)", grams: 200 },
      { name: "Pechay (bok choy)", grams: 150 },
      { name: "Bawang (garlic)", grams: 20 },
      { name: "Sibuyas (onion)", grams: 60 },
      { name: "Chicken broth", grams: 1500 },
      { name: "Toyo (soy sauce)", grams: 30 },
      { name: "Spring onions (dahon ng sibuyas)", grams: 20 },
    ],
    instructions: [
      "1. Sauté garlic and onion, add pork and shrimp, and cook.",
      "2. Pour in broth and bring to a boil.",
      "3. Add miki noodles and cook 3 minutes.",
      "4. Add pechay and soy sauce.",
      "5. Serve hot topped with spring onions and toasted garlic."
    ]
  },
  {
    name: "Arroz Valenciana",
    description: "Filipino-style paella with glutinous rice, chicken, and chorizo.",
    servings: 6,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Malagkit (glutinous rice)", grams: 400 },
      { name: "Manok (chicken)", grams: 500 },
      { name: "Chorizo de Bilbao", grams: 150 },
      { name: "Hipon (shrimp)", grams: 200 },
      { name: "Atsal (bell pepper)", grams: 150 },
      { name: "Gisantes (green peas)", grams: 100 },
      { name: "Karot (carrot)", grams: 100 },
      { name: "Tomato sauce", grams: 120 },
      { name: "Atsuete (annatto seeds)", grams: 15 },
      { name: "Bawang (garlic)", grams: 20 },
      { name: "Sibuyas (onion)", grams: 80 },
      { name: "Chicken broth", grams: 720 },
    ],
    instructions: [
      "1. Sauté garlic and onion, add chicken, chorizo, and shrimp.",
      "2. Add tomato sauce and annatto water.",
      "3. Add glutinous rice and broth, bring to a boil.",
      "4. Top with bell pepper, peas, and carrot, cover, and simmer until rice is cooked.",
      "5. Serve in a large platter."
    ]
  },
  {
    name: "Bringhe",
    description: "Kapampangan glutinous rice dish cooked in coconut milk with chicken.",
    servings: 6,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Malagkit (glutinous rice)", grams: 400 },
      { name: "Gata (coconut milk)", grams: 480 },
      { name: "Manok (chicken)", grams: 500 },
      { name: "Chorizo de Bilbao", grams: 100 },
      { name: "Atsal (bell pepper)", grams: 100 },
      { name: "Gisantes (green peas)", grams: 80 },
      { name: "Karot (carrot)", grams: 80 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Sibuyas (onion)", grams: 60 },
      { name: "Atsuete (annatto seeds)", grams: 10 },
      { name: "Luyang dilaw (turmeric)", grams: 10 },
    ],
    instructions: [
      "1. Sauté garlic, onion, and turmeric.",
      "2. Add chicken and chorizo, cook until browned.",
      "3. Pour in coconut milk and annatto water, bring to a boil.",
      "4. Add glutinous rice, stir, and simmer until rice is cooked.",
      "5. Top with bell pepper, peas, and carrot, cover, and steam 5 minutes."
    ]
  },
  {
    name: "Inihaw na Liempo",
    description: "Grilled marinated pork belly with a soy-calamansi glaze.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Liempo (pork belly)", grams: 800 },
      { name: "Toyo (soy sauce)", grams: 60 },
      { name: "Calamansi", grams: 60 },
      { name: "Bawang (garlic)", grams: 20 },
      { name: "Asukal (sugar)", grams: 30 },
      { name: "Ketchup", grams: 60 },
      { name: "Paminta (black pepper)", grams: 3 },
    ],
    instructions: [
      "1. Marinate pork belly in soy sauce, calamansi, garlic, sugar, ketchup, and pepper for at least 2 hours.",
      "2. Grill over hot coals, basting with the marinade.",
      "3. Cook 6–8 minutes per side until charred and cooked through.",
      "4. Slice and serve with dipping sauce."
    ]
  },
  {
    name: "Pork BBQ",
    description: "Sweet-savory Filipino pork barbecue skewers.",
    servings: 6,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Baboy (pork, kasim/shoulder)", grams: 800 },
      { name: "Toyo (soy sauce)", grams: 90 },
      { name: "Banana ketchup", grams: 120 },
      { name: "Asukal (sugar)", grams: 60 },
      { name: "Bawang (garlic)", grams: 20 },
      { name: "Calamansi", grams: 30 },
      { name: "Paminta (black pepper)", grams: 2 },
    ],
    instructions: [
      "1. Slice pork into thin strips.",
      "2. Marinate in soy sauce, banana ketchup, sugar, garlic, calamansi, and pepper overnight.",
      "3. Thread onto skewers.",
      "4. Grill over hot coals, basting with marinade, until cooked and caramelized.",
      "5. Serve with rice or as a snack."
    ]
  },
  {
    name: "Chicken BBQ",
    description: "Grilled chicken skewers in a sweet-soy marinade.",
    servings: 6,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Manok (chicken)", grams: 800 },
      { name: "Toyo (soy sauce)", grams: 90 },
      { name: "Banana ketchup", grams: 100 },
      { name: "Asukal (sugar)", grams: 50 },
      { name: "Bawang (garlic)", grams: 20 },
      { name: "Calamansi", grams: 30 },
      { name: "Paminta (black pepper)", grams: 2 },
    ],
    instructions: [
      "1. Cut chicken into bite-size pieces.",
      "2. Marinate in soy sauce, banana ketchup, sugar, garlic, calamansi, and pepper overnight.",
      "3. Thread onto skewers.",
      "4. Grill over hot coals, basting with marinade, until cooked and caramelized.",
      "5. Serve hot with rice."
    ]
  },
  {
    name: "Lechon Manok",
    description: "Roasted whole chicken stuffed with lemongrass and garlic.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Manok (chicken)", grams: 1400 },
      { name: "Tanglad (lemongrass)", grams: 40 },
      { name: "Bawang (garlic)", grams: 30 },
      { name: "Sibuyas (onion)", grams: 80 },
      { name: "Toyo (soy sauce)", grams: 60 },
      { name: "Calamansi", grams: 60 },
      { name: "Asukal (sugar)", grams: 30 },
      { name: "Asin (salt)", grams: 10 },
      { name: "Paminta (black pepper)", grams: 3 },
      { name: "Mantika (cooking oil)", grams: 30 },
    ],
    instructions: [
      "1. Rub chicken inside and out with salt, pepper, soy sauce, calamansi, and sugar.",
      "2. Stuff with lemongrass, garlic, and onion.",
      "3. Roast in the oven at 200°C for about 1 hour, basting with oil and marinade.",
      "4. Rest 10 minutes before carving.",
      "5. Serve with lechon sauce."
    ]
  },
  {
    name: "Sinangag (Garlic Fried Rice)",
    description: "Filipino garlic fried rice, the classic breakfast side.",
    servings: 4,
    tags: ["all", "breakfast", "lunch"],
    ingredients: [
      { name: "Kanin (cooked rice)", grams: 600 },
      { name: "Bawang (garlic)", grams: 30 },
      { name: "Mantika (cooking oil)", grams: 40 },
      { name: "Asin (salt)", grams: 3 },
    ],
    instructions: [
      "1. Sauté minced garlic in hot oil until golden brown.",
      "2. Add cooked rice and stir-fry until heated through.",
      "3. Season with salt.",
      "4. Serve with any silog (tapa, tocino, longganisa, egg)."
    ]
  },
  {
    name: "Papaitan",
    description: "Ilocano bitter soup made with beef tripe and bile.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Beef tripe (tuwalya)", grams: 800 },
      { name: "Beef bile (apdo)", grams: 30 },
      { name: "Luya (ginger)", grams: 20 },
      { name: "Bawang (garlic)", grams: 20 },
      { name: "Sibuyas (onion)", grams: 60 },
      { name: "Siling labuyo (bird's eye chili)", grams: 15 },
      { name: "Patis (fish sauce)", grams: 30 },
      { name: "Paminta (black pepper)", grams: 3 },
    ],
    instructions: [
      "1. Boil tripe until tender, then slice into strips.",
      "2. Sauté garlic, onion, and ginger.",
      "3. Add tripe and enough water to cover. Simmer 20 minutes.",
      "4. Add bile little by little, tasting for desired bitterness.",
      "5. Season with fish sauce, pepper, and chili. Serve hot."
    ]
  },
  {
    name: "Kalderetang Kambing",
    description: "Goat meat stew with liver spread, peanut butter, and vegetables.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Kambing (goat meat)", grams: 800 },
      { name: "Tomato sauce", grams: 240 },
      { name: "Liver spread", grams: 100 },
      { name: "Patatas (potato)", grams: 200 },
      { name: "Karot (carrot)", grams: 150 },
      { name: "Atsal (bell pepper)", grams: 80 },
      { name: "Peanut butter", grams: 40 },
      { name: "Bawang (garlic)", grams: 20 },
      { name: "Sibuyas (onion)", grams: 60 },
      { name: "Suka (vinegar)", grams: 30 },
      { name: "Siling labuyo (bird's eye chili)", grams: 15 },
    ],
    instructions: [
      "1. Marinate goat meat in vinegar, garlic, and pepper for 1 hour.",
      "2. Sauté garlic and onion, add goat meat, and brown.",
      "3. Pour in tomato sauce and water, simmer until tender (about 1 hour).",
      "4. Add liver spread, peanut butter, and vegetables.",
      "5. Season with chili and simmer 10 minutes. Serve hot."
    ]
  },
  {
    name: "Bam-i (Pancit Bisaya)",
    description: "Cebuano noodle dish combining canton and bihon noodles.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Pancit canton noodles", grams: 200 },
      { name: "Pancit bihon (rice noodles)", grams: 200 },
      { name: "Baboy (pork, kasim/shoulder)", grams: 250 },
      { name: "Hipon (shrimp)", grams: 200 },
      { name: "Repolyo (cabbage)", grams: 150 },
      { name: "Karot (carrot)", grams: 100 },
      { name: "Sibuyas (onion)", grams: 60 },
      { name: "Bawang (garlic)", grams: 15 },
      { name: "Toyo (soy sauce)", grams: 45 },
      { name: "Chicken broth", grams: 480 },
    ],
    instructions: [
      "1. Sauté garlic and onion, add pork and shrimp, and cook.",
      "2. Add vegetables and soy sauce.",
      "3. Pour in broth and add both noodle types.",
      "4. Toss until noodles are tender and liquid is absorbed.",
      "5. Serve with calamansi."
    ]
  },
  {
    name: "Sinigang na Baka",
    description: "Beef in a sour tamarind broth with vegetables.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Baka (beef, brisket/shank)", grams: 800 },
      { name: "Sinigang mix (sampalok)", grams: 40 },
      { name: "Kamatis (tomato)", grams: 200 },
      { name: "Sibuyas (onion)", grams: 60 },
      { name: "Labanos (radish)", grams: 150 },
      { name: "Sitaw (yardlong beans)", grams: 100 },
      { name: "Talong (eggplant)", grams: 150 },
      { name: "Kangkong (water spinach)", grams: 150 },
      { name: "Sili na mura (green finger chili)", grams: 30 },
      { name: "Patis (fish sauce)", grams: 20 },
    ],
    instructions: [
      "1. Boil beef in water until tender (about 2 hours), skimming scum.",
      "2. Add tomato and onion, simmer 10 minutes.",
      "3. Add radish and sinigang mix, cook 5 minutes.",
      "4. Add sitaw, eggplant, and chili, cook 5 minutes.",
      "5. Add kangkong and fish sauce. Serve hot."
    ]
  },
  {
    name: "Bangus Sisig",
    description: "Sizzling flaked milkfish with calamansi and chili.",
    servings: 4,
    tags: ["all", "lunch", "dinner"],
    ingredients: [
      { name: "Bangus (milkfish)", grams: 700 },
      { name: "Sibuyas (onion)", grams: 80 },
      { name: "Calamansi", grams: 60 },
      { name: "Siling labuyo (bird's eye chili)", grams: 20 },
      { name: "Mayonnaise", grams: 60 },
      { name: "Mantikilya (butter)", grams: 30 },
      { name: "Asin (salt)", grams: 3 },
      { name: "Paminta (black pepper)", grams: 2 },
    ],
    instructions: [
      "1. Grill or fry bangus until cooked, then flake the meat (remove bones).",
      "2. Melt butter on a sizzling plate, sauté onions.",
      "3. Add flaked bangus, calamansi juice, chili, and mayonnaise.",
      "4. Season with salt and pepper.",
      "5. Sizzle 2 minutes and serve."
    ]
  },
];