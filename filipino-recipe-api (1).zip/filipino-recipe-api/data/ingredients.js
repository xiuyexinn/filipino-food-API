// Nutrition values are per 100g edible portion, compiled from general
// published nutrition references (USDA-equivalent entries where a direct
// Filipino ingredient match exists, e.g. sitaw = yardlong bean, gabi = taro,
// ampalaya = bitter melon, malunggay = moringa leaves).
// These are reasonable starting estimates, NOT lab-verified figures.
// See README "Upgrading nutrition accuracy" for how to replace these with
// official DOST-FNRI PhilFCT values.

module.exports = [
  // --- Vegetables ---
  { name: "Sitaw (yardlong beans)", aliases: ["string beans", "long beans"], category: "vegetable", calories: 47, protein: 2.8, fat: 0.4, carbs: 8.4, fiber: 3.6, sodium_mg: 4 },
  { name: "Kangkong (water spinach)", aliases: ["swamp cabbage"], category: "vegetable", calories: 19, protein: 2.6, fat: 0.2, carbs: 3.1, fiber: 2.1, sodium_mg: 113 },
  { name: "Ampalaya (bitter melon)", aliases: ["bitter gourd"], category: "vegetable", calories: 17, protein: 1.0, fat: 0.2, carbs: 3.7, fiber: 2.8, sodium_mg: 5 },
  { name: "Malunggay (moringa leaves)", aliases: ["horseradish tree leaves"], category: "vegetable", calories: 64, protein: 9.4, fat: 1.4, carbs: 8.3, fiber: 2.0, sodium_mg: 9 },
  { name: "Gabi (taro)", aliases: ["taro root"], category: "vegetable", calories: 112, protein: 1.5, fat: 0.1, carbs: 26.5, fiber: 4.1, sodium_mg: 11 },
  { name: "Kalabasa (squash)", aliases: ["kabocha", "calabaza"], category: "vegetable", calories: 26, protein: 1.0, fat: 0.1, carbs: 6.5, fiber: 0.5, sodium_mg: 1 },
  { name: "Talong (eggplant)", aliases: ["aubergine"], category: "vegetable", calories: 25, protein: 1.0, fat: 0.2, carbs: 5.9, fiber: 3.0, sodium_mg: 2 },
  { name: "Patola (luffa/sponge gourd)", aliases: ["luffa"], category: "vegetable", calories: 20, protein: 1.2, fat: 0.2, carbs: 4.4, fiber: 1.8, sodium_mg: 2 },
  { name: "Labanos (radish)", aliases: ["daikon"], category: "vegetable", calories: 16, protein: 0.7, fat: 0.1, carbs: 3.4, fiber: 1.6, sodium_mg: 21 },
  { name: "Sili na mura (green finger chili)", aliases: ["siling haba", "long green chili"], category: "vegetable", calories: 40, protein: 2.0, fat: 0.2, carbs: 9.5, fiber: 1.5, sodium_mg: 7 },
  { name: "Siling labuyo (bird's eye chili)", aliases: ["labuyo chili"], category: "vegetable", calories: 40, protein: 1.9, fat: 0.4, carbs: 8.8, fiber: 1.5, sodium_mg: 9 },
  { name: "Puso ng saging (banana blossom/heart)", aliases: ["banana blossom"], category: "vegetable", calories: 51, protein: 1.6, fat: 0.6, carbs: 9.9, fiber: 5.7, sodium_mg: 5 },
  { name: "Ubod (heart of palm/coconut pith)", aliases: ["heart of palm"], category: "vegetable", calories: 27, protein: 2.4, fat: 0.6, carbs: 3.9, fiber: 2.4, sodium_mg: 244 },
  { name: "Saging na saba (plantain)", aliases: ["cardaba banana"], category: "fruit", calories: 122, protein: 1.3, fat: 0.3, carbs: 31.9, fiber: 2.3, sodium_mg: 4 },
  { name: "Kamote (sweet potato)", aliases: ["camote"], category: "vegetable", calories: 86, protein: 1.6, fat: 0.1, carbs: 20.1, fiber: 3.0, sodium_mg: 55 },
  { name: "Dahon ng sili (chili leaves)", aliases: ["chili pepper leaves"], category: "vegetable", calories: 37, protein: 4.0, fat: 0.5, carbs: 6.6, fiber: 1.8, sodium_mg: 12 },

  // --- Souring/flavoring & condiments ---
  { name: "Calamansi", aliases: ["kalamansi", "Philippine lime"], category: "fruit", calories: 26, protein: 0.6, fat: 0.3, carbs: 8.9, fiber: 2.0, sodium_mg: 1 },
  { name: "Bagoong alamang (shrimp paste)", aliases: ["shrimp paste", "bagoong"], category: "condiment", calories: 91, protein: 12.0, fat: 1.5, carbs: 6.0, fiber: 0, sodium_mg: 6700 },
  { name: "Bagoong isda (fermented fish sauce/paste)", aliases: ["patis-style paste"], category: "condiment", calories: 60, protein: 9.5, fat: 1.0, carbs: 2.5, fiber: 0, sodium_mg: 7200 },
  { name: "Patis (fish sauce)", aliases: ["fish sauce"], category: "condiment", calories: 35, protein: 5.1, fat: 0, carbs: 3.6, fiber: 0, sodium_mg: 7850 },
  { name: "Toyo (soy sauce)", aliases: ["soy sauce"], category: "condiment", calories: 53, protein: 8.1, fat: 0.6, carbs: 4.9, fiber: 0.8, sodium_mg: 5490 },
  { name: "Suka (cane/coconut vinegar)", aliases: ["vinegar"], category: "condiment", calories: 18, protein: 0, fat: 0, carbs: 0.4, fiber: 0, sodium_mg: 2 },
  { name: "Gata (coconut milk)", aliases: ["coconut milk"], category: "dairy-alt", calories: 230, protein: 2.3, fat: 24.0, carbs: 5.5, fiber: 2.2, sodium_mg: 15 },
  { name: "Atsuete (annatto seeds)", aliases: ["achuete", "annatto"], category: "spice", calories: 30, protein: 1.0, fat: 0.9, carbs: 4.5, fiber: 3.3, sodium_mg: 3 },
  { name: "Tanglad (lemongrass)", aliases: ["lemongrass"], category: "spice", calories: 99, protein: 1.8, fat: 0.5, carbs: 25.3, fiber: 0, sodium_mg: 6 },

  // --- Aromatics / pantry ---
  { name: "Bawang (garlic)", aliases: ["garlic"], category: "aromatic", calories: 149, protein: 6.4, fat: 0.5, carbs: 33.1, fiber: 2.1, sodium_mg: 17 },
  { name: "Sibuyas (onion)", aliases: ["onion"], category: "aromatic", calories: 40, protein: 1.1, fat: 0.1, carbs: 9.3, fiber: 1.7, sodium_mg: 4 },
  { name: "Luya (ginger)", aliases: ["ginger"], category: "aromatic", calories: 80, protein: 1.8, fat: 0.8, carbs: 17.8, fiber: 2.0, sodium_mg: 13 },
  { name: "Kanin (cooked rice)", aliases: ["rice"], category: "grain", calories: 130, protein: 2.7, fat: 0.3, carbs: 28.2, fiber: 0.4, sodium_mg: 1 },

  // --- Proteins ---
  { name: "Baboy (pork, kasim/shoulder)", aliases: ["pork"], category: "protein", calories: 242, protein: 27.3, fat: 14.0, carbs: 0, fiber: 0, sodium_mg: 62 },
  { name: "Manok (chicken)", aliases: ["chicken"], category: "protein", calories: 239, protein: 27.3, fat: 13.6, carbs: 0, fiber: 0, sodium_mg: 82 },
  { name: "Baka (beef, brisket/shank)", aliases: ["beef"], category: "protein", calories: 250, protein: 26.0, fat: 15.0, carbs: 0, fiber: 0, sodium_mg: 72 },
  { name: "Hipon (shrimp)", aliases: ["shrimp", "prawn"], category: "protein", calories: 99, protein: 24.0, fat: 0.3, carbs: 0.2, fiber: 0, sodium_mg: 111 },
  { name: "Bangus (milkfish)", aliases: ["milkfish"], category: "protein", calories: 148, protein: 20.5, fat: 6.7, carbs: 0, fiber: 0, sodium_mg: 65 },
  { name: "Tilapia", aliases: ["tilapia fish"], category: "protein", calories: 96, protein: 20.1, fat: 1.7, carbs: 0, fiber: 0, sodium_mg: 52 },
  { name: "Itlog (egg)", aliases: ["egg"], category: "protein", calories: 143, protein: 12.6, fat: 9.5, carbs: 0.7, fiber: 0, sodium_mg: 142 },
  { name: "Tokwa (tofu)", aliases: ["tofu"], category: "protein", calories: 76, protein: 8.1, fat: 4.8, carbs: 1.9, fiber: 0.3, sodium_mg: 7 },
];
