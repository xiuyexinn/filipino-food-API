const path = require("path");
const { DatabaseSync } = require("node:sqlite");

const DB_PATH = path.join(__dirname, "filipino_food.db");
const db = new DatabaseSync(DB_PATH);

function migrate() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS ingredients (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      aliases TEXT,           -- JSON array of alternate names
      category TEXT,
      calories REAL,
      protein REAL,
      fat REAL,
      carbs REAL,
      fiber REAL,
      sodium_mg REAL
    );

    CREATE TABLE IF NOT EXISTS recipes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      description TEXT,
      servings INTEGER,
      tags TEXT,               -- JSON array
      instructions TEXT        -- JSON array of steps
    );

    CREATE TABLE IF NOT EXISTS recipe_ingredients (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      recipe_id INTEGER NOT NULL REFERENCES recipes(id) ON DELETE CASCADE,
      ingredient_id INTEGER NOT NULL REFERENCES ingredients(id),
      grams REAL NOT NULL
    );

    CREATE INDEX IF NOT EXISTS idx_ri_recipe ON recipe_ingredients(recipe_id);
    CREATE INDEX IF NOT EXISTS idx_ri_ingredient ON recipe_ingredients(ingredient_id);
  `);
}

function seed() {
  const ingredients = require("../data/ingredients");
  const recipes = require("../data/recipes");

  const insertIngredient = db.prepare(`
    INSERT OR IGNORE INTO ingredients
      (name, aliases, category, calories, protein, fat, carbs, fiber, sodium_mg)
    VALUES (@name, @aliases, @category, @calories, @protein, @fat, @carbs, @fiber, @sodium_mg)
  `);

  db.exec("BEGIN");
  try {
    for (const ing of ingredients) {
      insertIngredient.run({
        ...ing,
        aliases: JSON.stringify(ing.aliases || []),
      });
    }
    db.exec("COMMIT");
  } catch (err) {
    db.exec("ROLLBACK");
    throw err;
  }

  const getIngredientId = db.prepare(`SELECT id FROM ingredients WHERE name = ?`);
  const insertRecipe = db.prepare(`
    INSERT OR IGNORE INTO recipes (name, description, servings, tags, instructions)
    VALUES (@name, @description, @servings, @tags, @instructions)
  `);
  const getRecipeId = db.prepare(`SELECT id FROM recipes WHERE name = ?`);
  const insertRecipeIngredient = db.prepare(`
    INSERT INTO recipe_ingredients (recipe_id, ingredient_id, grams)
    VALUES (?, ?, ?)
  `);
  const clearRecipeIngredients = db.prepare(`DELETE FROM recipe_ingredients WHERE recipe_id = ?`);

  db.exec("BEGIN");
  try {
    for (const r of recipes) {
      insertRecipe.run({
        name: r.name,
        description: r.description || "",
        servings: r.servings || 4,
        tags: JSON.stringify(r.tags || []),
        instructions: JSON.stringify(r.instructions || []),
      });
      const recipeRow = getRecipeId.get(r.name);
      if (!recipeRow) continue;
      clearRecipeIngredients.run(recipeRow.id);
      for (const ri of r.ingredients) {
        const ingRow = getIngredientId.get(ri.name);
        if (!ingRow) {
          console.warn(`Warning: ingredient "${ri.name}" (in recipe "${r.name}") not found in ingredients.js`);
          continue;
        }
        insertRecipeIngredient.run(recipeRow.id, ingRow.id, ri.grams);
      }
    }
    db.exec("COMMIT");
  } catch (err) {
    db.exec("ROLLBACK");
    throw err;
  }
}

migrate();
seed();

console.log(`Seeded database at ${DB_PATH}`);
console.log(
  `Ingredients: ${db.prepare("SELECT COUNT(*) c FROM ingredients").get().c}, ` +
  `Recipes: ${db.prepare("SELECT COUNT(*) c FROM recipes").get().c}`
);

module.exports = db;
