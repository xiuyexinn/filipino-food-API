# Filipino Recipe & Ingredient API

A small, self-contained REST API for a "what can I cook with what I have"
Filipino recipe app. It's seeded with local Filipino ingredients (calamansi,
bagoong, sitaw, gata, etc.) with per-100g nutrition data, and a set of
classic Filipino recipes linked to those ingredients.

## Stack
- Node.js + Express (REST API)
- SQLite via `better-sqlite3` (single-file database, no server to run/host)

## Setup

```bash
npm install
npm run seed   # builds db/filipino_food.db from data/ingredients.js and data/recipes.js
npm start      # runs the API on http://localhost:3000
```

Use `npm run dev` instead of `npm start` to auto-restart on file changes.

## Endpoints

### `GET /api/ingredients?q=<text>`
Search ingredients by name or alias (e.g. `?q=bagoong`, `?q=kalamansi`).
Omit `q` to list everything. Returns nutrition per 100g for each.

### `GET /api/ingredients/:id`
Full detail for one ingredient.

### `GET /api/recipes?q=<text>`
List/search recipes by name (nutrition omitted here for speed — use the
detail endpoint below for full nutrition).

### `GET /api/recipes/:id`
Full recipe: ingredients, quantities, instructions, and computed
`nutrition_total` (whole recipe) and `nutrition_per_serving`.

### `POST /api/recipes/search-by-ingredients`
The core "what's in my kitchen" endpoint.

```json
{
  "ingredients": ["sitaw", "kalabasa", "bawang", "sibuyas", "gata"],
  "match": "most"
}
```

- `match: "any"` — recipe needs at least one matching ingredient
- `match: "most"` — at least 60% of the recipe's ingredients are matched (default)
- `match: "all"` — you have every ingredient the recipe needs

Returns recipes ranked by match ratio, each with `missing_ingredients` (so
your app can show "you just need calamansi and siling labuyo") and full
computed nutrition.

Ingredient name matching is intentionally loose (substring + alias match) so
"kalamansi" and "calamansi" both work, and partial words like "sitaw" match
"Sitaw (yardlong beans)".

## What's in the seed data

- **37 ingredients**: native vegetables (sitaw, kangkong, ampalaya, malunggay,
  gabi, kalabasa, talong, patola, labanos, sili varieties, puso ng saging,
  ubod, saba, kamote, dahon ng sili), condiments/souring agents (calamansi,
  bagoong alamang, bagoong isda, patis, toyo, suka, gata, atsuete, tanglad),
  aromatics, rice, and common proteins (pork, chicken, beef, shrimp, bangus,
  tilapia, egg, tofu).
- **12 recipes**: sinigang, adobo, pinakbet, tinola, laing, Bicol express,
  ginisang gulay dishes, paksiw na bangus, ginataang gulay, nilaga, ginisang
  ampalaya, tokwa't bagoong.

This is enough to demo and build against, but it is a starting seed, not a
production-scale dataset — extend `data/ingredients.js` and
`data/recipes.js` (plain JS arrays) and re-run `npm run seed` to grow it.

## ⚠️ On nutrition accuracy — please read

You asked for **hyper-accurate local nutritional profiles**. I want to be
upfront: the numbers in `data/ingredients.js` are reasonable estimates
compiled from general nutrition references (mostly USDA-equivalent entries
for the closest matching food — e.g. sitaw ≈ yardlong bean, gabi ≈ taro,
ampalaya ≈ bitter melon). They are **not** sourced from a verified Filipino
lab-tested database, and for genuinely local items like bagoong or specific
Philippine rice varieties, generic international data can be meaningfully
off (fermentation, local varietals, and regional prep all shift the numbers).

The one dataset that actually matches what you asked for is the
**Philippine Food Composition Tables (PhilFCT)**, maintained by DOST-FNRI —
it covers ~1,500 commonly consumed Philippine foods and is searchable by
English, Filipino, or scientific name. It's a web tool, not a public API, so
to use it here you'd need to either:

1. Contact FNRI (philfct@fnri.dost.gov.ph) about data licensing/access for
   your app, or
2. Manually look up and transcribe the specific ingredients you need into
   `data/ingredients.js` (same shape as the existing entries — just replace
   the numbers), then re-run `npm run seed`.

Either way, the schema and API are already built to carry that data — you're
only ever swapping numbers in one file, not restructuring anything.

## Extending

- Add ingredients: append an object to `data/ingredients.js`.
- Add recipes: append an object to `data/recipes.js`, referencing ingredient
  `name`s exactly as they appear in `data/ingredients.js`. The seed script
  will warn you in the console if a recipe references an ingredient name it
  can't find.
- Re-run `npm run seed` any time you edit the data files — it's idempotent
  (existing rows are left alone, new ones are inserted).
