const path = require("path");
const { DatabaseSync } = require("node:sqlite");

const DB_PATH = path.join(__dirname, "filipino_food.db");
const db = new DatabaseSync(DB_PATH);

module.exports = db;
