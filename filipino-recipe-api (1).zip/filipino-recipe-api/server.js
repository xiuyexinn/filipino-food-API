const express = require("express");
const db = require("./db/connection");

const app = express();
app.use(express.json());

const PORT = process.env.PORT || 3000;

// ---------- helpers ----------

function parseJsonField(value, fallback) {
  try {
    return JSON.parse(value);
  } catch {
    return fallback;
  }
}

function serializeIngredient(row) {
  return {
    id: row.id,
    name: row.name,
    aliases: parseJsonField(row.aliases, []),
    category: row.category,
    nutrition_per_100g: {
      calories: row.calories,
      protein_g: row.protein,
      fat_g: row.fat,
      carbs_g: row.carbs,
      fiber_g: row.fiber,
      sodium_mg: row.sodium_mg,
    },
  };
}

function getRecipeIngredients(recipeId) {
  return db
    .prepare(
      `SELECT i.id, i.name, i.category, ri.grams,
              i.calories, i.protein, i.fat, i.carbs, i.fiber, i.sodium_mg
       FROM recipe_ingredients ri
       JOIN ingredients i ON i.id = ri.ingredient_id
       WHERE ri.recipe_id = ?`
    )
    .all(recipeId);
}

function computeNutrition(ingredientRows) {
  const totals = { calories: 0, protein_g: 0, fat_g: 0, carbs_g: 0, fiber_g: 0, sodium_mg: 0 };
  for (const row of ingredientRows) {
    const factor = row.grams / 100;
    totals.calories += row.calories * factor;
    totals.protein_g += row.protein * factor;
    totals.fat_g += row.fat * factor;
    totals.carbs_g += row.carbs * factor;
    totals.fiber_g += row.fiber * factor;
    totals.sodium_mg += row.sodium_mg * factor;
  }
  for (const k in totals) totals[k] = Math.round(totals[k] * 10) / 10;
  return totals;
}

function serializeRecipe(row, { includeNutrition = true } = {}) {
  const ingredientRows = getRecipeIngredients(row.id);
  const out = {
    id: row.id,
    name: row.name,
    description: row.description,
    servings: row.servings,
    tags: parseJsonField(row.tags, []),
    instructions: parseJsonField(row.instructions, []),
    ingredients: ingredientRows.map((r) => ({
      id: r.id,
      name: r.name,
      grams: r.grams,
    })),
  };
  if (includeNutrition) {
    out.nutrition_total = computeNutrition(ingredientRows);
    out.nutrition_per_serving = Object.fromEntries(
      Object.entries(out.nutrition_total).map(([k, v]) => [k, Math.round((v / row.servings) * 10) / 10])
    );
  }
  return out;
}

// ---------- ingredient endpoints ----------

// GET /api/ingredients?q=sitaw
app.get("/api/ingredients", (req, res) => {
  const q = (req.query.q || "").trim().toLowerCase();
  let rows;
  if (q) {
    rows = db.prepare(`SELECT * FROM ingredients`).all()
      .filter((r) => {
        if (r.name.toLowerCase().includes(q)) return true;
        const aliases = parseJsonField(r.aliases, []);
        return aliases.some((a) => a.toLowerCase().includes(q));
      });
  } else {
    rows = db.prepare(`SELECT * FROM ingredients ORDER BY name`).all();
  }
  res.json(rows.map(serializeIngredient));
});

// GET /api/ingredients/:id
app.get("/api/ingredients/:id", (req, res) => {
  const row = db.prepare(`SELECT * FROM ingredients WHERE id = ?`).get(req.params.id);
  if (!row) return res.status(404).json({ error: "Ingredient not found" });
  res.json(serializeIngredient(row));
});

// ---------- recipe endpoints ----------

// GET /api/recipes?q=adobo
app.get("/api/recipes", (req, res) => {
  const q = (req.query.q || "").trim().toLowerCase();
  let rows = db.prepare(`SELECT * FROM recipes ORDER BY name`).all();
  if (q) rows = rows.filter((r) => r.name.toLowerCase().includes(q));
  res.json(rows.map((r) => serializeRecipe(r, { includeNutrition: false })));
});

// GET /api/recipes/:id  (full detail incl. nutrition)
app.get("/api/recipes/:id", (req, res) => {
  const row = db.prepare(`SELECT * FROM recipes WHERE id = ?`).get(req.params.id);
  if (!row) return res.status(404).json({ error: "Recipe not found" });
  res.json(serializeRecipe(row));
});

// POST /api/recipes/search-by-ingredients
// Body: { "ingredients": ["sitaw", "kalabasa", "bagoong"], "match": "any" | "most" | "all" }
// Returns recipes ranked by how many of their ingredients you already have.
app.post("/api/recipes/search-by-ingredients", (req, res) => {
  const haveNames = (req.body.ingredients || []).map((s) => s.trim().toLowerCase());
  const mode = req.body.match || "most"; // "any" | "most" | "all"

  if (haveNames.length === 0) {
    return res.status(400).json({ error: "Provide a non-empty 'ingredients' array." });
  }

  const allIngredients = db.prepare(`SELECT id, name, aliases FROM ingredients`).all();
  const haveIds = new Set();
  for (const ing of allIngredients) {
    const aliases = parseJsonField(ing.aliases, []);
    const candidates = [ing.name.toLowerCase(), ...aliases.map((a) => a.toLowerCase())];
    if (haveNames.some((h) => candidates.some((c) => c.includes(h) || h.includes(c)))) {
      haveIds.add(ing.id);
    }
  }

  const recipes = db.prepare(`SELECT * FROM recipes`).all();
  const results = [];

  for (const recipe of recipes) {
    const ingredientRows = getRecipeIngredients(recipe.id);
    const totalCount = ingredientRows.length;
    const matchedRows = ingredientRows.filter((r) => haveIds.has(r.id));
    const matchedCount = matchedRows.length;
    const missing = ingredientRows.filter((r) => !haveIds.has(r.id)).map((r) => r.name);

    if (matchedCount === 0) continue;
    if (mode === "all" && matchedCount < totalCount) continue;
    if (mode === "most" && matchedCount / totalCount < 0.6) continue;

    results.push({
      recipe: serializeRecipe(recipe, { includeNutrition: true }),
      match_ratio: Math.round((matchedCount / totalCount) * 100) / 100,
      matched_count: matchedCount,
      total_ingredients: totalCount,
      missing_ingredients: missing,
    });
  }

  results.sort((a, b) => b.match_ratio - a.match_ratio || a.missing_ingredients.length - b.missing_ingredients.length);
  res.json(results);
});

app.get("/", (req, res) => {
  res.json({
    name: "Filipino Recipe & Ingredient API",
    endpoints: [
      "GET  /api/ingredients?q=<name>",
      "GET  /api/ingredients/:id",
      "GET  /api/recipes?q=<name>",
      "GET  /api/recipes/:id",
      "POST /api/recipes/search-by-ingredients  { ingredients: string[], match?: 'any'|'most'|'all' }",
    ],
  });
});

app.listen(PORT, () => {
  console.log(`Filipino Recipe API running on http://localhost:${PORT}`);
});
